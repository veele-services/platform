import { FieldgridDesignLab } from "./fieldgrid-design-lab";

export default function Home() {
  return <FieldgridDesignLab />;
}
