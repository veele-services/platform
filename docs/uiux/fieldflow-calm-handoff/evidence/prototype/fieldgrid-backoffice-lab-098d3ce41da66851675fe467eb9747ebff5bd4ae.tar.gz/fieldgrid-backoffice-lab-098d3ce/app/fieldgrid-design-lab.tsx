"use client";

import * as React from "react";
import {
  Activity,
  AlertCircle,
  Archive,
  ArrowLeft,
  ArrowRight,
  BadgeCheck,
  Bell,
  Blocks,
  BookOpen,
  Boxes,
  BriefcaseBusiness,
  Building2,
  CalendarClock,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  CircleHelp,
  ClipboardCheck,
  ClipboardList,
  Clock3,
  Columns3,
  Command as CommandIcon,
  Copy,
  Download,
  ExternalLink,
  FileCheck2,
  FilePenLine,
  FileText,
  FolderOpen,
  Gauge,
  Globe2,
  GripVertical,
  HardHat,
  History,
  Home,
  Inbox,
  KeyRound,
  LayoutDashboard,
  ListFilter,
  LockKeyhole,
  Mail,
  Map,
  MapPin,
  Menu,
  MessageSquareText,
  MoreHorizontal,
  Newspaper,
  PackageCheck,
  PackageSearch,
  PanelLeftClose,
  PanelTop,
  Pencil,
  Phone,
  Plus,
  ReceiptText,
  RefreshCw,
  Route,
  Save,
  Search,
  Send,
  Settings2,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Star,
  Tags,
  Trash2,
  TrendingUp,
  UploadCloud,
  UserCog,
  UserPlus,
  Users,
  WalletCards,
  WandSparkles,
  Workflow,
  type LucideIcon,
} from "lucide-react";
import { toast, Toaster } from "sonner";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandShortcut,
} from "@/components/ui/command";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

type DesignId = "fieldflow" | "northstar" | "atlas" | "nocturne" | "ledger";
type GroupId =
  | "start"
  | "operation"
  | "relations"
  | "team"
  | "quality"
  | "finance"
  | "content"
  | "manage";
type ViewId =
  | "dashboard"
  | "planning"
  | "assignments"
  | "customers"
  | "objects"
  | "personnel"
  | "leave"
  | "materials"
  | "inventory"
  | "quotes"
  | "reports"
  | "invoices"
  | "documents"
  | "tickets"
  | "news"
  | "website"
  | "checklists"
  | "settings"
  | "support"
  | "analysis";
type DossierType = "customer" | "personnel" | "object";

type DesignSpec = {
  id: DesignId;
  number: string;
  name: string;
  descriptor: string;
  thesis: string;
  shell: "sidebar" | "topbar" | "splitrail" | "command" | "editorial";
};

type NavItem = {
  id: ViewId;
  label: string;
  shortLabel: string;
  group: GroupId;
  icon: LucideIcon;
  badge?: string;
};

type NavGroup = {
  id: GroupId;
  label: string;
  compactLabel: string;
  icon: LucideIcon;
};

const designs: DesignSpec[] = [
  {
    id: "fieldflow",
    number: "01",
    name: "Fieldflow Calm",
    descriptor: "Zacht, ruim en taakgericht",
    thesis:
      "De rust van VeyoCast vertaald naar een volwassen services-operatie.",
    shell: "sidebar",
  },
  {
    id: "northstar",
    number: "02",
    name: "Northstar Suite",
    descriptor: "Horizontaal en executive",
    thesis: "Een brede commandobar met domeinen als heldere werkruimtes.",
    shell: "topbar",
  },
  {
    id: "atlas",
    number: "03",
    name: "Atlas Workbench",
    descriptor: "Gelaagd en dossiergericht",
    thesis:
      "Een compacte rail en vaste module-index voor intensief dagelijks werk.",
    shell: "splitrail",
  },
  {
    id: "nocturne",
    number: "04",
    name: "Nocturne Command",
    descriptor: "Donker en operationeel",
    thesis: "Een high-contrast control room met context binnen handbereik.",
    shell: "command",
  },
  {
    id: "ledger",
    number: "05",
    name: "Ledger Editorial",
    descriptor: "Redactioneel en precies",
    thesis:
      "Een rustige papieren werktafel met sterke typografische hiërarchie.",
    shell: "editorial",
  },
];

const navGroups: NavGroup[] = [
  { id: "start", label: "Start", compactLabel: "Start", icon: Home },
  {
    id: "operation",
    label: "Planning & operatie",
    compactLabel: "Operatie",
    icon: CalendarDays,
  },
  {
    id: "relations",
    label: "Relaties & locaties",
    compactLabel: "Relaties",
    icon: Building2,
  },
  { id: "team", label: "Team & middelen", compactLabel: "Team", icon: Users },
  {
    id: "quality",
    label: "Kwaliteit & bewijs",
    compactLabel: "Kwaliteit",
    icon: ClipboardCheck,
  },
  {
    id: "finance",
    label: "Financieel",
    compactLabel: "Financieel",
    icon: WalletCards,
  },
  {
    id: "content",
    label: "Contact & publicatie",
    compactLabel: "Content",
    icon: MessageSquareText,
  },
  {
    id: "manage",
    label: "Organisatiebeheer",
    compactLabel: "Beheer",
    icon: Settings2,
  },
];

const navItems: NavItem[] = [
  {
    id: "dashboard",
    label: "Vandaag",
    shortLabel: "Start",
    group: "start",
    icon: LayoutDashboard,
  },
  {
    id: "planning",
    label: "Planbord",
    shortLabel: "Planning",
    group: "operation",
    icon: CalendarDays,
  },
  {
    id: "assignments",
    label: "Opdrachten",
    shortLabel: "Opdrachten",
    group: "operation",
    icon: ClipboardList,
    badge: "8",
  },
  {
    id: "customers",
    label: "Klanten",
    shortLabel: "Klanten",
    group: "relations",
    icon: BriefcaseBusiness,
  },
  {
    id: "objects",
    label: "Objecten & locaties",
    shortLabel: "Objecten",
    group: "relations",
    icon: Building2,
  },
  {
    id: "personnel",
    label: "Medewerkers",
    shortLabel: "Team",
    group: "team",
    icon: UserCog,
  },
  {
    id: "leave",
    label: "Verlof & beschikbaarheid",
    shortLabel: "Verlof",
    group: "team",
    icon: CalendarClock,
    badge: "3",
  },
  {
    id: "materials",
    label: "Verbruiksmaterialen",
    shortLabel: "Materialen",
    group: "team",
    icon: Boxes,
  },
  {
    id: "inventory",
    label: "Bedrijfsmiddelen",
    shortLabel: "Inventaris",
    group: "team",
    icon: PackageSearch,
    badge: "2",
  },
  {
    id: "checklists",
    label: "Quality & checklists",
    shortLabel: "Checklists",
    group: "quality",
    icon: ClipboardCheck,
  },
  {
    id: "reports",
    label: "Uitvoeringsrapporten",
    shortLabel: "Rapporten",
    group: "quality",
    icon: Archive,
    badge: "4",
  },
  {
    id: "documents",
    label: "Documenten",
    shortLabel: "Documenten",
    group: "quality",
    icon: FolderOpen,
  },
  {
    id: "quotes",
    label: "Offertes",
    shortLabel: "Offertes",
    group: "finance",
    icon: FileCheck2,
    badge: "3",
  },
  {
    id: "invoices",
    label: "Facturen & betalingen",
    shortLabel: "Facturen",
    group: "finance",
    icon: ReceiptText,
    badge: "6",
  },
  {
    id: "tickets",
    label: "Tickets & verzoeken",
    shortLabel: "Tickets",
    group: "content",
    icon: Inbox,
    badge: "5",
  },
  {
    id: "news",
    label: "Nieuws & berichten",
    shortLabel: "Nieuws",
    group: "content",
    icon: Newspaper,
  },
  {
    id: "website",
    label: "Websitebeheer",
    shortLabel: "Website",
    group: "content",
    icon: Globe2,
  },
  {
    id: "settings",
    label: "Instellingen",
    shortLabel: "Beheer",
    group: "manage",
    icon: Settings2,
  },
];

const titleMap: Record<
  ViewId,
  { title: string; eyebrow: string; description: string }
> = {
  dashboard: {
    title: "Goedemorgen, Danny",
    eyebrow: "Woensdag 2 september",
    description: "Dit vraagt vandaag aandacht bij Veele Services.",
  },
  planning: {
    title: "Planbord",
    eyebrow: "Planning & operatie",
    description: "Capaciteit, opdrachten en reistijd in één rustig dagbeeld.",
  },
  assignments: {
    title: "Opdrachten",
    eyebrow: "Planning & operatie",
    description: "Van aanvraag tot uitvoering, rapportage en facturatie.",
  },
  customers: {
    title: "Klanten",
    eyebrow: "Relaties & locaties",
    description: "Organisaties, contactpersonen, afspraken en klantdossiers.",
  },
  objects: {
    title: "Objecten & locaties",
    eyebrow: "Relaties & locaties",
    description: "Werkplekken, toegang, diensten en uitvoeringscontext.",
  },
  personnel: {
    title: "Medewerkers",
    eyebrow: "Team & middelen",
    description: "Inzetbaarheid, kwalificaties, toegang en personeelsdossiers.",
  },
  leave: {
    title: "Verlof & beschikbaarheid",
    eyebrow: "Team & middelen",
    description: "Beoordeel aanvragen en bewaak de beschikbare capaciteit.",
  },
  materials: {
    title: "Verbruiksmaterialen",
    eyebrow: "Team & middelen",
    description: "Voorraad, verbruik, minima en bestelvoorstellen.",
  },
  inventory: {
    title: "Bedrijfsmiddelen",
    eyebrow: "Team & middelen",
    description: "Uitgifte, QR-identificatie, onderhoud en incidenten.",
  },
  quotes: {
    title: "Offertes",
    eyebrow: "Financieel",
    description: "Voorstellen, goedkeuringen, geldigheid en vervolgacties.",
  },
  reports: {
    title: "Uitvoeringsrapporten",
    eyebrow: "Kwaliteit & bewijs",
    description: "Controleer bewijs, afwijkingen en klantgereedheid.",
  },
  invoices: {
    title: "Facturen & betalingen",
    eyebrow: "Financieel",
    description: "Concepten, verzending, betaalstatus en verzamelruns.",
  },
  documents: {
    title: "Documenten",
    eyebrow: "Kwaliteit & bewijs",
    description: "Eén bibliotheek, gekoppeld aan elk dossier en elke opdracht.",
  },
  tickets: {
    title: "Tickets & verzoeken",
    eyebrow: "Contact & publicatie",
    description: "Klantvragen, interne opvolging en platformondersteuning.",
  },
  news: {
    title: "Nieuws & berichten",
    eyebrow: "Contact & publicatie",
    description: "Publiceer gericht naar klanten en medewerkers.",
  },
  website: {
    title: "Websitebeheer",
    eyebrow: "Contact & publicatie",
    description: "Pagina’s, blogs, formulieren en publicatie in één studio.",
  },
  checklists: {
    title: "Quality & checklists",
    eyebrow: "Kwaliteit & bewijs",
    description: "Herbruikbare controles met object- en opdrachtrangorde.",
  },
  settings: {
    title: "Organisatiebeheer",
    eyebrow: "Instellingen",
    description:
      "Mensen, rechten, huisstijl, automatisering en financiële regels.",
  },
  support: {
    title: "Help & product",
    eyebrow: "Ondersteuning",
    description: "Kennisbank, tickets, releases en roadmap.",
  },
  analysis: {
    title: "UX-analyse & dekking",
    eyebrow: "Ontwerpbesluit",
    description:
      "Wat er structureel verandert, waarom en waar alles terugkomt.",
  },
};

const staff = [
  {
    name: "Sofia de Jong",
    role: "Objectleider",
    initials: "SJ",
    status: "Beschikbaar",
    load: "6u 30m",
  },
  {
    name: "Yassin El Amrani",
    role: "Beveiliger",
    initials: "YE",
    status: "Op locatie",
    load: "7u 15m",
  },
  {
    name: "Naomi Vermeer",
    role: "Schoonmaak",
    initials: "NV",
    status: "Beschikbaar",
    load: "5u 45m",
  },
  {
    name: "Lars Hendriks",
    role: "Allround",
    initials: "LH",
    status: "Pauze",
    load: "6u",
  },
  {
    name: "Mila Smit",
    role: "Inspecteur",
    initials: "MS",
    status: "Beschikbaar",
    load: "4u 30m",
  },
  {
    name: "Rayan Akachar",
    role: "Glasbewassing",
    initials: "RA",
    status: "Verlof",
    load: "0u",
  },
];

const assignmentRows = [
  [
    "FG-2048",
    "Ochtendronde beveiliging",
    "World Forum Den Haag",
    "08:00–12:00",
    "In uitvoering",
    "Yassin El Amrani",
  ],
  [
    "FG-2051",
    "Dagelijkse schoonmaak",
    "Hofstaete Vastgoed",
    "09:00–11:30",
    "Gepland",
    "Naomi Vermeer",
  ],
  [
    "FG-2055",
    "Oplevercontrole verdieping 4",
    "VvE Parkzijde",
    "10:30–12:00",
    "Aandacht",
    "Mila Smit",
  ],
  [
    "FG-2059",
    "Glasbewassing entree",
    "Stadskantoor Rijswijk",
    "13:00–16:00",
    "Gepland",
    "Lars Hendriks",
  ],
  [
    "FG-2062",
    "Avondsluiting",
    "World Forum Den Haag",
    "17:30–20:00",
    "Planbaar",
    "Nog te kiezen",
  ],
];

const customerRows = [
  [
    "Hofstaete Vastgoed",
    "Zakelijk",
    "8 objecten",
    "€ 18.450",
    "Actief",
    "Sanne van Delft",
  ],
  [
    "World Forum Den Haag",
    "Hospitality",
    "3 objecten",
    "€ 32.100",
    "Actief",
    "Karim Ouali",
  ],
  [
    "VvE Parkzijde",
    "VvE",
    "1 object",
    "€ 6.840",
    "Herziening",
    "Marcel Kuiper",
  ],
  [
    "Gemeente Rijswijk",
    "Overheid",
    "5 objecten",
    "€ 24.800",
    "Actief",
    "Ilse van Dam",
  ],
];

const objectRows = [
  [
    "World Forum — entree A",
    "World Forum Den Haag",
    "Churchillplein 10",
    "Beveiliging",
    "Actief",
    "MFA-beveiligd",
  ],
  [
    "Hofstaete — Toren B",
    "Hofstaete Vastgoed",
    "Prinses Beatrixlaan 12",
    "Schoonmaak",
    "Actief",
    "Sleutelkluis",
  ],
  [
    "Parkzijde — wooncomplex",
    "VvE Parkzijde",
    "Parkweg 84",
    "Facilitair",
    "Aandacht",
    "Code + sleutel",
  ],
  [
    "Stadskantoor — publieksplein",
    "Gemeente Rijswijk",
    "Bogaardplein 15",
    "Multi-service",
    "Actief",
    "MFA-beveiligd",
  ],
];

const personnelRows = [
  [
    "Sofia de Jong",
    "Objectleider",
    "Den Haag",
    "6u 30m",
    "5 kwalificaties",
    "Actief",
  ],
  [
    "Yassin El Amrani",
    "Beveiliger",
    "Rijswijk",
    "7u 15m",
    "4 kwalificaties",
    "Actief",
  ],
  [
    "Naomi Vermeer",
    "Schoonmaak",
    "Delft",
    "5u 45m",
    "3 kwalificaties",
    "Actief",
  ],
  ["Lars Hendriks", "Allround", "Den Haag", "6u", "6 kwalificaties", "Actief"],
  [
    "Mila Smit",
    "Inspecteur",
    "Voorburg",
    "4u 30m",
    "5 kwalificaties",
    "Actief",
  ],
];

function findDesign(id: DesignId) {
  return designs.find((design) => design.id === id) ?? designs[0]!;
}

function groupForView(view: ViewId): GroupId {
  return navItems.find((item) => item.id === view)?.group ?? "start";
}

function statusTone(value: string) {
  const normalized = value.toLowerCase();
  if (
    normalized.includes("actief") ||
    normalized.includes("betaald") ||
    normalized.includes("gereed")
  )
    return "success";
  if (
    normalized.includes("aandacht") ||
    normalized.includes("verlopen") ||
    normalized.includes("herzien")
  )
    return "warning";
  if (
    normalized.includes("concept") ||
    normalized.includes("planbaar") ||
    normalized.includes("open")
  )
    return "neutral";
  if (normalized.includes("geblokkeerd") || normalized.includes("afgekeurd"))
    return "danger";
  return "info";
}

function BrandMark({ compact = false }: { compact?: boolean }) {
  return (
    <div
      className={`brand-mark ${compact ? "is-compact" : ""}`}
      aria-label="Fieldgrid"
    >
      <span className="brand-symbol">
        <Blocks aria-hidden="true" />
      </span>
      {!compact && (
        <span className="brand-word">
          <strong>FIELDGRID</strong>
          <small>services operating system</small>
        </span>
      )}
    </div>
  );
}

function LabBar({
  design,
  onDesign,
  onPlanning,
  onAnalysis,
}: {
  design: DesignSpec;
  onDesign: (id: DesignId) => void;
  onPlanning: () => void;
  onAnalysis: () => void;
}) {
  return (
    <header className="lab-bar">
      <div className="lab-identity">
        <span className="lab-dot" />
        <span>
          <strong>Fieldgrid</strong> / backoffice design lab
        </span>
      </div>
      <div
        className="design-switcher"
        role="group"
        aria-label="Kies ontwerpvariant"
      >
        {designs.map((option) => (
          <button
            key={option.id}
            type="button"
            aria-label={`Ontwerp ${option.number}: ${option.name}`}
            className={design.id === option.id ? "is-active" : ""}
            aria-pressed={design.id === option.id}
            onClick={() => onDesign(option.id)}
          >
            <span>{option.number}</span>
            <strong>{option.name}</strong>
          </button>
        ))}
      </div>
      <div className="lab-actions">
        <button
          type="button"
          className="lab-planboard-button"
          aria-label="Test het drag-and-drop-planbord"
          onClick={onPlanning}
        >
          <CalendarDays aria-hidden="true" />
          <span>Test drag & drop</span>
        </button>
        <button
          type="button"
          className="lab-report-button"
          aria-label="Open analyse en functiedekking"
          onClick={onAnalysis}
        >
          <FileText aria-hidden="true" />
          <span>Analyse & dekking</span>
        </button>
      </div>
    </header>
  );
}

function StatusPill({
  children,
  tone,
}: {
  children: React.ReactNode;
  tone?: string;
}) {
  return (
    <span
      className={`status-pill tone-${tone ?? statusTone(String(children))}`}
    >
      <span className="status-dot" />
      {children}
    </span>
  );
}

function NavItemButton({
  item,
  active,
  compact = false,
  onNavigate,
}: {
  item: NavItem;
  active: boolean;
  compact?: boolean;
  onNavigate: (view: ViewId) => void;
}) {
  const Icon = item.icon;
  const button = (
    <button
      type="button"
      className={`nav-item ${active ? "is-active" : ""} ${compact ? "is-compact" : ""}`}
      aria-current={active ? "page" : undefined}
      onClick={() => onNavigate(item.id)}
    >
      <Icon aria-hidden="true" />
      {!compact && <span>{item.label}</span>}
      {!compact && item.badge && <em>{item.badge}</em>}
      {compact && item.badge && <i />}
    </button>
  );

  if (!compact) return button;
  return (
    <Tooltip>
      <TooltipTrigger asChild>{button}</TooltipTrigger>
      <TooltipContent side="right">{item.label}</TooltipContent>
    </Tooltip>
  );
}

function SideNavigation({
  active,
  onNavigate,
}: {
  active: ViewId;
  onNavigate: (view: ViewId) => void;
}) {
  return (
    <nav className="side-navigation" aria-label="Hoofdnavigatie">
      {navGroups.map((group) => {
        const items = navItems.filter((item) => item.group === group.id);
        if (!items.length) return null;
        return (
          <section key={group.id} className="nav-group">
            <h2>{group.label}</h2>
            <div>
              {items.map((item) => (
                <NavItemButton
                  key={item.id}
                  item={item}
                  active={active === item.id}
                  onNavigate={onNavigate}
                />
              ))}
            </div>
          </section>
        );
      })}
    </nav>
  );
}

function UtilityActions({
  onCommand,
  onSupport,
}: {
  onCommand: () => void;
  onSupport: () => void;
}) {
  return (
    <div className="utility-actions">
      <button
        type="button"
        className="system-health"
        onClick={() =>
          toast.success("Alle koppelingen en processen werken normaal.")
        }
      >
        <span /> Alle systemen werken
      </button>
      <button type="button" className="search-trigger" onClick={onCommand}>
        <Search aria-hidden="true" /> <span>Zoeken</span>
        <kbd>⌘ K</kbd>
      </button>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button
            type="button"
            className="icon-button has-notice"
            aria-label="Meldingen openen"
          >
            <Bell aria-hidden="true" />
            <i />
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-80">
          <DropdownMenuLabel>Nieuwe meldingen</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem
            onSelect={() => toast.info("Rapport FG-2055 geopend")}
          >
            Rapport FG-2055 wacht op controle
          </DropdownMenuItem>
          <DropdownMenuItem
            onSelect={() => toast.info("Verlofaanvraag geopend")}
          >
            Nieuwe verlofaanvraag van Rayan
          </DropdownMenuItem>
          <DropdownMenuItem onSelect={() => toast.info("Facturen geopend")}>
            2 facturen vervallen deze week
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button type="button" className="profile-trigger">
            <span className="avatar">DG</span>
            <span>
              <strong>Danny</strong>
              <small>Hoofdbeheerder</small>
            </span>
            <ChevronDown aria-hidden="true" />
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-60">
          <DropdownMenuLabel>Veele Services</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem
            onSelect={() => toast.info("Profielweergave geopend")}
          >
            <UserCog /> Mijn profiel
          </DropdownMenuItem>
          <DropdownMenuItem onSelect={onSupport}>
            <CircleHelp /> Help & kennisbank
          </DropdownMenuItem>
          <DropdownMenuItem
            onSelect={() => toast.info("Organisatie gewisseld")}
          >
            <RefreshCw /> Wissel organisatie
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem>
            <ArrowRight /> Uitloggen
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}

function WorkspaceHeader({
  view,
  design,
  onCreate,
}: {
  view: ViewId;
  design: DesignSpec;
  onCreate: () => void;
}) {
  const meta = titleMap[view];
  const createLabels: Partial<Record<ViewId, string>> = {
    planning: "Nieuwe opdracht",
    assignments: "Nieuwe opdracht",
    customers: "Nieuwe klant",
    objects: "Nieuw object",
    personnel: "Nieuwe medewerker",
    quotes: "Nieuwe offerte",
    invoices: "Nieuwe factuur",
    documents: "Document uploaden",
    tickets: "Nieuw ticket",
    news: "Nieuw bericht",
    website: "Nieuwe pagina",
    checklists: "Nieuwe checklist",
    materials: "Materiaal toevoegen",
    inventory: "Middel toevoegen",
  };
  return (
    <div className="workspace-heading">
      <div>
        <p className="eyebrow">{meta.eyebrow}</p>
        <h1>{meta.title}</h1>
        <p className="page-description">{meta.description}</p>
      </div>
      <div className="heading-actions">
        {view !== "dashboard" && view !== "analysis" && (
          <Button
            variant="outline"
            className="quiet-button"
            onClick={() => toast.success("Weergave is bijgewerkt")}
          >
            <RefreshCw /> Vernieuwen
          </Button>
        )}
        {createLabels[view] && (
          <Button className="primary-button" onClick={onCreate}>
            <Plus /> {createLabels[view]}
          </Button>
        )}
        {view === "dashboard" && (
          <Button className="primary-button" onClick={onCreate}>
            <WandSparkles /> Snel starten
          </Button>
        )}
      </div>
      <div className="concept-caption">
        <span>{design.number}</span>
        <div>
          <strong>{design.name}</strong>
          <small>{design.descriptor}</small>
        </div>
      </div>
    </div>
  );
}

function MobileNavigation({
  open,
  onOpen,
  active,
  onNavigate,
}: {
  open: boolean;
  onOpen: (open: boolean) => void;
  active: ViewId;
  onNavigate: (view: ViewId) => void;
}) {
  return (
    <Sheet open={open} onOpenChange={onOpen}>
      <SheetContent side="left" className="mobile-nav-sheet">
        <SheetHeader>
          <SheetTitle>
            <BrandMark />
          </SheetTitle>
          <SheetDescription>
            Alle werkruimtes van Veele Services
          </SheetDescription>
        </SheetHeader>
        <div className="mobile-nav-scroll">
          <SideNavigation
            active={active}
            onNavigate={(view) => {
              onNavigate(view);
              onOpen(false);
            }}
          />
          <div className="mobile-utility-links">
            <button
              type="button"
              onClick={() => toast.success("Alle systemen werken normaal")}
            >
              <Activity /> Systeemstatus
            </button>
            <button
              type="button"
              onClick={() => toast.info("2 nieuwe meldingen geopend")}
            >
              <Bell /> Meldingen <Badge variant="secondary">2</Badge>
            </button>
            <button
              type="button"
              onClick={() => toast.info("Profielweergave geopend")}
            >
              <UserCog /> Mijn profiel
            </button>
            <button
              type="button"
              onClick={() => toast.info("Organisatiekiezer geopend")}
            >
              <RefreshCw /> Wissel organisatie
            </button>
            <button
              type="button"
              onClick={() => {
                onNavigate("support");
                onOpen(false);
              }}
            >
              <CircleHelp /> Help & kennisbank
            </button>
            <button
              type="button"
              onClick={() => {
                onNavigate("analysis");
                onOpen(false);
              }}
            >
              <FileText /> Analyse & dekking
            </button>
          </div>
        </div>
        <SheetFooter>
          <StatusPill tone="success">Veilige actieve sessie</StatusPill>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}

function GroupRail({
  activeGroup,
  onGroup,
  dark = false,
}: {
  activeGroup: GroupId;
  onGroup: (group: GroupId) => void;
  dark?: boolean;
}) {
  return (
    <nav
      className={`group-rail ${dark ? "is-dark" : ""}`}
      aria-label="Domeinen"
    >
      {navGroups.map((group) => {
        const Icon = group.icon;
        const count = navItems.filter(
          (item) => item.group === group.id && item.badge,
        ).length;
        return (
          <Tooltip key={group.id}>
            <TooltipTrigger asChild>
              <button
                type="button"
                className={activeGroup === group.id ? "is-active" : ""}
                aria-label={group.label}
                aria-pressed={activeGroup === group.id}
                onClick={() => onGroup(group.id)}
              >
                <Icon aria-hidden="true" />
                {count > 0 && <i />}
              </button>
            </TooltipTrigger>
            <TooltipContent side="right">{group.label}</TooltipContent>
          </Tooltip>
        );
      })}
    </nav>
  );
}

function ModuleIndex({
  group,
  active,
  onNavigate,
}: {
  group: GroupId;
  active: ViewId;
  onNavigate: (view: ViewId) => void;
}) {
  const groupMeta = navGroups.find((item) => item.id === group)!;
  const items = navItems.filter((item) => item.group === group);
  return (
    <aside className="module-index">
      <div className="module-index-head">
        <span>Werkruimte</span>
        <h2>{groupMeta.label}</h2>
        <p>
          {group === "operation"
            ? "Plan, verdeel en volg het werk van vandaag."
            : "Alles wat bij dit domein hoort, logisch bijeen."}
        </p>
      </div>
      <nav aria-label={`${groupMeta.label} onderdelen`}>
        {items.map((item, index) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              type="button"
              className={active === item.id ? "is-active" : ""}
              onClick={() => onNavigate(item.id)}
            >
              <span>{String(index + 1).padStart(2, "0")}</span>
              <Icon aria-hidden="true" />
              <strong>{item.label}</strong>
              {item.badge && <em>{item.badge}</em>}
              <ChevronRight aria-hidden="true" />
            </button>
          );
        })}
      </nav>
      <div className="module-index-foot">
        <ShieldCheck />
        <span>
          <strong>Veilige omgeving</strong>
          <small>Actieve sessie · MFA aan</small>
        </span>
      </div>
    </aside>
  );
}

function TopDomainNavigation({
  active,
  onNavigate,
}: {
  active: ViewId;
  onNavigate: (view: ViewId) => void;
}) {
  return (
    <nav className="top-domain-navigation" aria-label="Werkruimtes">
      {navGroups.map((group) => {
        const groupItems = navItems.filter((item) => item.group === group.id);
        const activeWithin = groupItems.some((item) => item.id === active);
        const Icon = group.icon;
        return (
          <DropdownMenu key={group.id}>
            <DropdownMenuTrigger asChild>
              <button type="button" className={activeWithin ? "is-active" : ""}>
                <Icon aria-hidden="true" />
                <span>{group.compactLabel}</span>
                <ChevronDown aria-hidden="true" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-64">
              <DropdownMenuLabel>{group.label}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {groupItems.map((item) => {
                const ItemIcon = item.icon;
                return (
                  <DropdownMenuItem
                    key={item.id}
                    onSelect={() => onNavigate(item.id)}
                  >
                    <ItemIcon /> {item.label}
                    {item.badge && (
                      <Badge className="ml-auto" variant="secondary">
                        {item.badge}
                      </Badge>
                    )}
                  </DropdownMenuItem>
                );
              })}
            </DropdownMenuContent>
          </DropdownMenu>
        );
      })}
    </nav>
  );
}

function ContextRail({
  view,
  onNavigate,
}: {
  view: ViewId;
  onNavigate: (view: ViewId) => void;
}) {
  return (
    <aside className="context-rail">
      <div className="context-date">
        <span>SEP</span>
        <strong>02</strong>
        <small>WOENSDAG</small>
      </div>
      <section>
        <p className="rail-label">Live operatie</p>
        <div className="live-stat">
          <span className="pulse" />
          <strong>4</strong>
          <small>opdrachten actief</small>
        </div>
        <div className="mini-progress">
          <i style={{ width: "68%" }} />
        </div>
        <p className="rail-note">18 van 24 geplande uren gestart</p>
      </section>
      <section>
        <p className="rail-label">Volgende</p>
        <button
          type="button"
          className="rail-event"
          onClick={() => onNavigate("planning")}
        >
          <span>10:30</span>
          <strong>Oplevercontrole</strong>
          <small>VvE Parkzijde</small>
        </button>
        <button
          type="button"
          className="rail-event"
          onClick={() => onNavigate("assignments")}
        >
          <span>13:00</span>
          <strong>Glasbewassing</strong>
          <small>Stadskantoor</small>
        </button>
      </section>
      <section>
        <p className="rail-label">Context</p>
        <button
          type="button"
          className="rail-link"
          onClick={() =>
            onNavigate(view === "planning" ? "assignments" : "planning")
          }
        >
          <Route /> {view === "planning" ? "Open opdrachten" : "Open planbord"}
          <ArrowRight />
        </button>
        <button
          type="button"
          className="rail-link"
          onClick={() => onNavigate("reports")}
        >
          <ClipboardCheck /> 4 rapporten
          <ArrowRight />
        </button>
      </section>
    </aside>
  );
}

type ShellProps = {
  design: DesignSpec;
  active: ViewId;
  activeGroup: GroupId;
  onNavigate: (view: ViewId) => void;
  onGroup: (group: GroupId) => void;
  onCommand: () => void;
  onSupport: () => void;
  onCreate: () => void;
  onMobileNav: () => void;
  children: React.ReactNode;
};

function AppShell(props: ShellProps) {
  const {
    design,
    active,
    activeGroup,
    onNavigate,
    onGroup,
    onCommand,
    onSupport,
    onCreate,
    onMobileNav,
    children,
  } = props;
  const mobileContext =
    design.id === "fieldflow"
      ? "Veele Services"
      : design.id === "northstar"
        ? `Suite · ${titleMap[active].eyebrow}`
        : design.id === "atlas"
          ? `WB / ${activeGroup.toUpperCase()}`
          : design.id === "nocturne"
            ? "LIVE · 09:42"
            : "WO 02 · JOURNAAL";
  const commonMobile = (
    <div className={`mobile-app-header mobile-${design.id}`}>
      <button type="button" aria-label="Navigatie openen" onClick={onMobileNav}>
        <Menu />
      </button>
      <div className="mobile-brand-slot">
        <BrandMark compact={design.id === "atlas" || design.id === "nocturne"} />
        <span>{mobileContext}</span>
      </div>
      <button type="button" aria-label="Zoeken" onClick={onCommand}>
        <Search />
      </button>
    </div>
  );
  const content = (
    <main className="workspace-scroll" id="main-content">
      <WorkspaceHeader view={active} design={design} onCreate={onCreate} />
      <div className="page-stage">{children}</div>
    </main>
  );

  if (design.shell === "sidebar") {
    return (
      <div className="fg-app shell-sidebar">
        {commonMobile}
        <aside className="primary-sidebar">
          <div className="sidebar-brand">
            <BrandMark />
          </div>
          <SideNavigation active={active} onNavigate={onNavigate} />
          <div className="sidebar-footer">
            <button type="button" onClick={onSupport}>
              <CircleHelp /> Help & kennisbank
            </button>
            <div className="tenant-card">
              <span>VS</span>
              <div>
                <strong>Veele Services</strong>
                <small>Enterprise omgeving</small>
              </div>
              <ChevronDown />
            </div>
          </div>
        </aside>
        <section className="workspace-frame">
          <div className="app-utility-bar">
            <div className="crumb">
              <span>Veele Services</span>
              <ChevronRight />
              {titleMap[active].eyebrow}
            </div>
            <UtilityActions onCommand={onCommand} onSupport={onSupport} />
          </div>
          {content}
        </section>
      </div>
    );
  }

  if (design.shell === "topbar") {
    return (
      <div className="fg-app shell-topbar">
        {commonMobile}
        <header className="northstar-header">
          <BrandMark />
          <TopDomainNavigation active={active} onNavigate={onNavigate} />
          <UtilityActions onCommand={onCommand} onSupport={onSupport} />
        </header>
        <div className="northstar-context">
          <div>
            <span className="context-mark" /> Veele Services <ChevronRight />{" "}
            {titleMap[active].eyebrow}
          </div>
          <div>
            <button type="button" onClick={() => onNavigate("support")}>
              <CircleHelp /> Hulp
            </button>
            <button type="button">
              <PanelLeftClose /> Focus
            </button>
          </div>
        </div>
        {content}
      </div>
    );
  }

  if (design.shell === "splitrail") {
    return (
      <div className="fg-app shell-splitrail">
        {commonMobile}
        <aside className="atlas-rail">
          <BrandMark compact />
          <GroupRail activeGroup={activeGroup} onGroup={onGroup} />
          <button
            type="button"
            className="rail-help"
            aria-label="Help"
            onClick={onSupport}
          >
            <CircleHelp />
          </button>
          <span className="atlas-avatar">DG</span>
        </aside>
        <ModuleIndex
          group={activeGroup}
          active={active}
          onNavigate={onNavigate}
        />
        <section className="workspace-frame">
          <div className="app-utility-bar">
            <button type="button" className="atlas-command" onClick={onCommand}>
              <CommandIcon /> Spring naar… <kbd>⌘K</kbd>
            </button>
            <UtilityActions onCommand={onCommand} onSupport={onSupport} />
          </div>
          {content}
        </section>
      </div>
    );
  }

  if (design.shell === "command") {
    const groupMeta = navGroups.find((group) => group.id === activeGroup)!;
    const commandItems = navItems.filter((item) => item.group === activeGroup);
    return (
      <div className="fg-app shell-command">
        {commonMobile}
        <aside className="nocturne-rail">
          <BrandMark compact />
          <GroupRail activeGroup={activeGroup} onGroup={onGroup} dark />
          <button
            type="button"
            className="command-launch"
            aria-label="Commandopalet"
            onClick={onCommand}
          >
            <CommandIcon />
          </button>
          <span className="nocturne-avatar">DG</span>
        </aside>
        <section className="command-workspace">
          <div className="nocturne-topbar">
            <div>
              <span className="pulse" /> Live operatie <em>02 SEP · 09:42</em>
            </div>
            <UtilityActions onCommand={onCommand} onSupport={onSupport} />
          </div>
          <nav className="nocturne-module-strip" aria-label={groupMeta.label}>
            <span>{groupMeta.label}</span>
            <div>
              {commandItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    type="button"
                    className={active === item.id ? "is-active" : ""}
                    onClick={() => onNavigate(item.id)}
                  >
                    <Icon /> {item.label}
                    {item.badge && <em>{item.badge}</em>}
                  </button>
                );
              })}
            </div>
          </nav>
          {content}
        </section>
        <ContextRail view={active} onNavigate={onNavigate} />
      </div>
    );
  }

  return (
    <div className="fg-app shell-editorial">
      {commonMobile}
      <header className="ledger-header">
        <BrandMark />
        <div className="ledger-title">
          <span>Operationeel journaal</span>
          <strong>Veele Services</strong>
        </div>
        <UtilityActions onCommand={onCommand} onSupport={onSupport} />
      </header>
      <TopDomainNavigation active={active} onNavigate={onNavigate} />
      <div className="ledger-body">
        <ModuleIndex
          group={activeGroup}
          active={active}
          onNavigate={onNavigate}
        />
        {content}
      </div>
    </div>
  );
}

function Panel({
  title,
  eyebrow,
  action,
  className = "",
  children,
}: {
  title?: string;
  eyebrow?: string;
  action?: React.ReactNode;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <section className={`surface-panel ${className}`}>
      {(title || eyebrow || action) && (
        <div className="panel-heading">
          <div>
            {eyebrow && <p>{eyebrow}</p>}
            {title && <h2>{title}</h2>}
          </div>
          {action && <div className="panel-action">{action}</div>}
        </div>
      )}
      {children}
    </section>
  );
}

function MetricCard({
  label,
  value,
  detail,
  icon: Icon,
  tone,
  trend,
}: {
  label: string;
  value: string;
  detail: string;
  icon: LucideIcon;
  tone: string;
  trend?: string;
}) {
  return (
    <article className={`metric-card metric-${tone}`}>
      <div className="metric-icon">
        <Icon />
      </div>
      <div className="metric-copy">
        <span>{label}</span>
        <strong>{value}</strong>
        <small>{detail}</small>
      </div>
      {trend && (
        <em>
          <TrendingUp /> {trend}
        </em>
      )}
      <i className="metric-orbit" />
    </article>
  );
}

function PageToolbar({
  placeholder = "Zoeken…",
  result = "",
  onFilter,
  children,
}: {
  placeholder?: string;
  result?: string;
  onFilter: () => void;
  children?: React.ReactNode;
}) {
  return (
    <div className="page-toolbar">
      <label className="toolbar-search">
        <Search />
        <span className="sr-only">Zoeken</span>
        <input placeholder={placeholder} />
      </label>
      <div className="toolbar-controls">
        {children}
        <Button variant="outline" onClick={onFilter}>
          <SlidersHorizontal /> Filters <span className="filter-count">2</span>
        </Button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline">
              <Columns3 /> Weergave
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Weergave aanpassen</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onSelect={() => toast.success("Compacte dichtheid gekozen")}
            >
              Compact
            </DropdownMenuItem>
            <DropdownMenuItem
              onSelect={() => toast.success("Comfortabele dichtheid gekozen")}
            >
              Comfortabel
            </DropdownMenuItem>
            <DropdownMenuItem
              onSelect={() => toast.success("Kolommen aangepast")}
            >
              Kolommen kiezen
            </DropdownMenuItem>
            <DropdownMenuItem
              onSelect={() => toast.success("Weergave opgeslagen")}
            >
              Weergave opslaan
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
      {result && <span className="result-count">{result}</span>}
    </div>
  );
}

function RowActions({
  onOpen,
  duplicateLabel = "Dupliceren",
  archiveLabel = "Archiveren",
}: {
  onOpen?: () => void;
  duplicateLabel?: string;
  archiveLabel?: string;
}) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button type="button" className="row-menu" aria-label="Meer acties">
          <MoreHorizontal />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-52">
        <DropdownMenuItem onSelect={onOpen}>
          <ExternalLink /> Openen
        </DropdownMenuItem>
        <DropdownMenuItem onSelect={() => toast.info("Bewerkvenster geopend")}>
          <Pencil /> Bewerken
        </DropdownMenuItem>
        <DropdownMenuItem onSelect={() => toast.success("Kopie is aangemaakt")}>
          <Copy /> {duplicateLabel}
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem
          onSelect={() =>
            toast.warning("Archiveren vraagt altijd om bevestiging")
          }
        >
          <Archive /> {archiveLabel}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function AttentionBanner({
  onNavigate,
}: {
  onNavigate: (view: ViewId) => void;
}) {
  return (
    <div className="attention-banner">
      <span className="attention-icon">
        <AlertCircle />
      </span>
      <div>
        <small>Aandacht nodig</small>
        <strong>
          Rapport FG-2055 blokkeert de facturatieronde van vandaag
        </strong>
        <p>De opleverfoto ontbreekt en moet vóór 12:00 worden aangevuld.</p>
      </div>
      <StatusPill tone="warning">Over 2 uur</StatusPill>
      <Button variant="outline" onClick={() => onNavigate("reports")}>
        Controleren <ArrowRight />
      </Button>
    </div>
  );
}

function NorthstarDashboard({
  onNavigate,
  onCreate,
}: {
  onNavigate: (view: ViewId) => void;
  onCreate: () => void;
}) {
  const performance = [
    ["Regio Den Haag", "18 / 20 bezet", "90%", "Op schema"],
    ["Regio Rijswijk", "8 / 10 bezet", "80%", "2 open"],
    ["Regio Delft", "6 / 9 bezet", "67%", "Aandacht"],
  ];
  return (
    <div className="page-flow northstar-dashboard">
      <section className="northstar-executive-banner">
        <div>
          <span>Operationele briefing · woensdag 2 september</span>
          <strong>De operatie loopt gezond; twee besluiten vragen aandacht.</strong>
          <p>
            36 van 44 beschikbare uren zijn gepland. De grootste winst zit in
            Delft en de rapportcontrole vóór de facturatieronde.
          </p>
        </div>
        <div>
          <Button variant="outline" onClick={onCreate}>
            <Plus /> Nieuwe opdracht
          </Button>
          <Button className="primary-button" onClick={() => onNavigate("planning")}>
            <CalendarDays /> Open dispatch center
          </Button>
        </div>
      </section>
      <section className="northstar-kpi-ribbon" aria-label="Kernprestaties">
        {[
          ["Live opdrachten", "4", "12 vandaag", Activity],
          ["Inzetbaar", "18 / 22", "82% capaciteit", Users],
          ["Open besluiten", "6", "2 urgent", AlertCircle],
          ["Factureerbaar", "€ 12.840", "+8,4%", WalletCards],
        ].map(([label, value, detail, Icon]) => {
          const I = Icon as LucideIcon;
          return (
            <button key={String(label)} type="button" onClick={() => onNavigate("reports")}>
              <I />
              <span>
                <small>{String(label)}</small>
                <strong>{String(value)}</strong>
                <em>{String(detail)}</em>
              </span>
              <ChevronRight />
            </button>
          );
        })}
      </section>
      <div className="northstar-command-grid">
        <section className="northstar-performance-board">
          <header>
            <div>
              <span>Capaciteit per werkgebied</span>
              <h2>Performance matrix</h2>
            </div>
            <button type="button" onClick={() => onNavigate("personnel")}>
              Teamcapaciteit <ArrowRight />
            </button>
          </header>
          <div className="northstar-performance-head">
            <span>Werkgebied</span>
            <span>Bezetting</span>
            <span>Benutting</span>
            <span>Status</span>
          </div>
          {performance.map((row, index) => (
            <button key={row[0]} type="button" onClick={() => onNavigate("planning")}>
              <strong>{row[0]}</strong>
              <span>{row[1]}</span>
              <span className="northstar-load">
                <i style={{ width: row[2] }} />
                <em>{row[2]}</em>
              </span>
              <StatusPill tone={index === 2 ? "warning" : "success"}>
                {row[3]}
              </StatusPill>
            </button>
          ))}
        </section>
        <aside className="northstar-decision-deck">
          <header>
            <span>Besluitvorming</span>
            <h2>Nu behandelen</h2>
          </header>
          {[
            ["3 verlofaanvragen", "2 beïnvloeden de planning", leaveIcon(CalendarClock), "leave"],
            ["Rapport FG-2055", "blokkeert facturatie", leaveIcon(FileCheck2), "reports"],
            ["2 defecte middelen", "uitgifte tijdelijk gestopt", leaveIcon(HardHat), "inventory"],
          ].map(([title, detail, icon, target]) => (
            <button key={String(title)} type="button" onClick={() => onNavigate(target as ViewId)}>
              {icon}
              <span>
                <strong>{String(title)}</strong>
                <small>{String(detail)}</small>
              </span>
              <ChevronRight />
            </button>
          ))}
        </aside>
      </div>
      <section className="northstar-workspace-dock">
        <div>
          <span>Opgeslagen werkruimtes</span>
          <strong>Spring direct naar een vaste bedrijfsweergave</strong>
        </div>
        {[
          ["Ochtenddispatch", "Planning", "planning"],
          ["Contractrisico", "Klanten", "customers"],
          ["Facturatieronde", "Financieel", "invoices"],
        ].map(([title, meta, target]) => (
          <button key={title} type="button" onClick={() => onNavigate(target as ViewId)}>
            <span>{meta}</span>
            <strong>{title}</strong>
            <ArrowRight />
          </button>
        ))}
      </section>
    </div>
  );
}

function leaveIcon(Icon: LucideIcon) {
  return (
    <span className="dashboard-inline-icon">
      <Icon />
    </span>
  );
}

function AtlasDashboard({
  onNavigate,
  onCreate,
}: {
  onNavigate: (view: ViewId) => void;
  onCreate: () => void;
}) {
  return (
    <div className="page-flow atlas-dashboard">
      <div className="atlas-workbench-dashboard">
        <section className="atlas-inbox-pane">
          <header>
            <span>01 / WERKVOORRAAD</span>
            <h2>Mijn inbox</h2>
            <StatusPill tone="warning">6 open</StatusPill>
          </header>
          {[
            ["09:18", "Rapport aanvullen", "FG-2055 · foto ontbreekt", "reports"],
            ["09:05", "Verlof beoordelen", "Rayan · vrijdag", "leave"],
            ["08:44", "Offerte opvolgen", "VvE Parkzijde", "quotes"],
            ["08:21", "Middel blokkeren", "Schrobmachine M-028", "inventory"],
          ].map((item, index) => (
            <button
              key={item[1]}
              type="button"
              className={index === 0 ? "is-active" : ""}
              onClick={() => onNavigate(item[3] as ViewId)}
            >
              <time>{item[0]}</time>
              <span>
                <strong>{item[1]}</strong>
                <small>{item[2]}</small>
              </span>
              <ChevronRight />
            </button>
          ))}
          <button type="button" className="atlas-new-record" onClick={onCreate}>
            <Plus /> Nieuw werkitem
          </button>
        </section>
        <section className="atlas-focus-pane">
          <header>
            <div>
              <span>02 / ACTIEF DOSSIER</span>
              <h2>Oplevercontrole verdieping 4</h2>
              <p>FG-2055 · VvE Parkzijde · vandaag 10:30–12:00</p>
            </div>
            <StatusPill tone="warning">Aandacht</StatusPill>
          </header>
          <div className="atlas-record-progress">
            {[
              ["Opdracht", "Gereed", true],
              ["Planning", "Mila Smit", true],
              ["Uitvoering", "Afgerond 11:52", true],
              ["Bewijs", "1 foto ontbreekt", false],
              ["Facturatie", "Geblokkeerd", false],
            ].map(([label, value, done], index) => (
              <button key={String(label)} type="button" onClick={() => onNavigate("reports")}>
                <span className={done ? "is-done" : ""}>{String(index + 1).padStart(2, "0")}</span>
                <span className="atlas-progress-copy">
                  <small>{String(label)}</small>
                  <strong>{String(value)}</strong>
                </span>
                {done ? <CheckCircle2 /> : <AlertCircle />}
              </button>
            ))}
          </div>
          <div className="atlas-evidence-placeholder">
            <FileCheck2 />
            <span>
              <strong>Opleverfoto toevoegen</strong>
              <small>JPEG/PNG · automatisch gekoppeld aan rapport FG-2055</small>
            </span>
            <Button variant="outline" onClick={() => onNavigate("documents")}>
              Bestand kiezen
            </Button>
          </div>
        </section>
        <aside className="atlas-inspector-pane">
          <header>
            <span>03 / INSPECTOR</span>
            <h2>Context</h2>
          </header>
          <dl>
            <div><dt>Klant</dt><dd>VvE Parkzijde</dd></div>
            <div><dt>Object</dt><dd>Wooncomplex</dd></div>
            <div><dt>Medewerker</dt><dd>Mila Smit</dd></div>
            <div><dt>Contractregel</dt><dd>Foto verplicht</dd></div>
            <div><dt>Deadline</dt><dd>Vandaag 12:30</dd></div>
          </dl>
          <div className="atlas-inspector-actions">
            <Button className="primary-button" onClick={() => onNavigate("reports")}>
              Rapport afronden
            </Button>
            <Button variant="outline" onClick={() => onNavigate("planning")}>
              Open in planbord
            </Button>
          </div>
        </aside>
      </div>
      <section className="atlas-status-console">
        <span>SYS / 09:42:18</span>
        <strong>Alle koppelingen operationeel</strong>
        <em>4 live · 8 planbaar · 1 blokkade · 0 synchronisatiefouten</em>
      </section>
    </div>
  );
}

function NocturneDashboard({
  onNavigate,
}: {
  onNavigate: (view: ViewId) => void;
}) {
  return (
    <div className="page-flow nocturne-dashboard">
      <section className="nocturne-live-canvas">
        <header>
          <div>
            <span className="pulse" /> LIVE OPERATIE
            <small>laatste sync 09:42:18</small>
          </div>
          <button type="button" onClick={() => onNavigate("planning")}>
            Volledig planbord <ArrowRight />
          </button>
        </header>
        <div className="nocturne-live-grid">
          <div className="nocturne-lane-labels">
            {staff.slice(0, 4).map((person) => (
              <span key={person.name}><i />{person.name}<small>{person.role}</small></span>
            ))}
          </div>
          <div className="nocturne-mini-board">
            <div className="command-hour-line"><span>08</span><span>10</span><span>12</span><span>14</span><span>16</span><span>18</span></div>
            {[
              ["8%", "26%", "World Forum", "blue"],
              ["3%", "34%", "Entree A", "mint"],
              ["19%", "24%", "Hofstaete", "aqua"],
              ["49%", "31%", "Stadskantoor", "orange"],
            ].map(([left, width, title, color], index) => (
              <button
                key={title}
                type="button"
                className={`command-block color-${color}`}
                style={{ left, width, top: `${62 + index * 74}px` }}
                onClick={() => onNavigate("planning")}
              >
                <span>{index % 2 ? "GEPLAND" : "LIVE"}</span>
                <strong>{title}</strong>
              </button>
            ))}
            <i className="command-now-line" />
          </div>
        </div>
      </section>
      <div className="nocturne-command-row">
        <section className="nocturne-alert-stack">
          <header><span>UITZONDERINGEN</span><strong>3 signalen</strong></header>
          {[
            ["P1", "Bewijs ontbreekt", "FG-2055 · facturatie geblokkeerd", "reports"],
            ["P2", "Reistijd krap", "Yassin · 15 minuten buffer", "planning"],
            ["P3", "Middel defect", "Schrobmachine M-028", "inventory"],
          ].map((item) => (
            <button key={item[1]} type="button" onClick={() => onNavigate(item[3] as ViewId)}>
              <span>{item[0]}</span><span className="nocturne-alert-copy"><strong>{item[1]}</strong><small>{item[2]}</small></span><ChevronRight />
            </button>
          ))}
        </section>
        <section className="nocturne-capacity-matrix">
          <header><span>CAPACITEIT</span><strong>36u / 44u gepland</strong></header>
          <div>
            {[82, 91, 73, 88, 64, 45, 22].map((value, index) => (
              <button key={index} type="button" onClick={() => onNavigate("personnel")}>
                <i style={{ height: `${value}%` }} /><span>{["MA", "DI", "WO", "DO", "VR", "ZA", "ZO"][index]}</span><em>{value}%</em>
              </button>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}

function LedgerDashboard({
  onNavigate,
  onCreate,
}: {
  onNavigate: (view: ViewId) => void;
  onCreate: () => void;
}) {
  return (
    <div className="page-flow ledger-dashboard">
      <article className="ledger-morning-brief">
        <header>
          <span>WOENSDAG</span>
          <strong>02</strong>
          <small>SEPTEMBER 2026 · EDITIE 036</small>
        </header>
        <div className="ledger-lead-story">
          <p className="ledger-kicker">DE DAG IN ÉÉN OOGOPSLAG</p>
          <h2>De bezetting is gezond, maar één ontbrekend bewijsstuk houdt de dagafsluiting tegen.</h2>
          <p>
            Vier opdrachten zijn gestart en achttien medewerkers zijn inzetbaar.
            De rapportcontrole van Parkzijde heeft prioriteit vóór de financiële
            ronde van vanmiddag.
          </p>
          <button type="button" onClick={() => onNavigate("reports")}>
            Lees het operationele dossier <ArrowRight />
          </button>
        </div>
        <aside className="ledger-figures">
          {[
            ["04", "op locatie"],
            ["08", "nog te plannen"],
            ["82%", "benutting"],
            ["€12.840", "factureerbaar"],
          ].map(([value, label]) => (
            <div key={label}><strong>{value}</strong><span>{label}</span></div>
          ))}
        </aside>
      </article>
      <div className="ledger-day-grid">
        <section className="ledger-daybook">
          <header><span>II</span><div><small>DAGBOEK</small><h2>Planning en gebeurtenissen</h2></div><button type="button" onClick={() => onNavigate("planning")}>Open planbord</button></header>
          {[
            ["08:00", "Ochtendronde beveiliging", "World Forum", "In uitvoering"],
            ["09:00", "Dagelijkse schoonmaak", "Hofstaete", "Op locatie"],
            ["10:30", "Oplevercontrole verdieping 4", "Parkzijde", "Aandacht"],
            ["13:00", "Glasbewassing entree", "Stadskantoor", "Gepland"],
            ["17:30", "Avondsluiting", "World Forum", "Nog te bezetten"],
          ].map((row, index) => (
            <button key={row[0]} type="button" onClick={() => onNavigate(index === 4 ? "assignments" : "planning")}>
              <time>{row[0]}</time><span><strong>{row[1]}</strong><small>{row[2]}</small></span><em>{row[3]}</em><ArrowRight />
            </button>
          ))}
        </section>
        <aside className="ledger-priorities">
          <header><small>III · PRIORITEITEN</small><h2>Voor sluiting behandelen</h2></header>
          {[
            ["01", "Rapport FG-2055", "Bewijs aanvullen", "reports"],
            ["02", "Drie verlofaanvragen", "Capaciteit toetsen", "leave"],
            ["03", "Offerte Parkzijde", "Voor vrijdag opvolgen", "quotes"],
          ].map((item) => (
            <button key={item[0]} type="button" onClick={() => onNavigate(item[3] as ViewId)}>
              <span>{item[0]}</span><span className="ledger-priority-copy"><strong>{item[1]}</strong><small>{item[2]}</small></span><ArrowRight />
            </button>
          ))}
          <Button className="primary-button" onClick={onCreate}><Plus /> Nieuw werkstuk</Button>
        </aside>
      </div>
    </div>
  );
}

function DashboardPage({
  design,
  onNavigate,
  onCreate,
}: {
  design: DesignId;
  onNavigate: (view: ViewId) => void;
  onCreate: () => void;
}) {
  if (design === "northstar")
    return <NorthstarDashboard onNavigate={onNavigate} onCreate={onCreate} />;
  if (design === "atlas")
    return <AtlasDashboard onNavigate={onNavigate} onCreate={onCreate} />;
  if (design === "nocturne")
    return <NocturneDashboard onNavigate={onNavigate} />;
  if (design === "ledger")
    return <LedgerDashboard onNavigate={onNavigate} onCreate={onCreate} />;
  return (
    <div className="page-flow dashboard-page">
      <div className="metric-grid">
        <MetricCard
          label="Actief op locatie"
          value="4"
          detail="van 12 opdrachten vandaag"
          icon={Activity}
          tone="teal"
          trend="op schema"
        />
        <MetricCard
          label="Beschikbaar"
          value="18 / 22"
          detail="medewerkers inzetbaar"
          icon={Users}
          tone="blue"
        />
        <MetricCard
          label="Nog te plannen"
          value="8"
          detail="6 hebben een voorkeursmatch"
          icon={CalendarClock}
          tone="orange"
        />
        <MetricCard
          label="Factureerbaar"
          value="€ 12.840"
          detail="23 goedgekeurde rapporten"
          icon={WalletCards}
          tone="violet"
          trend="+8,4%"
        />
      </div>
      <AttentionBanner onNavigate={onNavigate} />
      <div className="dashboard-main-grid">
        <Panel
          eyebrow="Live operatie"
          title="Vandaag op de vloer"
          action={
            <button
              type="button"
              className="text-action"
              onClick={() => onNavigate("planning")}
            >
              Open planbord <ArrowRight />
            </button>
          }
          className="operation-stream"
        >
          <div className="stream-list">
            {[
              [
                "08:00",
                "Ochtendronde beveiliging",
                "World Forum",
                "In uitvoering",
                "YE",
              ],
              [
                "09:00",
                "Dagelijkse schoonmaak",
                "Hofstaete · Toren B",
                "Op locatie",
                "NV",
              ],
              [
                "10:30",
                "Oplevercontrole verdieping 4",
                "VvE Parkzijde",
                "Aandacht",
                "MS",
              ],
              [
                "13:00",
                "Glasbewassing entree",
                "Stadskantoor",
                "Gepland",
                "LH",
              ],
              ["17:30", "Avondsluiting", "World Forum", "Nog te bezetten", "+"],
            ].map((row, index) => (
              <button
                type="button"
                className="stream-row"
                key={row[0]}
                onClick={() =>
                  onNavigate(index === 4 ? "assignments" : "planning")
                }
              >
                <time>{row[0]}</time>
                <i className={`stream-line line-${index}`} />
                <span className="stream-avatar">{row[4]}</span>
                <span className="stream-copy">
                  <strong>{row[1]}</strong>
                  <small>
                    <MapPin /> {row[2]}
                  </small>
                </span>
                <StatusPill>{row[3]}</StatusPill>
                <ChevronRight />
              </button>
            ))}
          </div>
        </Panel>
        <div className="dashboard-side-stack">
          <Panel
            eyebrow="Werkvoorraad"
            title="Wat vraagt een besluit?"
            action={
              <button type="button" className="icon-button">
                <MoreHorizontal />
              </button>
            }
          >
            <div className="decision-list">
              <button type="button" onClick={() => onNavigate("leave")}>
                <span className="decision-icon orange">
                  <CalendarClock />
                </span>
                <span className="decision-copy">
                  <strong>3 verlofaanvragen</strong>
                  <small>2 raken de capaciteit</small>
                </span>
                <ChevronRight />
              </button>
              <button type="button" onClick={() => onNavigate("quotes")}>
                <span className="decision-icon blue">
                  <FileCheck2 />
                </span>
                <span className="decision-copy">
                  <strong>3 offertes verlopen</strong>
                  <small>vóór vrijdag opvolgen</small>
                </span>
                <ChevronRight />
              </button>
              <button type="button" onClick={() => onNavigate("inventory")}>
                <span className="decision-icon red">
                  <HardHat />
                </span>
                <span className="decision-copy">
                  <strong>2 middelen defect</strong>
                  <small>uitgifte geblokkeerd</small>
                </span>
                <ChevronRight />
              </button>
            </div>
          </Panel>
          <Panel eyebrow="Snel starten" title="Maak of registreer">
            <div className="quick-actions">
              <button type="button" onClick={onCreate}>
                <Plus />
                <span>
                  <strong>Nieuwe opdracht</strong>
                  <small>stapsgewijs aanmaken</small>
                </span>
                <ArrowRight />
              </button>
              <button type="button" onClick={() => onNavigate("customers")}>
                <UserPlus />
                <span>
                  <strong>Klant toevoegen</strong>
                  <small>met eerste object</small>
                </span>
                <ArrowRight />
              </button>
              <button type="button" onClick={() => onNavigate("documents")}>
                <UploadCloud />
                <span>
                  <strong>Document uploaden</strong>
                  <small>direct koppelen</small>
                </span>
                <ArrowRight />
              </button>
            </div>
          </Panel>
        </div>
      </div>
      <div className="dashboard-bottom-grid">
        <Panel
          eyebrow="Capaciteit"
          title="Bezetting deze week"
          action={<StatusPill tone="success">82% gezond</StatusPill>}
        >
          <div className="capacity-chart" aria-label="Capaciteit per dag">
            {[72, 88, 82, 96, 76, 40, 22].map((value, index) => (
              <div key={index}>
                <span style={{ height: `${value}%` }} />
                <small>
                  {["Ma", "Di", "Wo", "Do", "Vr", "Za", "Zo"][index]}
                </small>
              </div>
            ))}
          </div>
        </Panel>
        <Panel
          eyebrow="Dossiers"
          title="Recent geopend"
          action={
            <button
              type="button"
              className="text-action"
              onClick={() => onNavigate("customers")}
            >
              Alle dossiers
            </button>
          }
        >
          <div className="recent-dossiers">
            <button type="button" onClick={() => onNavigate("customers")}>
              <span>HV</span>
              <span className="recent-dossier-copy">
                <strong>Hofstaete Vastgoed</strong>
                <small>Klant · 8 objecten</small>
              </span>
              <ArrowRight />
            </button>
            <button type="button" onClick={() => onNavigate("objects")}>
              <span>WF</span>
              <span className="recent-dossier-copy">
                <strong>World Forum — entree A</strong>
                <small>Object · MFA-beveiligd</small>
              </span>
              <ArrowRight />
            </button>
            <button type="button" onClick={() => onNavigate("personnel")}>
              <span>SJ</span>
              <span className="recent-dossier-copy">
                <strong>Sofia de Jong</strong>
                <small>Medewerker · objectleider</small>
              </span>
              <ArrowRight />
            </button>
          </div>
        </Panel>
      </div>
    </div>
  );
}

type PlannedBlock = {
  staff: number;
  start: number;
  duration: number;
  title: string;
  customer: string;
  code: string;
  color: string;
  status: string;
};

type QueueItem = {
  code: string;
  title: string;
  customer: string;
  timing: string;
  match: string;
  duration: number;
  color: string;
  status?: string;
};

type PlanningSelection = {
  source: "queue" | "board";
  code: string;
};

const initialPlannedBlocks: PlannedBlock[] = [
  {
    staff: 0,
    start: 8,
    duration: 2.5,
    title: "Openingsronde",
    customer: "World Forum",
    code: "FG-2048",
    color: "mint",
    status: "Live",
  },
  {
    staff: 0,
    start: 13.25,
    duration: 2,
    title: "Objectcontrole",
    customer: "Stadskantoor",
    code: "FG-2060",
    color: "lilac",
    status: "Gepland",
  },
  {
    staff: 1,
    start: 8,
    duration: 4,
    title: "Beveiliging entree A",
    customer: "World Forum",
    code: "FG-2049",
    color: "blue",
    status: "Live",
  },
  {
    staff: 1,
    start: 14.5,
    duration: 2.5,
    title: "Evenementdienst",
    customer: "World Forum",
    code: "FG-2064",
    color: "orange",
    status: "Gepland",
  },
  {
    staff: 2,
    start: 9,
    duration: 2.5,
    title: "Dagelijkse schoonmaak",
    customer: "Hofstaete",
    code: "FG-2051",
    color: "aqua",
    status: "Op locatie",
  },
  {
    staff: 2,
    start: 13,
    duration: 3,
    title: "Periodieke vloerzorg",
    customer: "Parkzijde",
    code: "FG-2061",
    color: "peach",
    status: "Gepland",
  },
  {
    staff: 3,
    start: 8.5,
    duration: 1.75,
    title: "Materialen afleveren",
    customer: "Hofstaete",
    code: "FG-2052",
    color: "yellow",
    status: "Gereed",
  },
  {
    staff: 3,
    start: 13,
    duration: 3,
    title: "Glasbewassing entree",
    customer: "Stadskantoor",
    code: "FG-2059",
    color: "mint",
    status: "Gepland",
  },
  {
    staff: 4,
    start: 10.5,
    duration: 1.5,
    title: "Oplevercontrole",
    customer: "VvE Parkzijde",
    code: "FG-2055",
    color: "rose",
    status: "Aandacht",
  },
  {
    staff: 4,
    start: 15,
    duration: 1.5,
    title: "Kwaliteitsronde",
    customer: "Hofstaete",
    code: "FG-2066",
    color: "lilac",
    status: "Gepland",
  },
];

const initialQueueItems: QueueItem[] = [
  {
    code: "FG-2062",
    title: "Avondsluiting",
    customer: "World Forum",
    timing: "17:30 · 2u30",
    match: "96% match",
    duration: 2.5,
    color: "blue",
  },
  {
    code: "FG-2068",
    title: "Extra schoonmaak",
    customer: "Hofstaete",
    timing: "Flexibel · 2u",
    match: "91% match",
    duration: 2,
    color: "aqua",
  },
  {
    code: "FG-2070",
    title: "Sleuteloverdracht",
    customer: "Parkzijde",
    timing: "Voor 15:00 · 45m",
    match: "78% match",
    duration: 0.75,
    color: "yellow",
  },
  {
    code: "FG-2072",
    title: "Spoedinspectie",
    customer: "Stadskantoor",
    timing: "Vandaag · 1u",
    match: "2 kandidaten",
    duration: 1,
    color: "rose",
  },
];

function formatPlanningTime(value: number) {
  const hour = Math.floor(value);
  const minutes = Math.round((value - hour) * 60);
  return `${String(hour).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
}

function WeeklyPlanningOverview({
  onDetail,
}: {
  onDetail: (title: string, subtitle: string) => void;
}) {
  const days = ["Ma 31", "Di 01", "Wo 02", "Do 03", "Vr 04", "Za 05", "Zo 06"];
  const loads = [
    [82, 90, 88, 74, 92, 30, 0],
    [76, 84, 96, 88, 72, 45, 0],
    [68, 78, 83, 91, 87, 0, 0],
    [92, 86, 75, 82, 94, 52, 0],
    [61, 70, 78, 85, 73, 0, 0],
    [74, 66, 81, 77, 69, 38, 0],
  ];
  return (
    <Panel className="weekly-planning-panel">
      <div className="period-overview-heading">
        <div>
          <span>Week 36</span>
          <h2>Capaciteit en bezetting per medewerker</h2>
          <p>Klik op een dag om de opdrachten en conflicten te openen.</p>
        </div>
        <StatusPill tone="success">Gemiddeld 82% benut</StatusPill>
      </div>
      <div
        className="weekly-capacity-grid"
        role="table"
        aria-label="Weekcapaciteit"
      >
        <div className="weekly-grid-head" role="row">
          <strong role="columnheader">Medewerker</strong>
          {days.map((day) => (
            <span role="columnheader" key={day}>
              {day}
            </span>
          ))}
          <span role="columnheader">Totaal</span>
        </div>
        {staff.map((person, personIndex) => (
          <div role="row" key={person.name}>
            <div className="weekly-person-cell" role="rowheader">
              <button
                type="button"
                className="weekly-person"
                onClick={() =>
                  onDetail(person.name, `${person.role} · week 36`)
                }
              >
                <span className="staff-avatar">{person.initials}</span>
                <span>
                  <strong>{person.name}</strong>
                  <small>{person.role}</small>
                </span>
              </button>
            </div>
            {loads[personIndex].map((value, dayIndex) => (
              <div className="weekly-load-cell" role="cell" key={days[dayIndex]}>
                <button
                  type="button"
                  className={
                    value > 90 ? "is-high" : value === 0 ? "is-off" : ""
                  }
                  onClick={() =>
                    onDetail(
                      `${person.name} · ${days[dayIndex]}`,
                      `${value}% benut · ${Math.round(value * 0.08)} uur gepland`,
                    )
                  }
                >
                  <i style={{ height: `${Math.max(5, value)}%` }} />
                  <strong>{value ? `${value}%` : "Vrij"}</strong>
                </button>
              </div>
            ))}
            <div className="weekly-total-cell" role="cell">
              <span className="weekly-total">
                <strong>{34 + personIndex * 2}u</strong>
                <small>gepland</small>
              </span>
            </div>
          </div>
        ))}
      </div>
    </Panel>
  );
}

function MonthlyPlanningOverview({
  onDetail,
}: {
  onDetail: (title: string, subtitle: string) => void;
}) {
  const monthDays = Array.from({ length: 35 }, (_, index) => index);
  return (
    <div className="monthly-planning-layout">
      <Panel className="monthly-calendar-panel">
        <div className="period-overview-heading">
          <div>
            <span>September 2026</span>
            <h2>Maandbelasting</h2>
            <p>Opdrachten, verlof en vrije capaciteit in één ritme.</p>
          </div>
          <Button variant="outline" onClick={() => toast.info("Maandrapport is voorbereid")}>
            <Download /> Exporteer maand
          </Button>
        </div>
        <div className="month-weekdays">
          {["Ma", "Di", "Wo", "Do", "Vr", "Za", "Zo"].map((day) => <span key={day}>{day}</span>)}
        </div>
        <div className="month-grid">
          {monthDays.map((day, index) => {
            const inMonth = day > 0 && day <= 30;
            const load = inMonth ? 48 + ((day * 13) % 49) : 0;
            return (
              <button
                type="button"
                key={index}
                className={`${!inMonth ? "is-outside" : ""} ${day === 2 ? "is-today" : ""}`}
                onClick={() => inMonth && onDetail(`${day} september`, `${load}% capaciteit benut · ${5 + (day % 8)} opdrachten`)}
              >
                <span>{inMonth ? day : ""}</span>
                {inMonth && <><i style={{ width: `${load}%` }} /><small>{load}%</small></>}
              </button>
            );
          })}
        </div>
      </Panel>
      <aside className="monthly-summary-panel">
        <header><span>Maandoverzicht</span><h2>Capaciteit</h2></header>
        {[
          ["1.024u", "beschikbaar"],
          ["836u", "gepland"],
          ["82%", "gemiddeld benut"],
          ["18", "verlofdagen"],
        ].map(([value, label]) => <div key={label}><strong>{value}</strong><span>{label}</span></div>)}
        <button type="button" onClick={() => onDetail("Piekbelasting", "Dinsdag 15 september · 96% benut")}>
          <AlertCircle /><span><strong>2 piekdagen</strong><small>bekijk de capaciteitsrisico’s</small></span><ChevronRight />
        </button>
      </aside>
    </div>
  );
}

function PlanningPage({
  onCreate,
  onFilter,
  onDetail,
}: {
  onCreate: () => void;
  onFilter: () => void;
  onDetail: (title: string, subtitle: string) => void;
}) {
  const [mode, setMode] = React.useState("bord");
  const [mobileView, setMobileView] = React.useState<"agenda" | "timeline">(
    "agenda",
  );
  const [dateOffset, setDateOffset] = React.useState(0);
  const [showQueue, setShowQueue] = React.useState(true);
  const [queueSearch, setQueueSearch] = React.useState("");
  const [queueFilter, setQueueFilter] = React.useState<"all" | "best" | "urgent">("all");
  const [staffSort, setStaffSort] = React.useState("best");
  const [boardDensity, setBoardDensity] = React.useState<"comfortable" | "compact">(
    "comfortable",
  );
  const [activeFilters, setActiveFilters] = React.useState([
    { id: "region", label: "Regio Haaglanden" },
  ]);
  const [blocksByDay, setBlocksByDay] = React.useState<
    Record<string, PlannedBlock[]>
  >(() => ({
    "-1": initialPlannedBlocks.map((block, index) => ({
      ...block,
      start: Math.max(8, block.start - (index % 2 ? 0.5 : 0)),
      status: index < 7 ? "Gereed" : "Gepland",
    })),
    "0": initialPlannedBlocks,
    "1": initialPlannedBlocks.slice(0, 8).map((block, index) => ({
      ...block,
      start: Math.min(17, block.start + (index % 3) * 0.25),
      status: "Gepland",
    })),
  }));
  const [queueByDay, setQueueByDay] = React.useState<
    Record<string, QueueItem[]>
  >(() => ({
    "-1": initialQueueItems.slice(2).map((item) => ({ ...item })),
    "0": initialQueueItems,
    "1": initialQueueItems.map((item) => ({ ...item, match: "Opnieuw berekend" })),
  }));
  const dayKey = String(dateOffset);
  const blocks = React.useMemo(
    () => blocksByDay[dayKey] ?? [],
    [blocksByDay, dayKey],
  );
  const queueItems = queueByDay[dayKey] ?? [];
  function setBlocks(next: PlannedBlock[]) {
    setBlocksByDay((current) => ({ ...current, [dayKey]: next }));
  }
  function setQueueItems(next: QueueItem[]) {
    setQueueByDay((current) => ({ ...current, [dayKey]: next }));
  }
  const [dragging, setDragging] = React.useState<PlanningSelection | null>(null);
  const [dragOffsetHours, setDragOffsetHours] = React.useState(0);
  const [selected, setSelected] = React.useState<PlanningSelection | null>(null);
  const [dropPreview, setDropPreview] = React.useState<{
    staff: number;
    start: number;
    duration: number;
    conflict: boolean;
  } | null>(null);
  const planningRevision = React.useRef(0);
  const boardScrollRef = React.useRef<HTMLDivElement>(null);
  const dates = [
    "dinsdag 1 september",
    "woensdag 2 september",
    "donderdag 3 september",
  ];
  const date = dates[Math.max(0, Math.min(dates.length - 1, dateOffset + 1))];
  const dateContext = dateOffset === 0 ? "vandaag" : dateOffset < 0 ? "gisteren" : "morgen";
  const boardStart = 8;
  const boardEnd = 19;
  const totalBoardHours = boardEnd - boardStart;
  const hours = Array.from(
    { length: totalBoardHours + 1 },
    (_, index) => index + boardStart,
  );
  const orderedStaff = React.useMemo(() => {
    let entries = staff.map((person, index) => ({ person, staffIndex: index }));
    if (activeFilters.some((filter) => filter.id === "availability")) {
      entries = entries.filter(({ person }) => person.status !== "Verlof");
    }
    if (activeFilters.some((filter) => filter.id === "attention")) {
      const attentionStaff = new Set(
        blocks
          .filter((block) => block.status === "Aandacht")
          .map((block) => block.staff),
      );
      entries = entries.filter(({ staffIndex }) => attentionStaff.has(staffIndex));
    }
    if (staffSort === "name") {
      return entries.sort((left, right) =>
        left.person.name.localeCompare(right.person.name, "nl"),
      );
    }
    if (staffSort === "load") {
      return entries.sort(
        (left, right) => parseFloat(right.person.load) - parseFloat(left.person.load),
      );
    }
    if (staffSort === "region") {
      return entries.sort((left, right) =>
        left.person.status.localeCompare(right.person.status, "nl"),
      );
    }
    return entries;
  }, [activeFilters, blocks, staffSort]);

  function togglePlanningFilter(id: string, label: string) {
    setActiveFilters((current) =>
      current.some((filter) => filter.id === id)
        ? current.filter((filter) => filter.id !== id)
        : [...current, { id, label }],
    );
  }
  const visibleQueueItems = queueItems.filter((item) => {
    const term = queueSearch.trim().toLocaleLowerCase("nl");
    const matchesSearch =
      !term ||
      [item.code, item.title, item.customer].some((value) =>
        value.toLocaleLowerCase("nl").includes(term),
      );
    const matchesFilter =
      queueFilter === "all" ||
      (queueFilter === "best" && Number.parseInt(item.match, 10) >= 90) ||
      (queueFilter === "urgent" && ["yellow", "rose"].includes(item.color));
    return matchesSearch && matchesFilter;
  });

  function selectionDuration(selection: PlanningSelection) {
    if (selection.source === "queue") {
      return queueItems.find((item) => item.code === selection.code)?.duration;
    }
    return blocks.find((block) => block.code === selection.code)?.duration;
  }

  function startFromPointer(
    clientX: number,
    row: HTMLElement,
    duration: number,
  ) {
    const rect = row.getBoundingClientRect();
    const relative = Math.max(0, Math.min(rect.width, clientX - rect.left));
    const raw =
      boardStart +
      (relative / rect.width) * totalBoardHours -
      (dragging ? dragOffsetHours : 0);
    const snapped = Math.round(raw * 4) / 4;
    return Math.max(
      boardStart,
      Math.min(boardEnd - duration, snapped),
    );
  }

  function placementConflicts(
    staffIndex: number,
    start: number,
    duration: number,
    movingCode: string,
  ) {
    const end = start + duration;
    return blocks.some(
      (block) =>
        block.code !== movingCode &&
        block.staff === staffIndex &&
        start < block.start + block.duration &&
        end > block.start,
    );
  }

  function firstAvailableStart(
    staffIndex: number,
    duration: number,
    movingCode: string,
  ) {
    for (
      let start = boardStart;
      start <= boardEnd - duration;
      start += 0.25
    ) {
      if (!placementConflicts(staffIndex, start, duration, movingCode)) {
        return start;
      }
    }
    return null;
  }

  function placeSelection(
    selection: PlanningSelection,
    staffIndex: number,
    start: number,
  ) {
    const duration = selectionDuration(selection);
    if (!duration) return;
    const existing = blocks.find((block) => block.code === selection.code);
    if (existing?.status === "Live") {
      toast.error("Een live opdracht is vergrendeld", {
        description: "Pauzeer de uitvoering voordat je de planning wijzigt.",
      });
      return;
    }
    if (placementConflicts(staffIndex, start, duration, selection.code)) {
      toast.error("Deze plek veroorzaakt een overlap", {
        description: "Kies een vrij kwartier of een andere medewerker.",
      });
      return;
    }

    const previousBlocks = blocks;
    const previousQueue = queueItems;
    let nextBlocks = blocks;
    let nextQueue = queueItems;
    let title = existing?.title ?? selection.code;

    if (selection.source === "queue") {
      const item = queueItems.find((entry) => entry.code === selection.code);
      if (!item) return;
      title = item.title;
      nextQueue = queueItems.filter((entry) => entry.code !== item.code);
      nextBlocks = [
        ...blocks,
        {
          staff: staffIndex,
          start,
          duration: item.duration,
          title: item.title,
          customer: item.customer,
          code: item.code,
          color: item.color,
          status: item.status ?? "Gepland",
        },
      ];
    } else {
      nextBlocks = blocks.map((block) =>
        block.code === selection.code
          ? { ...block, staff: staffIndex, start }
          : block,
      );
    }

    const revision = planningRevision.current + 1;
    planningRevision.current = revision;
    setBlocks(nextBlocks);
    setQueueItems(nextQueue);
    setSelected(null);
    setDragging(null);
    setDropPreview(null);
    toast.success(`${title} staat bij ${staff[staffIndex]?.name}`, {
      description: `${formatPlanningTime(start)}–${formatPlanningTime(start + duration)} · gecontroleerd op overlap`,
      action: {
        label: "Ongedaan maken",
        onClick: () => {
          if (planningRevision.current !== revision) {
            toast.info("Deze wijziging is opgevolgd door een nieuwere planning");
            return;
          }
          planningRevision.current += 1;
          setBlocks(previousBlocks);
          setQueueItems(previousQueue);
        },
      },
    });
  }

  function releaseToQueue(selection: PlanningSelection) {
    if (selection.source !== "board") return;
    const block = blocks.find((entry) => entry.code === selection.code);
    if (!block) return;
    if (!["Gepland", "Aandacht"].includes(block.status)) {
      toast.error("Deze opdracht is niet vrij te geven", {
        description: "Alleen geplande opdrachten kunnen terug naar de werkvoorraad.",
      });
      return;
    }
    const previousBlocks = blocks;
    const previousQueue = queueItems;
    setBlocks(blocks.filter((entry) => entry.code !== block.code));
    setQueueItems([
      {
        code: block.code,
        title: block.title,
        customer: block.customer,
        timing: `${formatPlanningTime(block.start)} · ${block.duration}u`,
        match: "Opnieuw planbaar",
        duration: block.duration,
        color: block.color,
        status: block.status,
      },
      ...queueItems.filter((entry) => entry.code !== block.code),
    ]);
    const revision = planningRevision.current + 1;
    planningRevision.current = revision;
    setSelected(null);
    setDragging(null);
    setDropPreview(null);
    toast.success(`${block.title} staat terug in de werkvoorraad`, {
      action: {
        label: "Ongedaan maken",
        onClick: () => {
          if (planningRevision.current !== revision) {
            toast.info("Deze wijziging is opgevolgd door een nieuwere planning");
            return;
          }
          planningRevision.current += 1;
          setBlocks(previousBlocks);
          setQueueItems(previousQueue);
        },
      },
    });
  }

  function beginDrag(
    event: React.DragEvent<HTMLElement>,
    selection: PlanningSelection,
  ) {
    event.dataTransfer.effectAllowed = "move";
    event.dataTransfer.setData(
      "application/x-fieldgrid-planning",
      JSON.stringify(selection),
    );
    if (selection.source === "board") {
      const block = blocks.find((entry) => entry.code === selection.code);
      const rect = event.currentTarget.getBoundingClientRect();
      const fraction = Math.max(
        0,
        Math.min(1, (event.clientX - rect.left) / Math.max(rect.width, 1)),
      );
      setDragOffsetHours((block?.duration ?? 0) * fraction);
    } else {
      setDragOffsetHours(0);
    }
    setDragging(selection);
    setSelected(null);
  }

  function dragSelection(event: React.DragEvent<HTMLElement>) {
    if (dragging) return dragging;
    const raw = event.dataTransfer.getData(
      "application/x-fieldgrid-planning",
    );
    if (!raw) return null;
    try {
      return JSON.parse(raw) as PlanningSelection;
    } catch {
      return null;
    }
  }

  function resetPlanningDemo() {
    planningRevision.current += 1;
    const resetBlocks =
      dateOffset < 0
        ? initialPlannedBlocks.map((block, index) => ({
            ...block,
            start: Math.max(8, block.start - (index % 2 ? 0.5 : 0)),
            status: index < 7 ? "Gereed" : "Gepland",
          }))
        : dateOffset > 0
          ? initialPlannedBlocks.slice(0, 8).map((block, index) => ({
              ...block,
              start: Math.min(17, block.start + (index % 3) * 0.25),
              status: "Gepland",
            }))
          : initialPlannedBlocks;
    const resetQueue =
      dateOffset < 0
        ? initialQueueItems.slice(2).map((item) => ({ ...item }))
        : dateOffset > 0
          ? initialQueueItems.map((item) => ({
              ...item,
              match: "Opnieuw berekend",
            }))
          : initialQueueItems;
    setBlocks(resetBlocks);
    setQueueItems(resetQueue);
    setSelected(null);
    setDragging(null);
    setDropPreview(null);
    setDragOffsetHours(0);
    toast.success("De voorbeeldplanning is hersteld");
  }

  const activeSelection = dragging ?? selected;
  const activeSelectionTitle = activeSelection
    ? activeSelection.source === "queue"
      ? queueItems.find((item) => item.code === activeSelection.code)?.title
      : blocks.find((block) => block.code === activeSelection.code)?.title
    : null;

  React.useEffect(() => {
    if (!selected) return;
    const timer = window.setTimeout(() => {
      document
        .querySelector<HTMLElement>(".planning-page .timeline-row")
        ?.focus();
    }, 40);
    return () => window.clearTimeout(timer);
  }, [selected, mobileView]);
  return (
    <div
      className="page-flow planning-page"
      data-mode={mode}
      data-mobile-view={mobileView}
    >
      <Panel className="planning-control-panel">
        <div className="planning-controls">
          <div
            className="view-segment"
            role="group"
            aria-label="Planningweergave"
          >
            {["bord", "dag", "week", "maand", "kaart"].map((value) => (
              <button
                key={value}
                type="button"
                className={mode === value ? "is-active" : ""}
                onClick={() => {
                  setMode(value);
                  if (!["bord", "dag"].includes(value)) {
                    setMobileView("agenda");
                  }
                }}
              >
                {value === "kaart" && <Map />}
                {value.charAt(0).toUpperCase() + value.slice(1)}
              </button>
            ))}
          </div>
          <div className="date-control">
            <button
              type="button"
              aria-label="Vorige dag"
              onClick={() => setDateOffset((value) => Math.max(-1, value - 1))}
            >
              <ChevronLeft />
            </button>
            <button
              type="button"
              className="date-label"
              onClick={() => setDateOffset(0)}
            >
              <CalendarDays />
              <span>
                <strong>{date}</strong>
                <small>Week 36 · {dateContext}</small>
              </span>
            </button>
            <button
              type="button"
              aria-label="Volgende dag"
              onClick={() => setDateOffset((value) => Math.min(1, value + 1))}
            >
              <ChevronRight />
            </button>
          </div>
          <div className="planning-actions">
            <Button
              variant="outline"
              onClick={() => {
                if (mode !== "bord") {
                  setMode("bord");
                  setShowQueue(true);
                  return;
                }
                setShowQueue((value) => !value);
              }}
            >
              <ClipboardList /> Werkvoorraad{" "}
              <Badge variant="secondary">{queueItems.length}</Badge>
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline">
                  <ListFilter /> Filters
                  <Badge variant="secondary">{activeFilters.length}</Badge>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-64">
                <DropdownMenuLabel>Planbord filteren</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onSelect={() =>
                    togglePlanningFilter(
                      "availability",
                      "Beschikbaar + ingepland",
                    )
                  }
                >
                  {activeFilters.some((filter) => filter.id === "availability") ? (
                    <Check />
                  ) : (
                    <Users />
                  )}
                  Beschikbaar + ingepland
                </DropdownMenuItem>
                <DropdownMenuItem
                  onSelect={() =>
                    togglePlanningFilter("attention", "Alleen aandacht")
                  }
                >
                  {activeFilters.some((filter) => filter.id === "attention") ? (
                    <Check />
                  ) : (
                    <AlertCircle />
                  )}
                  Alleen aandacht
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onSelect={onFilter}>
                  <SlidersHorizontal /> Meer filters…
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
        <div className="active-filter-row">
          {activeFilters.map((filter) => (
            <span key={filter.id}>
              {filter.label}{" "}
              <button
                type="button"
                aria-label={`${filter.label} verwijderen`}
                onClick={() =>
                  setActiveFilters((current) =>
                    current.filter((item) => item.id !== filter.id),
                  )
                }
              >
                ×
              </button>
            </span>
          ))}
          {activeFilters.length > 0 && (
            <button
              type="button"
              onClick={() => {
                setActiveFilters([]);
                toast.success("Filters zijn gewist");
              }}
            >
              Wis filters
            </button>
          )}
          <em>
            <RefreshCw /> Zojuist bijgewerkt
          </em>
        </div>
      </Panel>

      {(mode === "bord" || mode === "dag") && (
        <section
          className="mobile-planning-agenda"
          data-mode={mode}
          aria-label="Mobiele dagagenda"
        >
          <div className="mobile-agenda-head">
            <div>
              <span>Mobiele planning</span>
              <strong>{date} · {staff.length} medewerkers</strong>
            </div>
            <div className="mobile-planning-switch" role="group" aria-label="Mobiele planningweergave">
              <button
                type="button"
                className={mobileView === "agenda" ? "is-active" : ""}
                onClick={() => setMobileView("agenda")}
              >
                Agenda
              </button>
              <button
                type="button"
                className={mobileView === "timeline" ? "is-active" : ""}
                onClick={() => setMobileView("timeline")}
              >
                Tijdlijn
              </button>
            </div>
          </div>
          <div className="mobile-queue-summary">
            <div>
              <span><ClipboardList /></span>
              <div>
                <strong>{queueItems.length} opdrachten in werkvoorraad</strong>
                <small>Kies Plan en tik daarna een vrij kwartier aan.</small>
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                setMode("bord");
                setShowQueue(false);
                setMobileView("timeline");
              }}
            >
              Open bord <ArrowRight />
            </button>
          </div>
          <div className="mobile-queue-cards" aria-label="Werkvoorraad">
            {queueItems.map((item) => (
              <article key={item.code}>
                <div>
                  <small>{item.code}</small>
                  <strong>{item.title}</strong>
                  <span>{item.customer} · {item.timing}</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setSelected({ source: "queue", code: item.code });
                    setMode("bord");
                    setShowQueue(false);
                    setMobileView("timeline");
                    toast.info("Tik een vrij kwartier in de tijdlijn aan");
                  }}
                >
                  <CalendarClock /> Plan
                </button>
              </article>
            ))}
          </div>
          <div className="mobile-agenda-staff">
            {staff.map((person, index) => {
              const personBlocks = blocks
                .filter((block) => block.staff === index)
                .sort((left, right) => left.start - right.start);
              return (
                <article key={person.name}>
                  <header>
                    <span className="staff-avatar">{person.initials}</span>
                    <div>
                      <strong>{person.name}</strong>
                      <small>
                        {person.role} · {person.load} gepland
                      </small>
                    </div>
                    <StatusPill
                      tone={person.status === "Beschikbaar" ? "success" : "info"}
                    >
                      {person.status}
                    </StatusPill>
                  </header>
                  <div>
                    {personBlocks.length === 0 && (
                      <p className="mobile-empty-lane">Geen opdrachten ingepland</p>
                    )}
                    {personBlocks.map((block) => (
                      <div className={`mobile-agenda-assignment color-${block.color}`} key={block.code}>
                        <button
                          type="button"
                          className="mobile-assignment-main"
                          onClick={() =>
                            onDetail(block.title, `${block.code} · ${block.customer}`)
                          }
                        >
                          <time>{formatPlanningTime(block.start)}</time>
                          <span>
                            <strong>{block.title}</strong>
                            <small>{block.customer} · {block.duration} uur</small>
                          </span>
                        </button>
                        {block.status === "Live" ? (
                          <span className="mobile-locked-label">Live</span>
                        ) : (
                          <button
                            type="button"
                            className="mobile-reschedule-button"
                            aria-label={`${block.title} verplaatsen`}
                            onClick={() => {
                              setSelected({ source: "board", code: block.code });
                              setShowQueue(false);
                              setMobileView("timeline");
                              toast.info("Tik de nieuwe medewerker en tijd aan");
                            }}
                          >
                            <GripVertical /> Verplaats
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </article>
              );
            })}
          </div>
          <Button className="primary-button mobile-create-planning" onClick={onCreate}>
            <Plus /> Plan een opdracht stap voor stap
          </Button>
        </section>
      )}

      {mode === "kaart" ? (
        <Panel className="map-placeholder-panel">
          <div className="map-canvas">
            <div className="map-grid" />
            {["World Forum", "Hofstaete", "Parkzijde", "Stadskantoor"].map(
              (place, index) => {
                const count = blocks.filter((block) =>
                  block.customer.includes(place),
                ).length;
                return (
                <button
                  type="button"
                  key={place}
                  className={`map-pin pin-${index}`}
                  onClick={() =>
                    onDetail(place, `${count} opdrachten op deze locatie`)
                  }
                >
                  <MapPin />
                  <span>{place}</span>
                </button>
                );
              },
            )}
            <div className="map-route route-a" />
            <div className="map-route route-b" />
            <div className="map-legend">
              <StatusPill tone="success">Op schema</StatusPill>
              <StatusPill tone="warning">Aandacht</StatusPill>
              <StatusPill tone="info">Onderweg</StatusPill>
            </div>
          </div>
        </Panel>
      ) : mode === "week" ? (
        <WeeklyPlanningOverview onDetail={onDetail} />
      ) : mode === "maand" ? (
        <MonthlyPlanningOverview onDetail={onDetail} />
      ) : (
        <div
          className={`planning-workspace ${mode === "bord" && showQueue ? "has-queue" : ""}`}
        >
          {mode === "bord" && showQueue && (
            <aside
              className={`work-queue surface-panel ${dragging?.source === "board" ? "is-return-target" : ""}`}
              onDragOver={(event) => {
                if (dragging?.source === "board") {
                  event.preventDefault();
                  event.dataTransfer.dropEffect = "move";
                }
              }}
              onDrop={(event) => {
                event.preventDefault();
                const selection = dragSelection(event);
                if (selection) releaseToQueue(selection);
              }}
            >
              <div className="queue-head">
                <div>
                  <span>Werkvoorraad</span>
                  <strong>{queueItems.length} planbare opdrachten</strong>
                </div>
                <button
                  type="button"
                  aria-label="Sluiten"
                  onClick={() => setShowQueue(false)}
                >
                  ×
                </button>
              </div>
              <label>
                <Search />
                <input
                  placeholder="Zoek open werk…"
                  value={queueSearch}
                  onChange={(event) => setQueueSearch(event.target.value)}
                />
              </label>
              <div className="queue-filters">
                <button
                  type="button"
                  className={queueFilter === "all" ? "is-active" : ""}
                  onClick={() => setQueueFilter("all")}
                >
                  Alle {queueItems.length}
                </button>
                <button
                  type="button"
                  className={queueFilter === "best" ? "is-active" : ""}
                  onClick={() => setQueueFilter("best")}
                >
                  Beste match
                </button>
                <button
                  type="button"
                  className={queueFilter === "urgent" ? "is-active" : ""}
                  onClick={() => setQueueFilter("urgent")}
                >
                  Urgent 2
                </button>
              </div>
              <div className="queue-cards">
                {visibleQueueItems.map((item) => (
                  <article
                    draggable
                    key={item.code}
                    className={
                      selected?.source === "queue" && selected.code === item.code
                        ? "is-selected"
                        : ""
                    }
                    onDragStart={(event) =>
                      beginDrag(event, { source: "queue", code: item.code })
                    }
                    onDragEnd={() => {
                      setDragging(null);
                      setDropPreview(null);
                    }}
                  >
                    <span className="queue-grip" aria-hidden="true">
                      <GripVertical />
                    </span>
                    <span>
                      <small>{item.code}</small>
                      <strong>{item.title}</strong>
                      <em>
                        <MapPin /> {item.customer}
                      </em>
                      <i>
                        <Clock3 /> {item.timing}
                      </i>
                    </span>
                    <StatusPill tone={item.color === "rose" ? "warning" : "success"}>
                      {item.match}
                    </StatusPill>
                    <div className="queue-card-actions">
                      <button
                        type="button"
                        onClick={() =>
                          onDetail(item.title, `${item.code} · ${item.customer}`)
                        }
                      >
                        Details
                      </button>
                      <button
                        type="button"
                        className="queue-plan-button"
                        onClick={() => {
                          setSelected({ source: "queue", code: item.code });
                          toast.info("Kies een medewerker en tijd", {
                            description:
                              "Klik daarna op een vrije plek in het planbord.",
                          });
                        }}
                      >
                        <CalendarClock /> Plan
                      </button>
                    </div>
                  </article>
                ))}
              </div>
              <p className="queue-hint">
                <Sparkles /> Sleep een kaart naar medewerker en tijd, of kies
                “Plan” en klik daarna op het bord.
              </p>
              {dragging?.source === "board" && (
                <div className="queue-return-hint">
                  <GripVertical /> Laat los om de opdracht vrij te geven
                </div>
              )}
            </aside>
          )}
          <Panel className={`planboard-panel density-${boardDensity}`}>
            <div className="planboard-topline">
              <div>
                <span className="pulse" />
                <strong>{mode === "dag" ? "Dagplanning" : "Live planbord"}</strong>
                <small>
                  {mode === "dag"
                    ? "Gefocuste dagweergave · alle medewerkers"
                    : `${staff.length} van ${staff.length} medewerkers zichtbaar · ${showQueue ? "werkvoorraad actief" : "focus op het bord"}`}
                </small>
              </div>
              <div>
                <Select value={staffSort} onValueChange={setStaffSort}>
                  <SelectTrigger aria-label="Sorteer medewerkers">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="best">Beste match</SelectItem>
                    <SelectItem value="name">Naam</SelectItem>
                    <SelectItem value="load">Belasting</SelectItem>
                    <SelectItem value="region">Regio</SelectItem>
                  </SelectContent>
                </Select>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline">
                      <Settings2 /> Bordinstellingen
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>Planbord</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem
                      onSelect={() => {
                        setBoardDensity((current) =>
                          current === "comfortable" ? "compact" : "comfortable",
                        );
                        toast.success(
                          boardDensity === "comfortable"
                            ? "Compacte borddichtheid actief"
                            : "Comfortabele borddichtheid actief",
                        );
                      }}
                    >
                      <Columns3 /> Dichtheid: {boardDensity === "comfortable" ? "comfortabel" : "compact"}
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onSelect={() =>
                        onDetail(
                          "Tijdvenster planbord",
                          "Zichtbaar van 08:00 tot 19:00 · per locatie instelbaar",
                        )
                      }
                    >
                      Tijdvenster: 08:00–19:00
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onSelect={() =>
                        toast.success("Het planbord gebruikt stappen van 15 minuten")
                      }
                    >
                      Raster: 15 minuten
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
                <Button
                  variant="outline"
                  onClick={() => {
                    const scroll = boardScrollRef.current;
                    if (scroll) {
                      const nowFraction = (9.7 - boardStart) / totalBoardHours;
                      scroll.scrollTo({
                        left: Math.max(
                          0,
                          scroll.scrollWidth * nowFraction - scroll.clientWidth / 3,
                        ),
                        behavior: "smooth",
                      });
                    }
                    toast.info("De tijdlijn staat op 09:42");
                  }}
                >
                  <Clock3 /> Nu
                </Button>
              </div>
            </div>
            <div
              className={`planboard-interaction-bar ${activeSelection ? "is-active" : ""}`}
            >
              <div>
                <span className="interaction-icon">
                  <GripVertical />
                </span>
                <span>
                  <strong>
                    {activeSelectionTitle
                      ? `${activeSelectionTitle} is opgepakt`
                      : "Plan direct met drag & drop"}
                  </strong>
                  <small>
                    {activeSelectionTitle
                      ? "Kies een vrije plek; groen is geldig en rood geeft overlap aan."
                      : "Sleep uit de werkvoorraad of verplaats een bestaand blok per kwartier."}
                  </small>
                </span>
              </div>
              <div>
                {selected?.source === "board" && (
                  <button
                    type="button"
                    onClick={() => releaseToQueue(selected)}
                  >
                    Terug naar werkvoorraad
                  </button>
                )}
                {activeSelection && (
                  <button
                    type="button"
                    onClick={() => {
                      setSelected(null);
                      setDragging(null);
                      setDropPreview(null);
                    }}
                  >
                    Annuleren
                  </button>
                )}
                <button type="button" onClick={resetPlanningDemo}>
                  <RefreshCw /> Herstel demo
                </button>
              </div>
              <span className="sr-only" aria-live="polite">
                {activeSelectionTitle
                  ? `${activeSelectionTitle} geselecteerd om te plannen`
                  : "Geen opdracht geselecteerd"}
              </span>
            </div>
            <div
              ref={boardScrollRef}
              className="board-scroll"
              role="region"
              aria-label="Planbord met medewerkers als rijen en uren als kolommen"
              tabIndex={0}
            >
              <div
                className="board-grid"
                role="grid"
                aria-label="Dagplanning per medewerker"
                style={
                  { "--hour-count": hours.length - 1 } as React.CSSProperties
                }
              >
                <div className="board-heading-row" role="row">
                  <div className="board-corner" role="columnheader">
                    <span>Medewerker</span>
                    <small>Capaciteit</small>
                  </div>
                  <div className="board-hours" role="columnheader">
                    {hours.slice(0, -1).map((hour) => (
                      <span key={hour}>
                        {String(hour).padStart(2, "0")}:00
                      </span>
                    ))}
                  </div>
                </div>
                {orderedStaff.map(({ person, staffIndex }) => (
                  <div className="board-staff-row" role="row" key={person.name}>
                    <div className="board-staff-header" role="rowheader">
                      <button
                        type="button"
                        className="staff-cell"
                        onClick={() =>
                          onDetail(
                            person.name,
                            `${person.role} · ${person.load} gepland`,
                          )
                        }
                      >
                        <span className="staff-avatar">{person.initials}</span>
                        <span>
                          <strong>{person.name}</strong>
                          <small>
                            <i
                              className={
                                person.status === "Beschikbaar" ? "online" : ""
                              }
                            />
                            {person.status} · {person.load}
                          </small>
                        </span>
                        <ChevronRight />
                      </button>
                    </div>
                    <div
                      role="gridcell"
                      tabIndex={selected ? 0 : -1}
                      aria-label={
                        selected
                          ? `Plan ${activeSelectionTitle} bij ${person.name}`
                          : `Planning van ${person.name}`
                      }
                      className={`timeline-row ${
                        dropPreview?.staff === staffIndex
                          ? dropPreview.conflict
                            ? "is-conflict-drop"
                            : "is-valid-drop"
                          : ""
                      } ${selected ? "is-click-target" : ""}`}
                      onDragOver={(event) => {
                        const selection = dragging;
                        if (!selection) return;
                        const duration = selectionDuration(selection);
                        if (!duration) return;
                        event.preventDefault();
                        event.dataTransfer.dropEffect = "move";
                        const start = startFromPointer(
                          event.clientX,
                          event.currentTarget,
                          duration,
                        );
                        setDropPreview({
                          staff: staffIndex,
                          start,
                          duration,
                          conflict: placementConflicts(
                            staffIndex,
                            start,
                            duration,
                            selection.code,
                          ),
                        });
                      }}
                      onDrop={(event) => {
                        event.preventDefault();
                        const selection = dragSelection(event);
                        if (!selection) return;
                        const duration = selectionDuration(selection);
                        if (!duration) return;
                        const start = startFromPointer(
                          event.clientX,
                          event.currentTarget,
                          duration,
                        );
                        placeSelection(selection, staffIndex, start);
                      }}
                      onClick={(event) => {
                        if (!selected) return;
                        const duration = selectionDuration(selected);
                        if (!duration) return;
                        const start = startFromPointer(
                          event.clientX,
                          event.currentTarget,
                          duration,
                        );
                        placeSelection(selected, staffIndex, start);
                      }}
                      onKeyDown={(event) => {
                        if (
                          !selected ||
                          !["Enter", " "].includes(event.key)
                        )
                          return;
                        event.preventDefault();
                        const duration = selectionDuration(selected);
                        if (!duration) return;
                        const start = firstAvailableStart(
                          staffIndex,
                          duration,
                          selected.code,
                        );
                        if (start === null) {
                          toast.error(`Geen vrije plek bij ${person.name}`);
                          return;
                        }
                        placeSelection(selected, staffIndex, start);
                      }}
                    >
                      <div className="hour-lines">
                        {hours.slice(0, -1).map((hour) => (
                          <i key={hour} />
                        ))}
                      </div>
                      {dropPreview?.staff === staffIndex && activeSelection && (
                        <div
                          className={`drop-preview ${dropPreview.conflict ? "is-conflict" : ""}`}
                          style={{
                            left: `${((dropPreview.start - boardStart) / totalBoardHours) * 100}%`,
                            width: `${(dropPreview.duration / totalBoardHours) * 100}%`,
                          }}
                        >
                          <span>
                            {formatPlanningTime(dropPreview.start)} ·{" "}
                            {dropPreview.conflict ? "Overlap" : "Plaatsen"}
                          </span>
                          <strong>{activeSelectionTitle}</strong>
                        </div>
                      )}
                      {blocks
                        .filter((block) => block.staff === staffIndex)
                        .map((block) => {
                          const left =
                            ((block.start - boardStart) / totalBoardHours) * 100;
                          const width =
                            (block.duration / totalBoardHours) * 100;
                          return (
                            <article
                              draggable={block.status !== "Live"}
                              tabIndex={0}
                              key={block.code}
                              className={`schedule-block color-${block.color} ${
                                dragging?.source === "board" &&
                                dragging.code === block.code
                                  ? "is-dragging"
                                  : ""
                              } ${block.status === "Live" ? "is-locked" : ""}`}
                              style={{ left: `${left}%`, width: `${width}%` }}
                              onDragStart={(event) =>
                                beginDrag(event, {
                                  source: "board",
                                  code: block.code,
                                })
                              }
                              onDragEnd={() => {
                                setDragging(null);
                                setDropPreview(null);
                              }}
                              onKeyDown={(event) => {
                                if (event.target !== event.currentTarget) return;
                                if (
                                  ![
                                    "ArrowLeft",
                                    "ArrowRight",
                                    "ArrowUp",
                                    "ArrowDown",
                                  ].includes(event.key) ||
                                  block.status === "Live"
                                )
                                  return;
                                event.preventDefault();
                                const step = event.shiftKey ? 1 : 0.25;
                                const visualStaffIndex = orderedStaff.findIndex(
                                  (entry) => entry.staffIndex === block.staff,
                                );
                                const nextStaff =
                                  event.key === "ArrowUp"
                                    ? orderedStaff[
                                        Math.max(0, visualStaffIndex - 1)
                                      ]?.staffIndex ?? block.staff
                                    : event.key === "ArrowDown"
                                      ? orderedStaff[
                                          Math.min(
                                            orderedStaff.length - 1,
                                            visualStaffIndex + 1,
                                          )
                                        ]?.staffIndex ?? block.staff
                                      : block.staff;
                                const nextStart =
                                  event.key === "ArrowLeft"
                                    ? Math.max(boardStart, block.start - step)
                                    : event.key === "ArrowRight"
                                      ? Math.min(
                                          boardEnd - block.duration,
                                          block.start + step,
                                        )
                                      : block.start;
                                placeSelection(
                                  { source: "board", code: block.code },
                                  nextStaff,
                                  nextStart,
                                );
                              }}
                            >
                              <button
                                type="button"
                                className="schedule-block-main"
                                onClick={(event) => {
                                  event.stopPropagation();
                                  onDetail(
                                    block.title,
                                    `${block.code} · ${block.customer}`,
                                  );
                                }}
                              >
                                <span>
                                  {block.code} · {block.status}
                                </span>
                                <strong>{block.title}</strong>
                                <small>{block.customer}</small>
                              </button>
                              {block.status !== "Live" && (
                                <button
                                  type="button"
                                  className="schedule-move-button"
                                  aria-label={`${block.title} verplaatsen`}
                                  onClick={(event) => {
                                    event.stopPropagation();
                                    setSelected({
                                      source: "board",
                                      code: block.code,
                                    });
                                  }}
                                >
                                  <GripVertical />
                                </button>
                              )}
                            </article>
                          );
                        })}
                      {staffIndex === 0 && (
                        <div className="now-line" style={{ left: "17%" }}>
                          <span>09:42</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="board-legend">
              <span>
                <i className="legend-mint" /> Gepland
              </span>
              <span>
                <i className="legend-blue" /> In uitvoering
              </span>
              <span>
                <i className="legend-rose" /> Aandacht
              </span>
              <span>
                <i className="legend-gray" /> Niet beschikbaar
              </span>
              <em>
                Sleep met de greep · klik “Plan” op touch · pijltjes verplaatsen
              </em>
            </div>
          </Panel>
        </div>
      )}

      <div className="planning-insights">
        <Panel
          eyebrow="Capaciteit"
          title="Vandaag"
          action={<StatusPill tone="success">82% benut</StatusPill>}
        >
          <div className="insight-bars">
            <span>
              <i style={{ width: "82%" }} />
            </span>
            <div>
              <small>44u beschikbaar</small>
              <small>36u gepland</small>
              <small>8u vrij</small>
            </div>
          </div>
        </Panel>
        <Panel
          eyebrow="Route & reistijd"
          title="2 aandachtspunten"
          action={
            <button
              type="button"
              className="text-action"
              onClick={() => setMode("kaart")}
            >
              Open kaart
            </button>
          }
        >
          <div className="route-warning">
            <Route />
            <div>
              <strong>15 minuten krap</strong>
              <small>Yassin · World Forum → Parkzijde</small>
            </div>
            <StatusPill tone="warning">Controleer</StatusPill>
          </div>
        </Panel>
        <Panel
          eyebrow="Matchkwaliteit"
          title="6 sterke voorstellen"
          action={
            <button
              type="button"
              className="text-action"
              onClick={() =>
                onDetail(
                  "Sterkste matches",
                  "6 voorstellen op kwalificatie, regio en actuele belasting",
                )
              }
            >
              Bekijk matches
            </button>
          }
        >
          <div className="match-stack">
            <span>SJ</span>
            <span>NV</span>
            <span>LH</span>
            <span>+3</span>
            <div>
              <strong>92% gemiddeld</strong>
              <small>kwalificatie + regio + belasting</small>
            </div>
          </div>
        </Panel>
      </div>
    </div>
  );
}

function ListSummary({
  items,
}: {
  items: Array<{ label: string; value: string; tone: string; detail: string }>;
}) {
  return (
    <div className="list-summary">
      {items.map((item) => (
        <div key={item.label} className={`summary-${item.tone}`}>
          <span>{item.label}</span>
          <strong>{item.value}</strong>
          <small>{item.detail}</small>
        </div>
      ))}
    </div>
  );
}

function InteractiveListTabs({
  items,
}: {
  items: Array<{ label: string; count?: string }>;
}) {
  const [active, setActive] = React.useState(items[0]?.label ?? "");
  return (
    <div className="list-tabs">
      {items.map((item) => (
        <button
          type="button"
          key={item.label}
          className={active === item.label ? "is-active" : ""}
          aria-pressed={active === item.label}
          onClick={() => setActive(item.label)}
        >
          {item.label} {item.count && <span>{item.count}</span>}
        </button>
      ))}
    </div>
  );
}

function AssignmentsPage({
  onFilter,
  onDetail,
}: {
  onFilter: () => void;
  onDetail: (title: string, subtitle: string) => void;
}) {
  const [selected, setSelected] = React.useState<string[]>([]);
  const [activeTab, setActiveTab] = React.useState("Alle opdrachten");
  const [page, setPage] = React.useState(1);
  const assignmentTabs = [
    ["Alle opdrachten", "128"],
    ["Open", "18"],
    ["Vandaag", "12"],
    ["Aandacht", "4"],
    ["Afgerond", ""],
  ];
  function toggle(id: string) {
    setSelected((current) =>
      current.includes(id)
        ? current.filter((item) => item !== id)
        : [...current, id],
    );
  }
  return (
    <div className="page-flow list-page records-list-page">
      <ListSummary
        items={[
          {
            label: "Nieuw",
            value: "6",
            tone: "blue",
            detail: "nog te beoordelen",
          },
          {
            label: "Planbaar",
            value: "8",
            tone: "violet",
            detail: "6 sterke matches",
          },
          {
            label: "In uitvoering",
            value: "4",
            tone: "teal",
            detail: "allemaal op schema",
          },
          {
            label: "Rapportcontrole",
            value: "4",
            tone: "orange",
            detail: "1 blokkeert facturatie",
          },
        ]}
      />
      <Panel className="data-panel">
        <div className="list-tabs">
          {assignmentTabs.map(([label, count]) => (
            <button
              type="button"
              key={label}
              className={activeTab === label ? "is-active" : ""}
              aria-pressed={activeTab === label}
              onClick={() => {
                setActiveTab(label);
                setPage(1);
              }}
            >
              {label} {count && <span>{count}</span>}
            </button>
          ))}
        </div>
        <PageToolbar
          placeholder="Zoek op werkbon, klant, object of medewerker…"
          result="128 opdrachten"
          onFilter={onFilter}
        >
          <Select defaultValue="all">
            <SelectTrigger className="toolbar-select">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Alle statussen</SelectItem>
              <SelectItem value="open">Open</SelectItem>
              <SelectItem value="planned">Gepland</SelectItem>
              <SelectItem value="live">In uitvoering</SelectItem>
            </SelectContent>
          </Select>
        </PageToolbar>
        {selected.length > 0 && (
          <div className="bulk-bar">
            <strong>{selected.length} geselecteerd</strong>
            <Button
              variant="outline"
              onClick={() => toast.success("Eigenaar toegewezen")}
            >
              Eigenaar toewijzen
            </Button>
            <Button
              variant="outline"
              onClick={() => toast.success("Status bijgewerkt")}
            >
              Status wijzigen
            </Button>
            <Button variant="outline" onClick={() => setSelected([])}>
              Selectie wissen
            </Button>
          </div>
        )}
        <div className="desktop-table">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="check-cell">
                  <Checkbox
                    aria-label="Alles selecteren"
                    checked={selected.length === assignmentRows.length}
                    onCheckedChange={() =>
                      setSelected(
                        selected.length === assignmentRows.length
                          ? []
                          : assignmentRows.map((row) => row[0]),
                      )
                    }
                  />
                </TableHead>
                <TableHead>Opdracht</TableHead>
                <TableHead>Klant & object</TableHead>
                <TableHead>Moment</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Bezetting</TableHead>
                <TableHead className="action-cell">
                  <span className="sr-only">Acties</span>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {assignmentRows.map((row) => (
                <TableRow
                  key={row[0]}
                  data-selected={selected.includes(row[0])}
                >
                  <TableCell className="check-cell">
                    <Checkbox
                      aria-label={`Selecteer ${row[0]}`}
                      checked={selected.includes(row[0])}
                      onCheckedChange={() => toggle(row[0])}
                    />
                  </TableCell>
                  <TableCell>
                    <button
                      type="button"
                      className="identity-cell"
                      onClick={() => onDetail(row[1], `${row[0]} · ${row[2]}`)}
                    >
                      <span className="identity-icon">
                        <ClipboardList />
                      </span>
                      <span>
                        <small>{row[0]}</small>
                        <strong>{row[1]}</strong>
                      </span>
                    </button>
                  </TableCell>
                  <TableCell>
                    <strong>{row[2]}</strong>
                    <small className="cell-sub">Den Haag · hoofdlocatie</small>
                  </TableCell>
                  <TableCell>
                    <strong>{row[3]}</strong>
                    <small className="cell-sub">wo 2 september</small>
                  </TableCell>
                  <TableCell>
                    <StatusPill>{row[4]}</StatusPill>
                  </TableCell>
                  <TableCell>
                    <span className="person-chip">
                      <span>
                        {row[5]
                          .split(" ")
                          .map((part) => part[0])
                          .join("")
                          .slice(0, 2)}
                      </span>
                      {row[5]}
                    </span>
                  </TableCell>
                  <TableCell className="action-cell">
                    <RowActions
                      onOpen={() => onDetail(row[1], `${row[0]} · ${row[2]}`)}
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <div className="mobile-card-list">
          <label className="mobile-selection-bar">
            <Checkbox
              aria-label="Alle opdrachten selecteren"
              checked={selected.length === assignmentRows.length}
              onCheckedChange={() =>
                setSelected(
                  selected.length === assignmentRows.length
                    ? []
                    : assignmentRows.map((row) => row[0]),
                )
              }
            />
            <span>
              <strong>Alles selecteren</strong>
              <small>{selected.length} van {assignmentRows.length} geselecteerd</small>
            </span>
          </label>
          {assignmentRows.map((row) => (
            <article
              key={row[0]}
              className="mobile-data-card"
              data-selected={selected.includes(row[0])}
            >
              <div className="mobile-data-card-toolbar">
                <Checkbox
                  aria-label={`Selecteer ${row[0]}`}
                  checked={selected.includes(row[0])}
                  onCheckedChange={() => toggle(row[0])}
                />
                <StatusPill>{row[4]}</StatusPill>
                <RowActions
                  onOpen={() => onDetail(row[1], `${row[0]} · ${row[2]}`)}
                />
              </div>
              <button
                type="button"
                className="mobile-data-card-main"
                onClick={() => onDetail(row[1], `${row[0]} · ${row[2]}`)}
              >
                <small>{row[0]}</small>
                <strong>{row[1]}</strong>
                <span><MapPin /> {row[2]}</span>
                <span><Clock3 /> {row[3]}</span>
              </button>
            </article>
          ))}
        </div>
        <div className="pagination">
          <span>{(page - 1) * 25 + 1}–{Math.min(page * 25, 128)} van 128</span>
          <button
            type="button"
            aria-label="Vorige pagina"
            disabled={page === 1}
            onClick={() => setPage((current) => Math.max(1, current - 1))}
          >
            <ChevronLeft />
          </button>
          {[1, 2, 3].map((pageNumber) => (
            <button
              type="button"
              key={pageNumber}
              className={page === pageNumber ? "is-active" : ""}
              aria-current={page === pageNumber ? "page" : undefined}
              onClick={() => setPage(pageNumber)}
            >
              {pageNumber}
            </button>
          ))}
          <button
            type="button"
            aria-label="Volgende pagina"
            disabled={page === 3}
            onClick={() => setPage((current) => Math.min(3, current + 1))}
          >
            <ChevronRight />
          </button>
        </div>
      </Panel>
    </div>
  );
}

type EntityConfig = {
  type: DossierType;
  rows: string[][];
  tabs: string[];
  result: string;
  placeholder: string;
  columns: string[];
  summary: Array<{
    label: string;
    value: string;
    tone: string;
    detail: string;
  }>;
};

const entityConfigs: Record<DossierType, EntityConfig> = {
  customer: {
    type: "customer",
    rows: customerRows,
    tabs: ["Alle klanten", "Actief", "Prospect", "Herziening"],
    result: "42 klanten",
    placeholder: "Zoek klant, contactpersoon of plaats…",
    columns: [
      "Klant",
      "Type",
      "Objecten",
      "Omzet YTD",
      "Status",
      "Relatie-eigenaar",
    ],
    summary: [
      {
        label: "Actieve klanten",
        value: "38",
        tone: "teal",
        detail: "van 42 totaal",
      },
      {
        label: "Nieuwe aanvragen",
        value: "5",
        tone: "blue",
        detail: "deze week",
      },
      {
        label: "Contractherziening",
        value: "3",
        tone: "orange",
        detail: "actie vereist",
      },
      {
        label: "Klantwaarde YTD",
        value: "€ 286K",
        tone: "violet",
        detail: "+11% versus vorig jaar",
      },
    ],
  },
  object: {
    type: "object",
    rows: objectRows,
    tabs: ["Alle objecten", "Actief", "Toegang beveiligd", "Aandacht"],
    result: "67 objecten",
    placeholder: "Zoek object, klant, adres of dienst…",
    columns: [
      "Object / locatie",
      "Klant",
      "Adres",
      "Diensten",
      "Status",
      "Toegang",
    ],
    summary: [
      {
        label: "Actieve objecten",
        value: "63",
        tone: "teal",
        detail: "4 in voorbereiding",
      },
      {
        label: "MFA-beveiligd",
        value: "18",
        tone: "blue",
        detail: "gevoelige toegang",
      },
      {
        label: "Open aandacht",
        value: "4",
        tone: "orange",
        detail: "2 vandaag oplossen",
      },
      {
        label: "Diensten deze week",
        value: "148",
        tone: "violet",
        detail: "96% bezet",
      },
    ],
  },
  personnel: {
    type: "personnel",
    rows: personnelRows,
    tabs: [
      "Alle medewerkers",
      "Beschikbaar",
      "Op locatie",
      "Dossier incompleet",
    ],
    result: "54 medewerkers",
    placeholder: "Zoek medewerker, rol, regio of kwalificatie…",
    columns: [
      "Medewerker",
      "Rol",
      "Regio",
      "Belasting vandaag",
      "Kwalificaties",
      "Status",
    ],
    summary: [
      { label: "Actief", value: "51", tone: "teal", detail: "3 in onboarding" },
      {
        label: "Beschikbaar vandaag",
        value: "18",
        tone: "blue",
        detail: "8u vrije capaciteit",
      },
      {
        label: "Certificaat verloopt",
        value: "5",
        tone: "orange",
        detail: "binnen 30 dagen",
      },
      {
        label: "Portaal actief",
        value: "49",
        tone: "violet",
        detail: "96% geactiveerd",
      },
    ],
  },
};

function EntityListPage({
  type,
  onFilter,
  onOpen,
}: {
  type: DossierType;
  onFilter: () => void;
  onOpen: (type: DossierType) => void;
}) {
  const config = entityConfigs[type];
  const [selected, setSelected] = React.useState<string[]>([]);
  const [activeTab, setActiveTab] = React.useState(config.tabs[0]);
  const [page, setPage] = React.useState(1);
  const totalRecords = Number(config.result.split(" ")[0]);
  const lastPage = Math.max(1, Math.ceil(totalRecords / 25));
  const statusIndex = config.columns.indexOf("Status");
  function toggleEntity(id: string) {
    setSelected((current) =>
      current.includes(id)
        ? current.filter((item) => item !== id)
        : [...current, id],
    );
  }
  return (
    <div className="page-flow list-page records-list-page entity-list-page">
      <ListSummary items={config.summary} />
      <Panel className="data-panel">
        <div className="list-tabs">
          {config.tabs.map((tab, index) => (
            <button
              type="button"
              key={tab}
              className={activeTab === tab ? "is-active" : ""}
              aria-pressed={activeTab === tab}
              onClick={() => {
                setActiveTab(tab);
                setPage(1);
              }}
            >
              {tab}
              {index === 0 && <span>{config.result.split(" ")[0]}</span>}
            </button>
          ))}
        </div>
        <PageToolbar
          placeholder={config.placeholder}
          result={config.result}
          onFilter={onFilter}
        >
          <Button
            variant="outline"
            onClick={() => toast.success("CSV-export wordt voorbereid")}
          >
            <Download /> Exporteren
          </Button>
        </PageToolbar>
        {selected.length > 0 && (
          <div className="bulk-bar">
            <strong>{selected.length} geselecteerd</strong>
            <Button variant="outline" onClick={() => toast.success("Eigenaar toegewezen")}>
              Eigenaar toewijzen
            </Button>
            <Button variant="outline" onClick={() => toast.success("Status bijgewerkt")}>
              Status wijzigen
            </Button>
            <Button variant="outline" onClick={() => setSelected([])}>
              Selectie wissen
            </Button>
          </div>
        )}
        <div className="desktop-table">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="check-cell">
                  <Checkbox
                    aria-label="Alles selecteren"
                    checked={selected.length === config.rows.length}
                    onCheckedChange={() =>
                      setSelected(
                        selected.length === config.rows.length
                          ? []
                          : config.rows.map((row) => row[0]),
                      )
                    }
                  />
                </TableHead>
                {config.columns.map((column) => (
                  <TableHead key={column}>{column}</TableHead>
                ))}
                <TableHead className="action-cell">
                  <span className="sr-only">Acties</span>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {config.rows.map((row, rowIndex) => (
                <TableRow key={row[0]}>
                  <TableCell className="check-cell">
                    <Checkbox
                      aria-label={`Selecteer ${row[0]}`}
                      checked={selected.includes(row[0])}
                      onCheckedChange={() => toggleEntity(row[0])}
                    />
                  </TableCell>
                  {row.map((cell, cellIndex) => (
                    <TableCell key={`${row[0]}-${cellIndex}`}>
                      {cellIndex === 0 ? (
                        <button
                          type="button"
                          className="identity-cell"
                          onClick={() => onOpen(type)}
                        >
                          <span className={`entity-avatar entity-${type}`}>
                            {type === "customer" ? (
                              row[0]
                                .split(" ")
                                .map((part) => part[0])
                                .join("")
                                .slice(0, 2)
                            ) : type === "personnel" ? (
                              row[0]
                                .split(" ")
                                .map((part) => part[0])
                                .join("")
                                .slice(0, 2)
                            ) : (
                              <Building2 />
                            )}
                          </span>
                          <span>
                            <strong>{cell}</strong>
                            <small>
                              {type === "customer"
                                ? `KL-${1040 + rowIndex}`
                                : type === "personnel"
                                  ? `P-${201 + rowIndex}`
                                  : `OBJ-${301 + rowIndex}`}
                            </small>
                          </span>
                        </button>
                      ) : cellIndex === config.columns.length - 2 ? (
                        <StatusPill>{cell}</StatusPill>
                      ) : cellIndex === config.columns.length - 1 &&
                        (cell.includes("MFA") ||
                          cell.includes("sleutel") ||
                          cell.includes("Code")) ? (
                        <span className="security-label">
                          <LockKeyhole />
                          {cell}
                        </span>
                      ) : (
                        <>
                          <strong className="table-value">{cell}</strong>
                          {cellIndex === 1 && type === "customer" && (
                            <small className="cell-sub">Sinds 2024</small>
                          )}
                        </>
                      )}
                    </TableCell>
                  ))}
                  <TableCell className="action-cell">
                    <RowActions
                      onOpen={() => onOpen(type)}
                      duplicateLabel={
                        type === "personnel"
                          ? "Uitnodiging opnieuw sturen"
                          : "Dupliceren"
                      }
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <div className="mobile-card-list">
          <label className="mobile-selection-bar">
            <Checkbox
              aria-label={`Alle ${config.result} selecteren`}
              checked={selected.length === config.rows.length}
              onCheckedChange={() =>
                setSelected(
                  selected.length === config.rows.length
                    ? []
                    : config.rows.map((row) => row[0]),
                )
              }
            />
            <span>
              <strong>Alles selecteren</strong>
              <small>{selected.length} van {config.rows.length} zichtbaar geselecteerd</small>
            </span>
          </label>
          {config.rows.map((row) => (
            <article
              className="mobile-data-card"
              data-selected={selected.includes(row[0])}
              key={row[0]}
            >
              <div className="mobile-data-card-toolbar">
                <Checkbox
                  aria-label={`Selecteer ${row[0]}`}
                  checked={selected.includes(row[0])}
                  onCheckedChange={() => toggleEntity(row[0])}
                />
                <StatusPill>{row[statusIndex]}</StatusPill>
                <RowActions onOpen={() => onOpen(type)} />
              </div>
              <button type="button" className="mobile-data-card-main" onClick={() => onOpen(type)}>
                <small>{type === "customer" ? "Klantdossier" : row[1]}</small>
                <strong>{row[0]}</strong>
                <span>{row[1]}</span>
                <span>{row[2]}</span>
              </button>
            </article>
          ))}
        </div>
        <div className="pagination">
          <span>{(page - 1) * 25 + 1}–{Math.min(page * 25, totalRecords)} van {totalRecords}</span>
          <button
            type="button"
            aria-label="Vorige pagina"
            disabled={page === 1}
            onClick={() => setPage((current) => Math.max(1, current - 1))}
          >
            <ChevronLeft />
          </button>
          {Array.from({ length: Math.min(lastPage, 3) }, (_, index) => index + 1).map((pageNumber) => (
            <button
              type="button"
              key={pageNumber}
              className={page === pageNumber ? "is-active" : ""}
              aria-current={page === pageNumber ? "page" : undefined}
              onClick={() => setPage(pageNumber)}
            >
              {pageNumber}
            </button>
          ))}
          <button
            type="button"
            aria-label="Volgende pagina"
            disabled={page === lastPage}
            onClick={() => setPage((current) => Math.min(lastPage, current + 1))}
          >
            <ChevronRight />
          </button>
        </div>
      </Panel>
    </div>
  );
}

const dossierCopy: Record<
  DossierType,
  {
    back: string;
    code: string;
    name: string;
    subtitle: string;
    initials: string;
    meta: string[];
    tabs: Array<[string, string]>;
  }
> = {
  customer: {
    back: "Terug naar klanten",
    code: "KL-1040",
    name: "Hofstaete Vastgoed",
    subtitle: "Zakelijke klant · relatie sinds maart 2024",
    initials: "HV",
    meta: [
      "Sanne van Delft · eigenaar",
      "8 actieve objecten",
      "Den Haag",
      "Portaal actief",
    ],
    tabs: [
      ["overzicht", "Overzicht"],
      ["contacten", "Contactpersonen"],
      ["contracten", "Contracten & afspraken"],
      ["financieel", "Financieel"],
      ["kwaliteit", "Kwaliteit & relatie"],
      ["objecten", "Objecten"],
      ["opdrachten", "Opdrachten"],
      ["documenten", "Documenten"],
      ["tijdlijn", "Notities & tijdlijn"],
    ],
  },
  personnel: {
    back: "Terug naar medewerkers",
    code: "P-201",
    name: "Sofia de Jong",
    subtitle: "Objectleider · in dienst sinds 12 februari 2023",
    initials: "SJ",
    meta: ["Regio Haaglanden", "32 uur per week", "Auto", "Portaal actief"],
    tabs: [
      ["overzicht", "Overzicht"],
      ["profiel", "Persoonsgegevens"],
      ["dienstverband", "Dienstverband"],
      ["beschikbaarheid", "Beschikbaarheid"],
      ["kwalificaties", "Kwalificaties"],
      ["historie", "Operationele historie"],
      ["verzuim", "Verlof & verzuim"],
      ["middelen", "Middelen"],
      ["documenten", "Documenten"],
      ["tijdlijn", "Notities & tijdlijn"],
    ],
  },
  object: {
    back: "Terug naar objecten",
    code: "OBJ-301",
    name: "World Forum — entree A",
    subtitle: "Churchillplein 10, Den Haag · World Forum Den Haag",
    initials: "WF",
    meta: [
      "Karim Ouali · contact",
      "24/7 beveiliging",
      "MFA-beveiligd",
      "3 vaste medewerkers",
    ],
    tabs: [
      ["overzicht", "Overzicht"],
      ["gegevens", "Basisgegevens"],
      ["toegang", "Toegang & veiligheid"],
      ["uitvoering", "Uitvoering"],
      ["contacten", "Contactpersonen"],
      ["diensten", "Diensten"],
      ["personeel", "Personeel"],
      ["documenten", "Documenten"],
      ["tijdlijn", "Notities & tijdlijn"],
      ["rechten", "Rechten"],
    ],
  },
};

function DossierMiniCard({
  icon: Icon,
  label,
  value,
  detail,
  tone = "neutral",
}: {
  icon: LucideIcon;
  label: string;
  value: string;
  detail: string;
  tone?: string;
}) {
  return (
    <button type="button" className={`dossier-mini tone-${tone}`}>
      <span>
        <Icon />
      </span>
      <span className="dossier-mini-copy">
        <small>{label}</small>
        <strong>{value}</strong>
        <span className="dossier-mini-detail">{detail}</span>
      </span>
      <ChevronRight />
    </button>
  );
}

function DossierTabContent({
  type,
  tab,
  onDetail,
}: {
  type: DossierType;
  tab: string;
  onDetail: (title: string, subtitle: string) => void;
}) {
  if (tab === "overzicht") {
    if (type === "customer") {
      return (
        <div className="dossier-overview-grid">
          <div className="dossier-main-column">
            <Panel
              eyebrow="Klantgezondheid"
              title="Relatie in één oogopslag"
              action={<StatusPill tone="success">Gezond · 88%</StatusPill>}
            >
              <div className="health-grid">
                <DossierMiniCard
                  icon={Building2}
                  label="Objecten"
                  value="8 actief"
                  detail="2 met beveiligde toegang"
                  tone="blue"
                />
                <DossierMiniCard
                  icon={FileCheck2}
                  label="Contracten"
                  value="3 lopend"
                  detail="1 herziening in november"
                  tone="violet"
                />
                <DossierMiniCard
                  icon={WalletCards}
                  label="Omzet YTD"
                  value="€ 18.450"
                  detail="alle facturen op tijd"
                  tone="teal"
                />
                <DossierMiniCard
                  icon={ClipboardCheck}
                  label="Kwaliteit"
                  value="96%"
                  detail="laatste 30 rapporten"
                  tone="orange"
                />
              </div>
            </Panel>
            <Panel
              eyebrow="Commerciële context"
              title="Afspraken die het werk sturen"
            >
              <div className="agreement-list">
                <div>
                  <span>Facturatie</span>
                  <strong>Maandelijks achteraf · 30 dagen</strong>
                  <small>Kostenplaats verplicht per object</small>
                </div>
                <div>
                  <span>Servicevenster</span>
                  <strong>Ma–vr · 06:00–22:00</strong>
                  <small>Spoed via operationeel contact</small>
                </div>
                <div>
                  <span>Prijsafspraak</span>
                  <strong>Indexering per 1 januari</strong>
                  <small>CBS zakelijke dienstverlening</small>
                </div>
              </div>
            </Panel>
          </div>
          <DossierActivity type={type} />
        </div>
      );
    }
    if (type === "personnel") {
      return (
        <div className="dossier-overview-grid">
          <div className="dossier-main-column">
            <Panel
              eyebrow="Inzetbaarheid"
              title="Klaar voor planning"
              action={
                <StatusPill tone="success">Volledig inzetbaar</StatusPill>
              }
            >
              <div className="health-grid">
                <DossierMiniCard
                  icon={CalendarClock}
                  label="Vandaag"
                  value="6u 30m"
                  detail="2 opdrachten · 1u 30m vrij"
                  tone="blue"
                />
                <DossierMiniCard
                  icon={BadgeCheck}
                  label="Kwalificaties"
                  value="5 geldig"
                  detail="BHV verloopt over 48 dagen"
                  tone="orange"
                />
                <DossierMiniCard
                  icon={CalendarDays}
                  label="Beschikbaarheid"
                  value="32u / week"
                  detail="ma, di, wo en vr"
                  tone="teal"
                />
                <DossierMiniCard
                  icon={PackageCheck}
                  label="Middelen"
                  value="4 uitgegeven"
                  detail="alles in orde"
                  tone="violet"
                />
              </div>
            </Panel>
            <Panel eyebrow="Weekrooster" title="Beschikbaarheid & belasting">
              <div className="availability-week">
                {[
                  ["Ma", 8, 6],
                  ["Di", 8, 7],
                  ["Wo", 8, 6.5],
                  ["Do", 0, 0],
                  ["Vr", 8, 5],
                  ["Za", 0, 0],
                  ["Zo", 0, 0],
                ].map((day) => (
                  <div key={day[0]}>
                    <span>{day[0]}</span>
                    <i>
                      <b
                        style={{
                          width: `${(Number(day[2]) / Math.max(1, Number(day[1]))) * 100}%`,
                        }}
                      />
                    </i>
                    <small>{day[1] ? `${day[2]}u / ${day[1]}u` : "Vrij"}</small>
                  </div>
                ))}
              </div>
            </Panel>
          </div>
          <DossierActivity type={type} />
        </div>
      );
    }
    return (
      <div className="dossier-overview-grid">
        <div className="dossier-main-column">
          <Panel
            eyebrow="Operationele status"
            title="Locatie gereed voor uitvoering"
            action={<StatusPill tone="success">Actief</StatusPill>}
          >
            <div className="health-grid">
              <DossierMiniCard
                icon={ShieldCheck}
                label="Toegang"
                value="MFA-beveiligd"
                detail="venster opent 60 min vooraf"
                tone="orange"
              />
              <DossierMiniCard
                icon={ClipboardCheck}
                label="Diensten"
                value="3 actief"
                detail="beveiliging, receptie, sluiting"
                tone="blue"
              />
              <DossierMiniCard
                icon={Users}
                label="Vast team"
                value="3 medewerkers"
                detail="alle kwalificaties geldig"
                tone="teal"
              />
              <DossierMiniCard
                icon={Activity}
                label="Kwaliteit"
                value="98%"
                detail="geen open afwijkingen"
                tone="violet"
              />
            </div>
          </Panel>
          <Panel eyebrow="Volgende uitvoering" title="Vandaag · 08:00–12:00">
            <div className="next-execution">
              <span className="time-tile">08:00</span>
              <div>
                <small>FG-2048</small>
                <strong>Ochtendronde beveiliging</strong>
                <p>Yassin El Amrani · entree A en laadperron</p>
              </div>
              <StatusPill tone="info">In uitvoering</StatusPill>
              <Button
                variant="outline"
                onClick={() =>
                  onDetail("Ochtendronde beveiliging", "FG-2048 · World Forum")
                }
              >
                Open werkbon
              </Button>
            </div>
          </Panel>
        </div>
        <DossierActivity type={type} />
      </div>
    );
  }

  if (type === "object" && tab === "toegang") {
    return (
      <div className="security-workspace">
        <Panel
          eyebrow="Extra beveiligd"
          title="Toegang & veiligheid"
          action={
            <StatusPill tone="warning">
              Doelontwerp · backend afronden
            </StatusPill>
          }
        >
          <div className="security-intro">
            <span>
              <ShieldCheck />
            </span>
            <div>
              <strong>Gevoelige informatie blijft standaard verzegeld</strong>
              <p>
                Doelproces: alleen bevoegde medewerkers met een actieve werkbon
                kunnen vanaf 60 minuten voor de start toegang aanvragen. De
                huidige code ondersteunt management-MFA gedeeltelijk; toegang
                voor medewerkers en break-glass moeten nog worden afgebouwd.
              </p>
            </div>
          </div>
          <div className="sealed-record">
            <div className="seal">
              <LockKeyhole />
            </div>
            <div>
              <small>Beveiligd toegangsrecord</small>
              <strong>Sleutelkluis, alarmzone en nachtingang</strong>
              <p>
                Beschikbaar vandaag van 07:00 tot 13:00 voor toegewezen
                medewerkers.
              </p>
            </div>
            <div className="seal-actions">
              <StatusPill tone="warning">
                6-cijferige e-mailcode nodig
              </StatusPill>
              <Button
                className="primary-button"
                onClick={() =>
                  toast.info("Verificatiecode is veilig verstuurd")
                }
              >
                Toegang verifiëren
              </Button>
            </div>
          </div>
          <div className="security-rules">
            <div>
              <span>60 min</span>
              <strong>Voor start beschikbaar</strong>
              <small>configureerbaar per organisatie</small>
            </div>
            <div>
              <span>6 cijfers</span>
              <strong>MFA via e-mail</strong>
              <small>eenmalig en kort geldig</small>
            </div>
            <div>
              <span>100%</span>
              <strong>Inzage gelogd</strong>
              <small>actor, tijd en opdracht</small>
            </div>
          </div>
        </Panel>
        <Panel eyebrow="Toegangsregister" title="Beveiligde onderdelen">
          <div className="secure-record-list">
            {[
              [
                "Alarm & zones",
                "3 records",
                "Management + toegewezen medewerker",
              ],
              ["Sleutels & kluizen", "2 records", "Management + objectleider"],
              ["Noodprocedures", "4 documenten", "Vast team"],
              ["Camerabeleid", "1 document", "Management"],
            ].map((row) => (
              <button
                type="button"
                key={row[0]}
                onClick={() => onDetail(row[0], row[2])}
              >
                <span>
                  <LockKeyhole />
                </span>
                <span className="secure-record-copy">
                  <strong>{row[0]}</strong>
                  <small>
                    {row[1]} · {row[2]}
                  </small>
                </span>
                <ChevronRight />
              </button>
            ))}
          </div>
        </Panel>
      </div>
    );
  }

  const labels: Record<
    string,
    { title: string; intro: string; icon: LucideIcon }
  > = {
    contacten: {
      title: "Contactpersonen",
      intro:
        "Operationele, financiële en escalatiecontacten met duidelijke rollen.",
      icon: Phone,
    },
    contracten: {
      title: "Contracten & commerciële afspraken",
      intro: "Lopende overeenkomsten, prijsafspraken en verlengmomenten.",
      icon: FileCheck2,
    },
    financieel: {
      title: "Financieel dossier",
      intro: "Offertes, facturen, betalingen en uitzonderingsafspraken.",
      icon: WalletCards,
    },
    kwaliteit: {
      title: "Kwaliteit & relatiebeheer",
      intro: "SLA-score, evaluaties, klachten en verbeteracties.",
      icon: Star,
    },
    objecten: {
      title: "Gekoppelde objecten",
      intro: "Locaties, diensten, contactpersonen en actuele status.",
      icon: Building2,
    },
    opdrachten: {
      title: "Operationele historie",
      intro: "Alle opdrachten, uitvoeringsstatussen en bewijsstukken.",
      icon: ClipboardList,
    },
    documenten: {
      title: "Documentmanagement",
      intro: "Versies, geldigheid, categorieën en veilige koppelingen.",
      icon: FolderOpen,
    },
    tijdlijn: {
      title: "Notities, communicatie & tijdlijn",
      intro: "Eén chronologisch overzicht met zichtbaarheid per doelgroep.",
      icon: History,
    },
    profiel: {
      title: "Persoons- & contactgegevens",
      intro: "Adres, bereikbaarheid, noodcontact en profielinformatie.",
      icon: UserCog,
    },
    dienstverband: {
      title: "Dienstverband",
      intro: "Contract, uren, functie, kostenplaats en verantwoordelijke.",
      icon: BriefcaseBusiness,
    },
    beschikbaarheid: {
      title: "Beschikbaarheid & planning",
      intro: "Weekpatroon, uitzonderingen, reistype en belasting.",
      icon: CalendarClock,
    },
    kwalificaties: {
      title: "Kwalificaties & bevoegdheden",
      intro: "Geldigheid en automatische match met opdrachteisen.",
      icon: BadgeCheck,
    },
    historie: {
      title: "Operationele historie",
      intro: "Uitgevoerde opdrachten, punctualiteit en kwaliteitsresultaten.",
      icon: Activity,
    },
    verzuim: {
      title: "Verlof & verzuim",
      intro: "Aanvragen, registraties en impact op inzetbaarheid.",
      icon: CalendarDays,
    },
    middelen: {
      title: "Materiaal & bedrijfsmiddelen",
      intro: "Uitgiftes, retouren, schade en onderhoud.",
      icon: PackageSearch,
    },
    gegevens: {
      title: "Basisgegevens",
      intro:
        "Adres, klantkoppeling, regio, openingstijden en locatiekenmerken.",
      icon: Building2,
    },
    uitvoering: {
      title: "Uitvoering",
      intro: "Werkinstructies, routes, zones, checklistsets en overdracht.",
      icon: Workflow,
    },
    diensten: {
      title: "Diensten & afspraken",
      intro: "Actieve services, frequenties, taakcodes en normen.",
      icon: ClipboardCheck,
    },
    personeel: {
      title: "Toegewezen personeel",
      intro: "Vast team, invalkrachten, vereiste rollen en kwalificaties.",
      icon: Users,
    },
    rechten: {
      title: "Rechten & beveiliging",
      intro: "Toegang per dossieronderdeel, rol en tijdelijk werkverband.",
      icon: KeyRound,
    },
  };
  const meta = labels[tab] ?? {
    title: "Dossieronderdeel",
    intro: "Alle relevante gegevens logisch bijeen.",
    icon: FileText,
  };
  const MetaIcon = meta.icon;
  return (
    <div className="dossier-section-page">
      <Panel
        eyebrow="Dossieronderdeel"
        title={meta.title}
        action={
          <Button
            className="primary-button"
            onClick={() => toast.success(`${meta.title} kan worden bewerkt`)}
          >
            <Pencil /> Bewerken
          </Button>
        }
      >
        <div className="section-intro">
          <span>
            <MetaIcon />
          </span>
          <p>{meta.intro}</p>
        </div>
        <div className="detail-records">
          {[
            [
              "Primaire registratie",
              "Volledig en actueel",
              "Vandaag gecontroleerd",
            ],
            [
              "Aanvullende afspraken",
              "3 actieve items",
              "Laatste wijziging 26 augustus",
            ],
            [
              "Verantwoordelijke",
              type === "personnel" ? "Michel de Graaf" : "Sanne van Delft",
              "Eigenaar van dit onderdeel",
            ],
            [
              "Zichtbaarheid",
              tab === "tijdlijn"
                ? "Management + gekozen doelgroep"
                : "Op basis van rol",
              "Rechten per dossieronderdeel",
            ],
          ].map((row) => (
            <button
              type="button"
              key={row[0]}
              onClick={() => onDetail(row[0], row[1])}
            >
              <span className="detail-record-copy">
                <small>{row[0]}</small>
                <strong>{row[1]}</strong>
                <span className="detail-record-meta">{row[2]}</span>
              </span>
              <ChevronRight />
            </button>
          ))}
        </div>
      </Panel>
      <DossierActivity type={type} />
    </div>
  );
}

function DossierActivity({ type }: { type: DossierType }) {
  return (
    <aside className="dossier-activity">
      <Panel eyebrow="Acties" title="Open werk">
        <div className="dossier-actions">
          <button
            type="button"
            onClick={() => toast.info("Open taken zijn geladen")}
          >
            <ClipboardCheck />
            <span>
              <strong>2 taken</strong>
              <small>1 vervalt vandaag</small>
            </span>
            <ChevronRight />
          </button>
          <button
            type="button"
            onClick={() => toast.success("Nieuwe notitie is geopend")}
          >
            <MessageSquareText />
            <span>
              <strong>Nieuwe notitie</strong>
              <small>intern of gedeeld</small>
            </span>
            <ChevronRight />
          </button>
          <button
            type="button"
            onClick={() => toast.info("Documentkiezer is geopend")}
          >
            <UploadCloud />
            <span>
              <strong>Document koppelen</strong>
              <small>met categorie en geldigheid</small>
            </span>
            <ChevronRight />
          </button>
        </div>
      </Panel>
      <Panel
        eyebrow="Tijdlijn"
        title="Recente activiteit"
        action={
          <button
            type="button"
            className="icon-button"
            aria-label="Meer tijdlijnacties"
            onClick={() => toast.info("Tijdlijnacties geopend")}
          >
            <MoreHorizontal />
          </button>
        }
      >
        <ol className="timeline-list">
          <li>
            <i className="green">
              <Check />
            </i>
            <div>
              <strong>
                {type === "personnel"
                  ? "Beoordeling vastgelegd"
                  : "Rapport goedgekeurd"}
              </strong>
              <small>Vandaag · 09:18 · Danny</small>
            </div>
          </li>
          <li>
            <i className="blue">
              <FilePenLine />
            </i>
            <div>
              <strong>Gegevens bijgewerkt</strong>
              <small>Gisteren · 16:42 · Sanne</small>
            </div>
          </li>
          <li>
            <i className="violet">
              <UploadCloud />
            </i>
            <div>
              <strong>Document toegevoegd</strong>
              <small>28 augustus · automatisch</small>
            </div>
          </li>
        </ol>
        <button
          type="button"
          className="timeline-more"
          onClick={() => toast.info("Volledige tijdlijn geopend")}
        >
          Volledige tijdlijn <ArrowRight />
        </button>
      </Panel>
    </aside>
  );
}

function DossierPage({
  type,
  onBack,
  onDetail,
}: {
  type: DossierType;
  onBack: () => void;
  onDetail: (title: string, subtitle: string) => void;
}) {
  const info = dossierCopy[type];
  const [tab, setTab] = React.useState("overzicht");
  return (
    <div className="page-flow dossier-page">
      <button type="button" className="back-link" onClick={onBack}>
        <ArrowLeft /> {info.back}
      </button>
      <section className="dossier-hero surface-panel">
        <div className={`dossier-avatar entity-${type}`}>{info.initials}</div>
        <div className="dossier-identity">
          <div>
            <span className="record-code">{info.code}</span>
            <StatusPill tone="success">Actief</StatusPill>
            {type === "object" && (
              <StatusPill tone="warning">MFA-beveiligd</StatusPill>
            )}
          </div>
          <h2>{info.name}</h2>
          <p>{info.subtitle}</p>
          <ul>
            {info.meta.map((item) => (
              <li key={item}>
                <CheckCircle2 />
                {item}
              </li>
            ))}
          </ul>
        </div>
        <div className="dossier-hero-actions">
          <Button
            variant="outline"
            onClick={() => toast.info("Berichtvenster geopend")}
          >
            <Mail /> Bericht
          </Button>
          <Button
            className="primary-button"
            onClick={() => toast.success("Bewerkformulier geopend")}
          >
            <Pencil /> Bewerken
          </Button>
          <RowActions
            onOpen={() => onDetail(info.name, info.code)}
            archiveLabel="Dossier archiveren"
          />
        </div>
      </section>
      <section className="dossier-status-strip">
        <div>
          <small>Dossierstatus</small>
          <strong>
            <CheckCircle2 /> Compleet
          </strong>
        </div>
        <div>
          <small>Verantwoordelijke</small>
          <strong>Sanne van Delft</strong>
        </div>
        <div>
          <small>Laatste beoordeling</small>
          <strong>26 augustus 2026</strong>
        </div>
        <div>
          <small>Open werk</small>
          <strong>2 taken · 0 blokkades</strong>
        </div>
      </section>
      <Tabs value={tab} onValueChange={setTab} className="dossier-tabs">
        <div className="dossier-tab-scroll">
          <TabsList variant="line">
            {info.tabs.map(([value, label]) => (
              <TabsTrigger key={value} value={value}>
                {label}
              </TabsTrigger>
            ))}
          </TabsList>
        </div>
        {info.tabs.map(([value]) => (
          <TabsContent key={value} value={value}>
            <DossierTabContent type={type} tab={value} onDetail={onDetail} />
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}

function LeavePage({
  onFilter,
  onDetail,
}: {
  onFilter: () => void;
  onDetail: (title: string, subtitle: string) => void;
}) {
  return (
    <div className="page-flow leave-page">
      <ListSummary
        items={[
          {
            label: "Wacht op besluit",
            value: "3",
            tone: "orange",
            detail: "2 raken capaciteit",
          },
          {
            label: "Goedgekeurd",
            value: "12",
            tone: "teal",
            detail: "komende 60 dagen",
          },
          {
            label: "Bezetting laag",
            value: "2 dagen",
            tone: "blue",
            detail: "18 en 25 september",
          },
          {
            label: "Verzuim actief",
            value: "1",
            tone: "violet",
            detail: "correct afgeschermd",
          },
        ]}
      />
      <div className="two-column-workspace">
        <Panel
          eyebrow="Inbox"
          title="Verlofaanvragen"
          action={<StatusPill tone="warning">3 nieuw</StatusPill>}
        >
          <PageToolbar
            placeholder="Zoek medewerker of datum…"
            onFilter={onFilter}
          />
          <div className="request-list">
            {[
              [
                "Rayan Akachar",
                "18–19 september",
                "16 uur",
                "Capaciteitsconflict",
                "RA",
              ],
              [
                "Naomi Vermeer",
                "2 oktober",
                "8 uur",
                "Kan worden goedgekeurd",
                "NV",
              ],
              [
                "Mila Smit",
                "12–16 oktober",
                "32 uur",
                "Vervanging voorgesteld",
                "MS",
              ],
            ].map((row, index) => (
              <article key={row[0]}>
                <span className="entity-avatar entity-personnel">{row[4]}</span>
                <div>
                  <strong>{row[0]}</strong>
                  <p>
                    {row[1]} · {row[2]}
                  </p>
                  <StatusPill
                    tone={
                      index === 0 ? "warning" : index === 1 ? "success" : "info"
                    }
                  >
                    {row[3]}
                  </StatusPill>
                </div>
                <div className="request-actions">
                  <Button
                    variant="outline"
                    onClick={() => onDetail(row[0], `${row[1]} · ${row[2]}`)}
                  >
                    Details
                  </Button>
                  <Button
                    className="primary-button"
                    onClick={() =>
                      toast.success(`Verlof van ${row[0]} is goedgekeurd`)
                    }
                  >
                    <Check /> Goedkeuren
                  </Button>
                  <RowActions archiveLabel="Afwijzen" />
                </div>
              </article>
            ))}
          </div>
        </Panel>
        <Panel
          eyebrow="Capaciteitsbeeld"
          title="September 2026"
          action={
            <button type="button" className="text-action">
              Open planning
            </button>
          }
        >
          <div className="capacity-calendar">
            <div className="weekdays">
              {["Ma", "Di", "Wo", "Do", "Vr", "Za", "Zo"].map((day) => (
                <span key={day}>{day}</span>
              ))}
            </div>
            <div className="calendar-days">
              {Array.from({ length: 35 }, (_, index) => {
                const day = index - 1;
                const load = (index * 7) % 100;
                return (
                  <button
                    key={index}
                    className={
                      day < 1 || day > 30
                        ? "is-outside"
                        : load > 78
                          ? "is-busy"
                          : load < 28
                            ? "is-low"
                            : ""
                    }
                  >
                    <span>{day > 0 && day <= 30 ? day : ""}</span>
                    {day > 0 && day <= 30 && (
                      <i style={{ opacity: Math.max(0.25, load / 100) }} />
                    )}
                  </button>
                );
              })}
            </div>
            <div className="calendar-legend">
              <span>
                <i className="good" />
                Gezond
              </span>
              <span>
                <i className="low" />
                Lage bezetting
              </span>
              <span>
                <i className="busy" />
                Zwaar belast
              </span>
            </div>
          </div>
        </Panel>
      </div>
    </div>
  );
}

function MaterialsPage({
  kind,
  onFilter,
  onDetail,
}: {
  kind: "materials" | "inventory";
  onFilter: () => void;
  onDetail: (title: string, subtitle: string) => void;
}) {
  const isMaterials = kind === "materials";
  const rows = isMaterials
    ? [
        [
          "Allesreiniger Pro 5L",
          "Verbruik",
          "84 stuks",
          "20",
          "Magazijn Den Haag",
          "Op peil",
        ],
        [
          "Nitril handschoenen M",
          "PBM",
          "18 dozen",
          "24",
          "Magazijn Den Haag",
          "Bestellen",
        ],
        [
          "Microvezeldoek blauw",
          "Schoonmaak",
          "142 stuks",
          "60",
          "3 locaties",
          "Op peil",
        ],
        [
          "Vuilniszak 120L",
          "Verbruik",
          "9 rollen",
          "12",
          "World Forum",
          "Laag",
        ],
      ]
    : [
        [
          "Schrobzuigmachine T7",
          "Machine",
          "FG-MID-0081",
          "Hofstaete",
          "Sofia de Jong",
          "In gebruik",
        ],
        [
          "Sleutelbos World Forum A",
          "Sleutel",
          "FG-MID-0144",
          "World Forum",
          "Yassin El Amrani",
          "Uitgegeven",
        ],
        [
          "Bodycam BC-22",
          "Beveiliging",
          "FG-MID-0202",
          "Magazijn",
          "Niet toegewezen",
          "Onderhoud",
        ],
        [
          "Glasbewassingsset 8m",
          "Gereedschap",
          "FG-MID-0178",
          "Stadskantoor",
          "Lars Hendriks",
          "In gebruik",
        ],
      ];
  return (
    <div className="page-flow resource-page">
      <ListSummary
        items={
          isMaterials
            ? [
                {
                  label: "Voorraadwaarde",
                  value: "€ 24.860",
                  tone: "teal",
                  detail: "412 artikelen",
                },
                {
                  label: "Onder minimum",
                  value: "7",
                  tone: "orange",
                  detail: "4 bestelvoorstellen",
                },
                {
                  label: "Verbruik deze maand",
                  value: "€ 4.120",
                  tone: "blue",
                  detail: "binnen budget",
                },
                {
                  label: "Transfers onderweg",
                  value: "3",
                  tone: "violet",
                  detail: "naar 2 objecten",
                },
              ]
            : [
                {
                  label: "Actieve middelen",
                  value: "186",
                  tone: "teal",
                  detail: "€ 312K waarde",
                },
                {
                  label: "Uitgegeven",
                  value: "84",
                  tone: "blue",
                  detail: "aan 39 medewerkers",
                },
                {
                  label: "Onderhoud",
                  value: "6",
                  tone: "orange",
                  detail: "2 vandaag gepland",
                },
                {
                  label: "Open incidenten",
                  value: "2",
                  tone: "violet",
                  detail: "1 blokkeert uitgifte",
                },
              ]
        }
      />
      <Panel className="data-panel">
        <InteractiveListTabs
          items={[
            { label: isMaterials ? "Voorraad" : "Alle middelen" },
            { label: isMaterials ? "Verbruik" : "Uitgiftes" },
            { label: isMaterials ? "Bestelvoorstellen" : "Onderhoud" },
            {
              label: isMaterials ? "Transfers" : "Incidenten",
              count: isMaterials ? "4" : "2",
            },
            ...(!isMaterials ? [{ label: "QR-labels" }] : []),
          ]}
        />
        <PageToolbar
          placeholder={
            isMaterials
              ? "Zoek artikel, categorie of locatie…"
              : "Zoek middel, QR-code, medewerker of locatie…"
          }
          result={isMaterials ? "412 artikelen" : "186 middelen"}
          onFilter={onFilter}
        >
          <Button
            variant="outline"
            onClick={() =>
              toast.success(
                isMaterials
                  ? "Voorraadrapport geëxporteerd"
                  : "QR-labels worden voorbereid",
              )
            }
          >
            <Download /> {isMaterials ? "Voorraadrapport" : "QR-labels"}
          </Button>
        </PageToolbar>
        <div className="desktop-table">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>
                  {isMaterials ? "Artikel" : "Bedrijfsmiddel"}
                </TableHead>
                {(isMaterials
                  ? ["Categorie", "Voorraad", "Minimum", "Locatie", "Status"]
                  : [
                      "Categorie",
                      "Assetcode",
                      "Locatie",
                      "Toegewezen aan",
                      "Status",
                    ]
                ).map((head) => (
                  <TableHead key={head}>{head}</TableHead>
                ))}
                <TableHead className="action-cell" />
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((row, index) => (
                <TableRow key={row[0]}>
                  <TableCell>
                    <button
                      type="button"
                      className="identity-cell"
                      onClick={() => onDetail(row[0], `${row[1]} · ${row[2]}`)}
                    >
                      <span className="identity-icon">
                        {isMaterials ? <Boxes /> : <PackageSearch />}
                      </span>
                      <span>
                        <strong>{row[0]}</strong>
                        <small>
                          {isMaterials ? `ART-${401 + index}` : row[2]}
                        </small>
                      </span>
                    </button>
                  </TableCell>
                  {row.slice(1).map((cell, cellIndex) => (
                    <TableCell key={`${row[0]}-${cell}`}>
                      {cellIndex === row.length - 2 ? (
                        <StatusPill>{cell}</StatusPill>
                      ) : (
                        <strong className="table-value">{cell}</strong>
                      )}
                    </TableCell>
                  ))}
                  <TableCell className="action-cell">
                    <RowActions
                      onOpen={() => onDetail(row[0], `${row[1]} · ${row[2]}`)}
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <div className="mobile-card-list">
          {rows.map((row) => (
            <article className="mobile-data-card" key={row[0]}>
              <div className="mobile-data-card-toolbar">
                <small>{row[1]}</small>
                <StatusPill>{row[5]}</StatusPill>
                <RowActions onOpen={() => onDetail(row[0], row[2])} />
              </div>
              <button
                type="button"
                className="mobile-data-card-main"
                onClick={() => onDetail(row[0], row[2])}
              >
                <strong>{row[0]}</strong>
                <span>{row[2]}</span>
                <span>{row[4]}</span>
              </button>
            </article>
          ))}
        </div>
      </Panel>
    </div>
  );
}

const financeData = {
  quotes: {
    tabs: [
      "Alle offertes",
      "Concept",
      "Wacht op klant",
      "Goedgekeurd",
      "Verlopen",
    ],
    result: "38 offertes",
    placeholder: "Zoek offerte, klant of object…",
    summary: [
      {
        label: "Open waarde",
        value: "€ 84.200",
        tone: "blue",
        detail: "12 open offertes",
      },
      {
        label: "Wacht op klant",
        value: "6",
        tone: "violet",
        detail: "€ 41.600 waarde",
      },
      {
        label: "Verloopt deze week",
        value: "3",
        tone: "orange",
        detail: "opvolging nodig",
      },
      {
        label: "Conversie",
        value: "72%",
        tone: "teal",
        detail: "+6% dit kwartaal",
      },
    ],
    rows: [
      [
        "OFF-2026-081",
        "Hofstaete Vastgoed",
        "Periodieke vloerzorg",
        "€ 8.450",
        "12 sep 2026",
        "Wacht op klant",
      ],
      [
        "OFF-2026-079",
        "VvE Parkzijde",
        "Glasbewassing Q4",
        "€ 3.280",
        "6 sep 2026",
        "Verloopt bijna",
      ],
      [
        "OFF-2026-076",
        "Gemeente Rijswijk",
        "Facilitair jaarplan",
        "€ 42.600",
        "28 sep 2026",
        "Concept",
      ],
      [
        "OFF-2026-071",
        "World Forum",
        "Extra beveiliging",
        "€ 12.840",
        "18 sep 2026",
        "Goedgekeurd",
      ],
    ],
  },
  invoices: {
    tabs: [
      "Alle facturen",
      "Concept",
      "Te verzenden",
      "Openstaand",
      "Vervallen",
      "Betaald",
    ],
    result: "246 facturen",
    placeholder: "Zoek factuurnummer, klant of periode…",
    summary: [
      {
        label: "Openstaand",
        value: "€ 48.620",
        tone: "blue",
        detail: "31 facturen",
      },
      {
        label: "Te verzenden",
        value: "12",
        tone: "violet",
        detail: "€ 18.940 gereed",
      },
      {
        label: "Vervallen",
        value: "6",
        tone: "orange",
        detail: "€ 7.280 open",
      },
      {
        label: "Betaald deze maand",
        value: "€ 86.410",
        tone: "teal",
        detail: "94% op tijd",
      },
    ],
    rows: [
      [
        "FAC-2026-1184",
        "Hofstaete Vastgoed",
        "Augustus 2026",
        "€ 8.450",
        "30 sep 2026",
        "Verzonden",
      ],
      [
        "FAC-2026-1179",
        "VvE Parkzijde",
        "Augustus 2026",
        "€ 3.280",
        "31 aug 2026",
        "Vervallen",
      ],
      [
        "FAC-2026-1174",
        "Gemeente Rijswijk",
        "Week 34–35",
        "€ 12.600",
        "22 sep 2026",
        "Concept",
      ],
      [
        "FAC-2026-1168",
        "World Forum",
        "Augustus 2026",
        "€ 18.840",
        "18 sep 2026",
        "Betaald",
      ],
    ],
  },
};

function FinancePage({
  kind,
  onFilter,
  onDetail,
}: {
  kind: "quotes" | "invoices";
  onFilter: () => void;
  onDetail: (title: string, subtitle: string) => void;
}) {
  const config = financeData[kind];
  const [activeTab, setActiveTab] = React.useState(config.tabs[0]);
  return (
    <div className="page-flow finance-page list-page">
      <ListSummary items={config.summary} />
      <Panel className="data-panel">
        <div className="list-tabs">
          {config.tabs.map((tab, index) => (
            <button
              type="button"
              key={tab}
              className={activeTab === tab ? "is-active" : ""}
              aria-pressed={activeTab === tab}
              onClick={() => setActiveTab(tab)}
            >
              {tab}
              {index === 2 && <span>6</span>}
            </button>
          ))}
        </div>
        <PageToolbar
          placeholder={config.placeholder}
          result={config.result}
          onFilter={onFilter}
        >
          <Button
            variant="outline"
            onClick={() =>
              toast.success(
                kind === "quotes"
                  ? "Offerteoverzicht geëxporteerd"
                  : "Factuurselectie geëxporteerd",
              )
            }
          >
            <Download /> Exporteren
          </Button>
          {kind === "invoices" && (
            <Button
              variant="outline"
              onClick={() => toast.success("Verzamelfacturatie gestart")}
            >
              <Blocks /> Verzamelrun
            </Button>
          )}
        </PageToolbar>
        <div className="desktop-table">
          <Table>
            <TableHeader>
              <TableRow>
                {[
                  kind === "quotes" ? "Offerte" : "Factuur",
                  "Klant",
                  kind === "quotes" ? "Voorstel" : "Periode",
                  "Bedrag",
                  kind === "quotes" ? "Geldig tot" : "Vervaldatum",
                  "Status",
                  "",
                ].map((head, index) => (
                  <TableHead
                    key={`${head}-${index}`}
                    className={index === 6 ? "action-cell" : ""}
                  >
                    {head}
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {config.rows.map((row) => (
                <TableRow key={row[0]}>
                  <TableCell>
                    <button
                      className="identity-cell"
                      onClick={() => onDetail(row[0], `${row[1]} · ${row[3]}`)}
                    >
                      <span className="identity-icon">
                        {kind === "quotes" ? <FileCheck2 /> : <ReceiptText />}
                      </span>
                      <span>
                        <strong>{row[0]}</strong>
                        <small>2 sep 2026</small>
                      </span>
                    </button>
                  </TableCell>
                  <TableCell>
                    <strong>{row[1]}</strong>
                  </TableCell>
                  <TableCell>{row[2]}</TableCell>
                  <TableCell>
                    <strong>{row[3]}</strong>
                  </TableCell>
                  <TableCell>{row[4]}</TableCell>
                  <TableCell>
                    <StatusPill>{row[5]}</StatusPill>
                  </TableCell>
                  <TableCell className="action-cell">
                    <RowActions
                      onOpen={() => onDetail(row[0], `${row[1]} · ${row[3]}`)}
                      duplicateLabel={
                        kind === "quotes" ? "Nieuwe versie" : "Creditnota maken"
                      }
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <div className="mobile-card-list">
          {config.rows.map((row) => (
            <article className="mobile-data-card" key={row[0]}>
              <div className="mobile-data-card-toolbar">
                <small>{row[0]}</small>
                <StatusPill>{row[5]}</StatusPill>
                <RowActions
                  onOpen={() => onDetail(row[0], `${row[1]} · ${row[3]}`)}
                  duplicateLabel={kind === "quotes" ? "Nieuwe versie" : "Creditnota maken"}
                />
              </div>
              <button
                type="button"
                className="mobile-data-card-main"
                onClick={() => onDetail(row[0], `${row[1]} · ${row[3]}`)}
              >
                <strong>{row[1]}</strong>
                <span>{row[2]}</span>
                <span>{row[3]} · {row[4]}</span>
              </button>
            </article>
          ))}
        </div>
      </Panel>
    </div>
  );
}

function ReportsPage({
  onFilter,
  onDetail,
}: {
  onFilter: () => void;
  onDetail: (title: string, subtitle: string) => void;
}) {
  const rows = [
    [
      "RAP-4182",
      "FG-2055",
      "Oplevercontrole verdieping 4",
      "VvE Parkzijde",
      "Mila Smit",
      "Foto ontbreekt",
      "Aandacht",
    ],
    [
      "RAP-4180",
      "FG-2051",
      "Dagelijkse schoonmaak",
      "Hofstaete",
      "Naomi Vermeer",
      "Compleet",
      "Klaar voor akkoord",
    ],
    [
      "RAP-4178",
      "FG-2048",
      "Ochtendronde beveiliging",
      "World Forum",
      "Yassin El Amrani",
      "Compleet",
      "Goedgekeurd",
    ],
    [
      "RAP-4176",
      "FG-2044",
      "Glasbewassing zuidzijde",
      "Stadskantoor",
      "Lars Hendriks",
      "1 afwijking",
      "Klantcontrole",
    ],
  ];
  return (
    <div className="page-flow reports-page list-page">
      <ListSummary
        items={[
          {
            label: "Te beoordelen",
            value: "4",
            tone: "orange",
            detail: "1 met blokkade",
          },
          {
            label: "Klantgereed",
            value: "11",
            tone: "blue",
            detail: "vandaag verzenden",
          },
          {
            label: "Goedgekeurd",
            value: "23",
            tone: "teal",
            detail: "klaar voor factuur",
          },
          {
            label: "Afwijkingen",
            value: "3",
            tone: "violet",
            detail: "2 verbeteracties",
          },
        ]}
      />
      <Panel className="data-panel">
        <InteractiveListTabs
          items={[
            { label: "Werkvoorraad", count: "4" },
            { label: "In klantcontrole" },
            { label: "Goedgekeurd" },
            { label: "Afgekeurd" },
            { label: "Alle rapporten" },
          ]}
        />
        <PageToolbar
          placeholder="Zoek rapport, opdracht, klant of medewerker…"
          result="84 rapporten deze maand"
          onFilter={onFilter}
        >
          <Button
            variant="outline"
            onClick={() => toast.success("Rapportbundel wordt samengesteld")}
          >
            <Download /> Rapportbundel
          </Button>
        </PageToolbar>
        <div className="report-queue">
          {rows.map((row, index) => (
            <article key={row[0]}>
              <div className={`report-proof proof-${index}`}>
                <ClipboardCheck />
                <span>
                  {index === 0 ? "2/3" : "3/3"}
                  <small>bewijs</small>
                </span>
              </div>
              <div className="report-copy">
                <span>
                  {row[0]} · {row[1]}
                </span>
                <strong>{row[2]}</strong>
                <p>
                  <Building2 /> {row[3]} <i /> <UserCog /> {row[4]}
                </p>
              </div>
              <div className="report-check">
                <small>Controle</small>
                <strong>{row[5]}</strong>
                <StatusPill>{row[6]}</StatusPill>
              </div>
              <div className="report-actions">
                <Button
                  variant="outline"
                  onClick={() => onDetail(row[2], `${row[0]} · ${row[3]}`)}
                >
                  Beoordelen
                </Button>
                {index > 0 && (
                  <Button
                    className="primary-button"
                    onClick={() => toast.success(`${row[0]} is goedgekeurd`)}
                  >
                    <Check /> Goedkeuren
                  </Button>
                )}
                <RowActions onOpen={() => onDetail(row[2], row[0])} />
              </div>
            </article>
          ))}
        </div>
      </Panel>
    </div>
  );
}

function DocumentsPage({
  onFilter,
  onDetail,
}: {
  onFilter: () => void;
  onDetail: (title: string, subtitle: string) => void;
}) {
  const files = [
    [
      "Beveiligingsplan Entree A.pdf",
      "Object",
      "World Forum — entree A",
      "Veiligheid",
      "1,8 MB",
      "Vandaag 08:24",
    ],
    [
      "Contract dienstverlening 2026.pdf",
      "Klant",
      "Hofstaete Vastgoed",
      "Contract",
      "840 KB",
      "1 sep 16:42",
    ],
    [
      "BHV-certificaat Sofia.pdf",
      "Medewerker",
      "Sofia de Jong",
      "Kwalificatie",
      "320 KB",
      "30 aug 12:10",
    ],
    [
      "Werkbonrapport FG-2048.pdf",
      "Opdracht",
      "FG-2048",
      "Rapport",
      "2,4 MB",
      "28 aug 18:04",
    ],
  ];
  return (
    <div className="page-flow documents-page">
      <div className="document-workspace">
        <aside className="document-sidebar surface-panel">
          <div>
            <span>Bibliotheek</span>
            <strong>Documenten</strong>
          </div>
          <nav>
            {[
              [FolderOpen, "Alle documenten", "284"],
              [BriefcaseBusiness, "Klanten", "68"],
              [Building2, "Objecten", "92"],
              [UserCog, "Medewerkers", "54"],
              [ClipboardList, "Opdrachten", "70"],
            ].map(([Icon, label, count], index) => {
              const I = Icon as LucideIcon;
              return (
                <button
                  type="button"
                  key={String(label)}
                  className={index === 0 ? "is-active" : ""}
                >
                  <I />
                  <span>{String(label)}</span>
                  <em>{String(count)}</em>
                </button>
              );
            })}
          </nav>
          <hr />
          <button type="button">
            <Archive /> Archief
          </button>
          <button type="button">
            <Trash2 /> Prullenbak
          </button>
        </aside>
        <Panel className="data-panel document-list-panel">
          <PageToolbar
            placeholder="Zoek bestandsnaam, dossier of categorie…"
            result="284 documenten"
            onFilter={onFilter}
          >
            <Button
              variant="outline"
              onClick={() => toast.success("Nieuwe map aangemaakt")}
            >
              <FolderOpen /> Nieuwe map
            </Button>
          </PageToolbar>
          <div className="document-summary">
            <div>
              <span>
                <FileText />
              </span>
              <strong>284</strong>
              <small>bestanden</small>
            </div>
            <div>
              <span>
                <Gauge />
              </span>
              <strong>1,8 GB</strong>
              <small>opslag gebruikt</small>
            </div>
            <div>
              <span>
                <AlertCircle />
              </span>
              <strong>7</strong>
              <small>verloopt binnen 30 dagen</small>
            </div>
          </div>
          <div className="desktop-table">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Naam</TableHead>
                  <TableHead>Gekoppeld aan</TableHead>
                  <TableHead>Categorie</TableHead>
                  <TableHead>Grootte</TableHead>
                  <TableHead>Gewijzigd</TableHead>
                  <TableHead />
                </TableRow>
              </TableHeader>
              <TableBody>
                {files.map((file) => (
                  <TableRow key={file[0]}>
                    <TableCell>
                      <button
                        className="file-cell"
                        onClick={() =>
                          onDetail(file[0], `${file[1]} · ${file[2]}`)
                        }
                      >
                        <span>
                          <FileText />
                        </span>
                        <strong>{file[0]}</strong>
                      </button>
                    </TableCell>
                    <TableCell>
                      <small>{file[1]}</small>
                      <strong className="table-value">{file[2]}</strong>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{file[3]}</Badge>
                    </TableCell>
                    <TableCell>{file[4]}</TableCell>
                    <TableCell>{file[5]}</TableCell>
                    <TableCell className="action-cell">
                      <RowActions
                        onOpen={() => onDetail(file[0], file[2])}
                        duplicateLabel="Nieuwe versie"
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <div className="mobile-card-list">
            {files.map((file) => (
              <article className="mobile-data-card" key={file[0]}>
                <div className="mobile-data-card-toolbar">
                  <small>{file[3]}</small>
                  <span>{file[4]}</span>
                  <RowActions
                    onOpen={() => onDetail(file[0], `${file[1]} · ${file[2]}`)}
                    duplicateLabel="Nieuwe versie"
                  />
                </div>
                <button
                  type="button"
                  className="mobile-data-card-main"
                  onClick={() => onDetail(file[0], `${file[1]} · ${file[2]}`)}
                >
                  <strong>{file[0]}</strong>
                  <span>{file[2]}</span>
                  <span>{file[5]}</span>
                </button>
              </article>
            ))}
          </div>
        </Panel>
      </div>
    </div>
  );
}

function TicketsPage({
  onFilter,
  onDetail,
}: {
  onFilter: () => void;
  onDetail: (title: string, subtitle: string) => void;
}) {
  const columns = [
    {
      title: "Nieuw",
      count: 3,
      items: [
        ["TCK-184", "Extra sleutel aanvragen", "Hofstaete", "Hoog"],
        ["TCK-181", "Wijziging factuuradres", "VvE Parkzijde", "Normaal"],
      ],
    },
    {
      title: "In behandeling",
      count: 5,
      items: [
        ["TCK-179", "Toegang medewerkersportaal", "Naomi Vermeer", "Normaal"],
        ["TCK-172", "Afwijking avondsluiting", "World Forum", "Hoog"],
      ],
    },
    {
      title: "Wacht op klant",
      count: 2,
      items: [
        ["TCK-168", "Bevestiging extra dienst", "Gemeente Rijswijk", "Normaal"],
      ],
    },
    {
      title: "Opgelost",
      count: 18,
      items: [["TCK-161", "Nieuwe contactpersoon", "Hofstaete", "Laag"]],
    },
  ];
  return (
    <div className="page-flow tickets-page">
      <Panel className="data-panel">
        <PageToolbar
          placeholder="Zoek ticket, aanvrager of onderwerp…"
          result="28 tickets"
          onFilter={onFilter}
        >
          <div className="view-segment compact">
            <button className="is-active">Bord</button>
            <button>Lijst</button>
          </div>
        </PageToolbar>
        <div className="ticket-board">
          {columns.map((column, columnIndex) => (
            <section key={column.title}>
              <header>
                <span className={`column-dot dot-${columnIndex}`} />
                <strong>{column.title}</strong>
                <em>{column.count}</em>
                <button aria-label="Kolommenu">
                  <MoreHorizontal />
                </button>
              </header>
              <div>
                {column.items.map((item) => (
                  <button
                    type="button"
                    draggable
                    key={item[0]}
                    onClick={() => onDetail(item[1], `${item[0]} · ${item[2]}`)}
                  >
                    <span>
                      <small>{item[0]}</small>
                      <GripVertical />
                    </span>
                    <strong>{item[1]}</strong>
                    <span className="ticket-description">{item[2]}</span>
                    <span className="ticket-footer">
                      <StatusPill
                        tone={item[3] === "Hoog" ? "warning" : "neutral"}
                      >
                        {item[3]}
                      </StatusPill>
                      <span className="mini-avatar">
                        {item[2]
                          .split(" ")
                          .map((part) => part[0])
                          .join("")
                          .slice(0, 2)}
                      </span>
                    </span>
                  </button>
                ))}
              </div>
              <button
                type="button"
                className="add-ticket"
                onClick={() => toast.info(`Nieuw ticket in ${column.title}`)}
              >
                <Plus /> Ticket toevoegen
              </button>
            </section>
          ))}
        </div>
      </Panel>
    </div>
  );
}

function NewsPage({
  onDetail,
}: {
  onDetail: (title: string, subtitle: string) => void;
}) {
  const posts = [
    [
      "Nieuwe werkinstructie avondsluiting",
      "Medewerkers · World Forum",
      "Vandaag 08:15",
      "Gepubliceerd",
      "NW",
    ],
    [
      "Planning rond Prinsjesdag",
      "Alle medewerkers",
      "1 sep 16:30",
      "Ingepland",
      "PP",
    ],
    ["Klantupdate september", "Alle klanten", "31 aug 11:20", "Concept", "KS"],
    [
      "Welkom bij de vernieuwde portal",
      "Nieuwe gebruikers",
      "28 aug 09:00",
      "Gepubliceerd",
      "WP",
    ],
  ];
  return (
    <div className="page-flow news-page">
      <div className="model-warning">
        <AlertCircle />
        <div>
          <strong>Doelontwerp — nog niet productiegeschikt</strong>
          <p>
            De huidige tenantinterface en het platform-only nieuwsmodel spreken
            elkaar tegen. Herstel tenant-scope en doelgroepen voordat publiceren
            wordt vrijgegeven.
          </p>
        </div>
      </div>
      <div className="news-layout">
        <Panel className="data-panel">
          <InteractiveListTabs
            items={[
              { label: "Alle berichten" },
              { label: "Concept" },
              { label: "Ingepland" },
              { label: "Gepubliceerd" },
            ]}
          />
          <PageToolbar
            placeholder="Zoek titel, doelgroep of auteur…"
            result="24 berichten"
            onFilter={() => toast.info("Doelgroepfilters geopend")}
          />
          <div className="news-list">
            {posts.map((post, index) => (
              <button
                type="button"
                key={post[0]}
                onClick={() => onDetail(post[0], post[1])}
              >
                <span className={`news-thumb thumb-${index}`}>
                  <Newspaper />
                  <i>{post[4]}</i>
                </span>
                <span className="news-copy">
                  <StatusPill>{post[3]}</StatusPill>
                  <strong>{post[0]}</strong>
                  <span className="news-meta">
                    {post[1]} · {post[2]}
                  </span>
                </span>
                <ChevronRight />
              </button>
            ))}
          </div>
        </Panel>
        <aside className="news-side">
          <Panel eyebrow="Publicatie" title="Doelgroepen">
            <div className="audience-stats">
              <div>
                <Users />
                <span>
                  <strong>54</strong>
                  <small>medewerkers</small>
                </span>
              </div>
              <div>
                <BriefcaseBusiness />
                <span>
                  <strong>42</strong>
                  <small>klanten</small>
                </span>
              </div>
              <div>
                <Tags />
                <span>
                  <strong>6</strong>
                  <small>segmenten</small>
                </span>
              </div>
            </div>
          </Panel>
          <Panel eyebrow="Hierna" title="Geplande berichten">
            <div className="scheduled-post">
              <time>
                03<small>SEP</small>
              </time>
              <div>
                <strong>Planning Prinsjesdag</strong>
                <small>07:30 · alle medewerkers</small>
              </div>
            </div>
            <div className="scheduled-post">
              <time>
                07<small>SEP</small>
              </time>
              <div>
                <strong>Maandelijkse klantupdate</strong>
                <small>09:00 · actieve klanten</small>
              </div>
            </div>
          </Panel>
        </aside>
      </div>
    </div>
  );
}

function WebsitePage() {
  const [section, setSection] = React.useState("hero");
  const [device, setDevice] = React.useState("desktop");
  const [workspaceTab, setWorkspaceTab] = React.useState("Studio");
  const [libraryOpen, setLibraryOpen] = React.useState(true);
  const websiteTabs = [
    "Studio",
    "Pagina’s",
    "Blog",
    "Formulieren",
    "Inzendingen",
    "Navigatie",
    "Redirects",
    "Publicatiecheck",
    "Instellingen",
  ];
  return (
    <div className="page-flow website-page">
      <Panel className="website-shell">
        <div className="website-tabs">
          {websiteTabs.map((tab) => (
            <button
              type="button"
              key={tab}
              className={workspaceTab === tab ? "is-active" : ""}
              aria-pressed={workspaceTab === tab}
              onClick={() => {
                setWorkspaceTab(tab);
                toast.info(`${tab} geopend`);
              }}
            >
              {tab} {tab === "Inzendingen" && <span>8</span>}
            </button>
          ))}
        </div>
        <div className="studio-toolbar">
          <div>
            <StatusPill tone="warning">Concept</StatusPill>
            <strong>{workspaceTab === "Studio" ? "Homepage" : workspaceTab}</strong>
            <span>Laatste opslag 09:38</span>
          </div>
          <div className="device-toggle">
            <button
              className={device === "desktop" ? "is-active" : ""}
              onClick={() => setDevice("desktop")}
            >
              <PanelTop /> Desktop
            </button>
            <button
              className={device === "mobile" ? "is-active" : ""}
              onClick={() => setDevice("mobile")}
            >
              <Columns3 /> Mobiel
            </button>
          </div>
          <div>
            {!libraryOpen && (
              <Button
                className="studio-library-toggle"
                variant="outline"
                onClick={() => setLibraryOpen(true)}
              >
                <PanelLeftClose /> Bibliotheek
              </Button>
            )}
            <Button
              variant="outline"
              onClick={() => toast.info("Voorbeeld geopend")}
            >
              <ExternalLink /> Voorbeeld
            </Button>
            <Button
              className="primary-button"
              onClick={() => toast.success("Publicatiecheck is gestart")}
            >
              <Send /> Naar publicatie
            </Button>
          </div>
        </div>
        <div className={`website-studio-grid${libraryOpen ? "" : " is-library-closed"}`}>
          <aside className="section-library">
            <div>
              <span>Onderdelen</span>
              <button
                type="button"
                aria-label="Bibliotheek sluiten"
                onClick={() => setLibraryOpen(false)}
              >
                <PanelLeftClose />
              </button>
            </div>
            <label>
              <Search />
              <input placeholder="Zoek sectie…" />
            </label>
            <nav>
              {[
                [LayoutDashboard, "Hero", "Intro met hoofdactie", "hero"],
                [Star, "Bewijs", "Keurmerken en cijfers", "proof"],
                [Blocks, "Diensten", "Modulaire dienstkaarten", "services"],
                [MessageSquareText, "Reviews", "Klantervaringen", "reviews"],
                [Mail, "Contact", "Formulier en bereikbaarheid", "contact"],
              ].map(([Icon, label, detail, id]) => {
                const I = Icon as LucideIcon;
                return (
                  <button
                    type="button"
                    key={String(id)}
                    onClick={() => setSection(String(id))}
                  >
                    <span>
                      <I />
                    </span>
                    <span className="section-library-copy">
                      <strong>{String(label)}</strong>
                      <small>{String(detail)}</small>
                    </span>
                    <Plus />
                  </button>
                );
              })}
            </nav>
          </aside>
          <section className={`page-canvas device-${device}`}>
            <div className="browser-chrome">
              <i />
              <i />
              <i />
              <span>veeleservices.nl</span>
            </div>
            <div className="canvas-page">
              <section
                className={section === "hero" ? "is-selected" : ""}
                onClick={() => setSection("hero")}
              >
                <div className="selection-label">
                  Hero · klik om te bewerken
                </div>
                <nav>
                  <strong>Veele Services</strong>
                  <span>Diensten</span>
                  <span>Over ons</span>
                  <span>Contact</span>
                  <button>Offerte aanvragen</button>
                </nav>
                <div className="fake-hero">
                  <span>FACILITAIRE DIENSTVERLENING</span>
                  <h3>
                    Schoon. Veilig.
                    <br />
                    Altijd geregeld.
                  </h3>
                  <p>
                    Eén betrouwbare partner voor schoonmaak, beveiliging en
                    facilitaire ondersteuning in Haaglanden.
                  </p>
                  <button>
                    Plan een kennismaking <ArrowRight />
                  </button>
                </div>
              </section>
              <section
                className={
                  section === "proof"
                    ? "is-selected proof-section"
                    : "proof-section"
                }
                onClick={() => setSection("proof")}
              >
                <div className="selection-label">Bewijs</div>
                <div>
                  <strong>12+</strong>
                  <small>jaar ervaring</small>
                </div>
                <div>
                  <strong>98%</strong>
                  <small>klanttevredenheid</small>
                </div>
                <div>
                  <strong>24/7</strong>
                  <small>bereikbaar</small>
                </div>
              </section>
              <section
                className={
                  section === "services"
                    ? "is-selected service-section"
                    : "service-section"
                }
                onClick={() => setSection("services")}
              >
                <div className="selection-label">Diensten</div>
                <h4>Alles onder één dak</h4>
                <div>
                  <article>
                    <ShieldCheck />
                    <strong>Beveiliging</strong>
                  </article>
                  <article>
                    <Sparkles />
                    <strong>Schoonmaak</strong>
                  </article>
                  <article>
                    <Building2 />
                    <strong>Facilitair</strong>
                  </article>
                </div>
              </section>
            </div>
          </section>
          <aside className="property-panel">
            <div>
              <span>Eigenschappen</span>
              <RowActions
                duplicateLabel="Sectie dupliceren"
                archiveLabel="Sectie verwijderen"
              />
            </div>
            <div className="property-group">
              <label>
                Interne naam
                <Input
                  value={
                    section === "hero" ? "Homepage hero" : `Sectie ${section}`
                  }
                  readOnly
                />
              </label>
              <label>
                Layout
                <Select defaultValue="split">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="split">Tekst links</SelectItem>
                    <SelectItem value="center">Gecentreerd</SelectItem>
                    <SelectItem value="full">Volledige breedte</SelectItem>
                  </SelectContent>
                </Select>
              </label>
            </div>
            <div className="property-group">
              <h4>Inhoud</h4>
              <label>
                Kop
                <Input defaultValue="Schoon. Veilig. Altijd geregeld." />
              </label>
              <label>
                Intro
                <Textarea defaultValue="Eén betrouwbare partner voor schoonmaak, beveiliging en facilitaire ondersteuning in Haaglanden." />
              </label>
            </div>
            <div className="property-group">
              <h4>Weergave</h4>
              <label className="switch-row">
                <span>
                  <strong>Donkere overlay</strong>
                  <small>Verbetert leesbaarheid</small>
                </span>
                <Switch defaultChecked />
              </label>
              <label className="switch-row">
                <span>
                  <strong>Toon op mobiel</strong>
                  <small>Responsive zichtbaar</small>
                </span>
                <Switch defaultChecked />
              </label>
            </div>
            <Button
              className="primary-button"
              onClick={() => toast.success("Sectie is opgeslagen")}
            >
              <Save /> Wijzigingen opslaan
            </Button>
          </aside>
        </div>
      </Panel>
    </div>
  );
}

function ChecklistsPage({
  onFilter,
  onDetail,
}: {
  onFilter: () => void;
  onDetail: (title: string, subtitle: string) => void;
}) {
  const templates = [
    [
      "Dagelijkse schoonmaakcontrole",
      "Schoonmaak",
      "14 onderdelen",
      "18 objecten",
      "Verplicht",
      "Actief",
    ],
    [
      "Openingsronde beveiliging",
      "Beveiliging",
      "9 onderdelen",
      "6 objecten",
      "Prioriteit 10",
      "Actief",
    ],
    [
      "Opleverinspectie",
      "Kwaliteit",
      "22 onderdelen",
      "Alle opdrachten",
      "Bij status voltooid",
      "Actief",
    ],
    [
      "Materiaaluitgifte",
      "Middelen",
      "7 onderdelen",
      "Magazijnen",
      "Na opdrachtchecklist",
      "Concept",
    ],
  ];
  return (
    <div className="page-flow checklists-page">
      <div className="quality-flow">
        <Panel
          eyebrow="Toepassingslogica"
          title="Van bron naar uitvoeringscheck"
          action={<StatusPill tone="success">Geen conflicten</StatusPill>}
        >
          <div className="rule-flow">
            <div>
              <span>1</span>
              <strong>Algemene standaard</strong>
              <small>organisatiebreed</small>
            </div>
            <ArrowRight />
            <div>
              <span>2</span>
              <strong>Sector & klanttype</strong>
              <small>specifieke aanvulling</small>
            </div>
            <ArrowRight />
            <div>
              <span>3</span>
              <strong>Object</strong>
              <small>lokale instructie</small>
            </div>
            <ArrowRight />
            <div>
              <span>4</span>
              <strong>Opdracht</strong>
              <small>hoogste prioriteit</small>
            </div>
          </div>
          <div className="rule-note">
            <ShieldCheck />
            <p>
              <strong>Conflictregel:</strong> een specifieker niveau wint. Bij
              gelijke prioriteit geldt de hoogste ingestelde rangorde.
              Verwijderen vraagt om een keuze: ontkoppelen, vervangen of
              annuleren.
            </p>
            <Button
              variant="outline"
              onClick={() =>
                onDetail(
                  "Conflict- en verwijderregels",
                  "Voorvertoning van de beslisboom",
                )
              }
            >
              Regels bekijken
            </Button>
          </div>
        </Panel>
      </div>
      <Panel className="data-panel">
        <InteractiveListTabs
          items={[
            { label: "Templates", count: "18" },
            { label: "Sets" },
            { label: "Toepassingen" },
            { label: "Conflicten" },
            { label: "Resultaten" },
          ]}
        />
        <PageToolbar
          placeholder="Zoek checklist, sector, object of taakcode…"
          result="18 templates"
          onFilter={onFilter}
        >
          <Button
            variant="outline"
            onClick={() => toast.success("Templatebibliotheek geëxporteerd")}
          >
            <Download /> Exporteren
          </Button>
        </PageToolbar>
        <div className="checklist-grid">
          {templates.map((template, index) => (
            <article key={template[0]}>
              <header>
                <span
                  className={`checklist-icon color-${["mint", "blue", "lilac", "orange"][index]}`}
                >
                  <ClipboardCheck />
                </span>
                <RowActions
                  onOpen={() =>
                    onDetail(template[0], `${template[1]} · ${template[2]}`)
                  }
                />
              </header>
              <small>{template[1]}</small>
              <h3>{template[0]}</h3>
              <div>
                <span>{template[2]}</span>
                <span>{template[3]}</span>
              </div>
              <p>
                <Workflow /> {template[4]}
              </p>
              <footer>
                <StatusPill>{template[5]}</StatusPill>
                <Button
                  variant="outline"
                  onClick={() =>
                    onDetail(template[0], `${template[2]} · ${template[3]}`)
                  }
                >
                  Open template
                </Button>
              </footer>
            </article>
          ))}
        </div>
      </Panel>
    </div>
  );
}

const settingsSections = [
  ["organization", "Organisatie", "Bedrijfsgegevens en werkgebied", Building2],
  ["branding", "Huisstijl", "Logo, kleuren en portals", Sparkles],
  ["users", "Gebruikers", "Toegang en uitnodigingen", Users],
  ["roles", "Rollen & rechten", "Modules en dossieronderdelen", KeyRound],
  ["sectors", "Sectoren & klanttypen", "Catalogus en toepassingsbeleid", Tags],
  ["qualifications", "Kwalificaties", "Bevoegdheden en verloop", BadgeCheck],
  ["taskcodes", "Taakcodes", "Standaardtaken en tarieven", ClipboardList],
  ["automation", "Slim plannen", "Matches, reistijd en regels", WandSparkles],
  ["notifications", "Notificaties", "Kanalen, events en ontvangers", Bell],
  ["mail", "E-mail", "Afzender en templates", Mail],
  ["billing", "Facturatie", "Nummering, betaling en btw", ReceiptText],
  ["audit", "Activiteitslog", "Wijzigingen en beveiliging", History],
] as const;

function SettingsPage() {
  const [section, setSection] = React.useState("organization");
  const current =
    settingsSections.find((item) => item[0] === section) ?? settingsSections[0];
  const CurrentIcon = current[3];
  return (
    <div className="page-flow settings-page">
      <div className="settings-workspace">
        <aside className="settings-index surface-panel">
          <div>
            <span>Instellingen</span>
            <strong>Veele Services</strong>
          </div>
          <label>
            <Search />
            <input placeholder="Zoek instelling…" />
          </label>
          <nav>
            {settingsSections.map(([id, label, detail, Icon]) => (
              <button
                type="button"
                key={id}
                className={section === id ? "is-active" : ""}
                onClick={() => setSection(id)}
              >
                <Icon />
                <span>
                  <strong>{label}</strong>
                  <small>{detail}</small>
                </span>
                <ChevronRight />
              </button>
            ))}
          </nav>
        </aside>
        <section className="settings-content">
          <Panel
            eyebrow="Organisatiebeheer"
            title={current[1]}
            action={
              <StatusPill tone="success">Wijzigingen opgeslagen</StatusPill>
            }
          >
            <div className="settings-section-intro">
              <span>
                <CurrentIcon />
              </span>
              <div>
                <h3>{current[1]}</h3>
                <p>
                  {current[2]}. Beheer dit zonder andere instellingen uit
                  context te halen.
                </p>
              </div>
            </div>
            {section === "roles" ? (
              <div className="permission-matrix">
                <div className="matrix-head">
                  <span>Rol / onderdeel</span>
                  <span>Bekijken</span>
                  <span>Toevoegen</span>
                  <span>Wijzigen</span>
                  <span>Verwijderen</span>
                </div>
                {[
                  ["Planner", true, true, true, false],
                  ["Objectleider", true, true, true, false],
                  ["Administratie", true, true, true, true],
                  ["Klantbeheer", true, true, true, false],
                ].map((row) => (
                  <div key={String(row[0])}>
                    <strong>{String(row[0])}</strong>
                    {row.slice(1).map((value, index) => (
                      <Checkbox
                        key={index}
                        checked={Boolean(value)}
                        aria-label={`${row[0]} recht ${index + 1}`}
                      />
                    ))}
                  </div>
                ))}
                <div className="matrix-note">
                  <ShieldCheck />
                  <span>
                    <strong>Dossieronderdeelrechten</strong>
                    <small>
                      Gevoelige onderdelen zoals verzuim, financiën en
                      objecttoegang krijgen afzonderlijke rechten.
                    </small>
                  </span>
                  <Button variant="outline">Fijnmazige rechten</Button>
                </div>
              </div>
            ) : section === "automation" ? (
              <div className="automation-rules">
                {[
                  [
                    "Kwalificatie is verplicht",
                    "Kandidaten zonder alle vereisten uitsluiten",
                    true,
                  ],
                  [
                    "Reistijd bewaken",
                    "Waarschuw bij minder dan 20 minuten marge",
                    true,
                  ],
                  [
                    "Belasting balanceren",
                    "Geef lagere weekbelasting voorrang",
                    true,
                  ],
                  [
                    "Automatisch toewijzen",
                    "Nooit zonder handmatige bevestiging",
                    false,
                  ],
                ].map((rule) => (
                  <label key={String(rule[0])}>
                    <span>
                      <strong>{String(rule[0])}</strong>
                      <small>{String(rule[1])}</small>
                    </span>
                    <Switch defaultChecked={Boolean(rule[2])} />
                  </label>
                ))}
              </div>
            ) : (
              <form
                className="settings-form"
                onSubmit={(event) => {
                  event.preventDefault();
                  toast.success(`${current[1]} is opgeslagen`);
                }}
              >
                <div className="form-section">
                  <div>
                    <h4>Basisinstellingen</h4>
                    <p>
                      Gegevens die op alle relevante plekken worden hergebruikt.
                    </p>
                  </div>
                  <div className="form-grid">
                    <label>
                      Weergavenaam
                      <Input
                        defaultValue={
                          section === "organization"
                            ? "Veele Services"
                            : String(current[1])
                        }
                      />
                    </label>
                    <label>
                      Verantwoordelijke
                      <Select defaultValue="danny">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="danny">
                            Danny Goldenbelt
                          </SelectItem>
                          <SelectItem value="sanne">Sanne van Delft</SelectItem>
                        </SelectContent>
                      </Select>
                    </label>
                    <label className="span-2">
                      Omschrijving
                      <Textarea
                        defaultValue={`${current[2]} voor de tenant Veele Services.`}
                      />
                    </label>
                  </div>
                </div>
                <div className="form-section">
                  <div>
                    <h4>Gedrag & zichtbaarheid</h4>
                    <p>
                      Veilige standaardinstellingen met een duidelijke uitleg.
                    </p>
                  </div>
                  <div className="switch-list">
                    <label>
                      <span>
                        <strong>Actief voor deze organisatie</strong>
                        <small>
                          Onderdeel is beschikbaar voor bevoegde gebruikers.
                        </small>
                      </span>
                      <Switch defaultChecked />
                    </label>
                    <label>
                      <span>
                        <strong>Wijzigingen auditen</strong>
                        <small>
                          Actor, moment en wijziging veilig vastleggen.
                        </small>
                      </span>
                      <Switch defaultChecked />
                    </label>
                    <label>
                      <span>
                        <strong>Bevestiging bij impact</strong>
                        <small>
                          Toon een samenvatting vóór ingrijpende wijzigingen.
                        </small>
                      </span>
                      <Switch defaultChecked />
                    </label>
                  </div>
                </div>
                <div className="sticky-save">
                  <span>
                    <CheckCircle2 /> Alle verplichte velden zijn ingevuld
                  </span>
                  <Button variant="outline" type="button">
                    Annuleren
                  </Button>
                  <Button className="primary-button" type="submit">
                    <Save /> Opslaan
                  </Button>
                </div>
              </form>
            )}
          </Panel>
        </section>
      </div>
    </div>
  );
}

function SupportPage() {
  return (
    <div className="page-flow support-page">
      <div className="support-search">
        <BookOpen />
        <div>
          <span>Hoe kunnen we helpen?</span>
          <label>
            <Search />
            <input placeholder="Zoek in handleidingen, releases en roadmap…" />
            <kbd>Enter</kbd>
          </label>
        </div>
      </div>
      <div className="support-grid">
        <Panel eyebrow="Kennisbank" title="Veel gebruikt">
          <div className="support-links">
            {[
              [CalendarDays, "Werken met het planbord", "8 min"],
              [KeyRound, "Rollen en dossieronderdelen", "6 min"],
              [ReceiptText, "Van rapport naar factuur", "5 min"],
              [Globe2, "Website publiceren", "7 min"],
            ].map(([Icon, title, time]) => {
              const I = Icon as LucideIcon;
              return (
                <button type="button" key={String(title)}>
                  <I />
                  <span>
                    <strong>{String(title)}</strong>
                    <small>Handleiding · {String(time)}</small>
                  </span>
                  <ArrowRight />
                </button>
              );
            })}
          </div>
        </Panel>
        <Panel eyebrow="Ondersteuning" title="Mijn tickets">
          <div className="support-ticket">
            <StatusPill tone="info">In behandeling</StatusPill>
            <strong>Vraag over verzamelrun</strong>
            <small>TCK-166 · reactie 1 uur geleden</small>
          </div>
          <Button
            variant="outline"
            onClick={() => toast.info("Nieuw supportticket geopend")}
          >
            <Plus /> Nieuw supportticket
          </Button>
        </Panel>
      </div>
      <div className="support-grid three">
        <Panel eyebrow="Wat is er nieuw?" title="September-update">
          <p className="support-copy">
            Sneller plannen, fijnmazige dossierrechten en verbeterde mobiele
            lijsten.
          </p>
          <button className="text-action">
            Bekijk release notes <ArrowRight />
          </button>
        </Panel>
        <Panel eyebrow="Roadmap" title="In onderzoek">
          <p className="support-copy">
            AI-voorstellen voor roosteroptimalisatie met menselijke
            eindcontrole.
          </p>
          <button className="text-action">
            Bekijk roadmap <ArrowRight />
          </button>
        </Panel>
        <Panel eyebrow="Systeemstatus" title="Alles werkt">
          <div className="system-lines">
            <span>
              <i />
              Portalen <strong>Operationeel</strong>
            </span>
            <span>
              <i />
              E-mail <strong>Operationeel</strong>
            </span>
            <span>
              <i />
              Realtime <strong>Operationeel</strong>
            </span>
          </div>
        </Panel>
      </div>
    </div>
  );
}

function AnalysisPage({ onDesign }: { onDesign: (id: DesignId) => void }) {
  const findings = [
    [
      "P0",
      "Sectoren en klanttypen",
      "Tenantpagina’s muteren globale catalogi zonder tenant-scope. Verplaats naar platformbeheer of maak tenantbeleid expliciet.",
    ],
    [
      "P0",
      "Nieuwsdoelgroepen",
      "De tenant-UI belooft tenant- en individuele doelgroepen, terwijl het datamodel platform-only afdwingt. Eerst één eigenaarsmodel kiezen.",
    ],
    [
      "P0",
      "Rollen & rechten",
      "De rollen-editor wijzigt de globale functiecatalogus, terwijl runtime tenantrollen gebruikt. Toegangsbeheer en operationele functies zijn daardoor vervuild.",
    ],
    [
      "P0",
      "Gebruiker deactiveren",
      "Een tenantactie bant nu het globale account, ook wanneer iemand bij meerdere organisaties hoort. Dit moet een tenantlidmaatschapactie worden.",
    ],
    [
      "P0",
      "Verlofmelding verkeerde tenant",
      "De personeels-PWA pakt organisatie-instellingen met limit(1) zonder tenantfilter. Een verlofmelding kan daardoor naar de verkeerde organisatie gaan.",
    ],
    [
      "P0",
      "Onderbezette planning kan vol lijken",
      "Opslaan gebruikt het aantal rollen in plaats van requiredPersonnelCount. Een opdracht voor vijf personen kan na één toewijzing als bezet verdwijnen.",
    ],
    [
      "P0",
      "Kwalificaties cross-tenant",
      "Bekende UUID’s kunnen kwalificatie- en taakcodekoppelingen buiten de actieve tenant wijzigen. Iedere mutatie moet tenantownership afdwingen.",
    ],
    [
      "P1",
      "Actiepermissies middelen",
      "Gebundelde canWrite-flags tonen acties waarvoor een gebruiker geen specifiek recht heeft en verbergen soms toegestane acties.",
    ],
    [
      "P1",
      "Planbord verschuift verborgen vervolgwerk",
      "Drag-and-drop kan later werk verplaatsen, medewerkers ontkoppelen en opdrachten terugzetten zonder impactpreview; de huidige undo herstelt niet alles.",
    ],
    [
      "P1",
      "Gebroken week- en detailfilters",
      "Planning heeft overlappende dag/weekimplementaties; meerdere dossierlinks openen opdrachten of facturen zonder het meegegeven klant-, object- of medewerkerfilter.",
    ],
    [
      "P1",
      "Slim-plan-gewichten",
      "De UI belooft normalisatie naar 100%, maar de engine telt ruwe gewichten op. Daardoor kunnen topmatches onmogelijk of juist verzadigd raken.",
    ],
    [
      "P1",
      "Dossierverwijdering",
      "Object en medewerker tonen permanent verwijderen terwijl Dossier 360 referenties dit blokkeren. Gebruik een expliciete actief-inactief-archief-retentiecyclus.",
    ],
    [
      "P1",
      "Offertefeedback",
      "Meerdere succesvolle offertemutaties verversen de clientstaat niet; de gebruiker blijft een oude status zien.",
    ],
  ];
  const coverage = [
    [
      "Start & signalen",
      "Dashboard, rolrelevante KPI’s, aandachtstrip, agenda, snelle acties, recente dossiers",
      "Vandaag",
    ],
    [
      "Planning",
      "Bord/dag/week/maand/kaart, werkvoorraad, matches, conflicten, reistijd, zoom/dichtheid",
      "Planbord",
    ],
    [
      "Opdrachten",
      "Lijst, filters, opgeslagen weergaven, bulk, rijacties, statusflow, personeel, rapportage",
      "Opdrachten",
    ],
    [
      "Klantdossier 360",
      "Organisatie, contacten, contracten, financiën, kwaliteit, objecten, werk, documenten, tijdlijn",
      "Klanten → open dossier",
    ],
    [
      "Personeelsdossier 360",
      "Profiel, dienstverband, beschikbaarheid, kwalificaties, historie, verzuim, middelen, portaal",
      "Medewerkers → open dossier",
    ],
    [
      "Objectdossier 360",
      "Basis, toegang/MFA, uitvoering, contacten, diensten, team, documenten, tijdlijn, rechten",
      "Objecten → open dossier",
    ],
    [
      "Kwaliteit",
      "Checklisttemplates, prioriteit/conflicten, rapportcontrole, bewijs en documenten",
      "Quality & checklists / Rapporten / Documenten",
    ],
    [
      "Middelen",
      "Voorraad, verbruik, transfers, besteladvies, assets, QR, uitgifte, onderhoud, incidenten",
      "Materialen / Bedrijfsmiddelen",
    ],
    [
      "Financiën",
      "Offertes, klantgoedkeuring, facturen, betalingen, creditnota, export, verzamelruns",
      "Offertes / Facturen",
    ],
    [
      "Communicatie",
      "Ticketboard, nieuws, doelgroepselectie, kennisbank, releases en roadmap",
      "Tickets / Nieuws / Help",
    ],
    [
      "Website",
      "Pagina’s, sectiecanvas, blog, navigatie, formulieren, inzendingen, redirects, review, publicatie",
      "Websitebeheer",
    ],
    [
      "Beheer",
      "Organisatie, huisstijl, gebruikers, rollen, sectoren, kwalificaties, taakcodes, automatisering, mail, facturatie, audit",
      "Instellingen",
    ],
  ];
  return (
    <div className="page-flow analysis-page">
      <section className="audit-intro surface-panel">
        <div>
          <p className="eyebrow">Geanalyseerde bron</p>
          <h2>De techniek is rijker dan de huidige interface laat voelen.</h2>
          <p>
            De actuele staging-code en de VeyoCast-referenties zijn naast elkaar
            gelegd. Het probleem is niet een tekort aan functies, maar een
            gebrek aan visuele rangorde, consequente patronen en doelgerichte
            werkruimtes.
          </p>
          <div className="source-badges">
            <span>
              <strong>staging</strong> 535b3c6
            </span>
            <span>
              <strong>75</strong> tenantpagina’s
            </span>
            <span>
              <strong>544</strong> backoffice-bronbestanden
            </span>
            <span>
              <strong>235</strong> componenten
            </span>
            <span>
              <strong>64</strong> serveractiemodules
            </span>
          </div>
        </div>
        <div className="audit-score">
          <span>UX-systeem</span>
          <strong>6,4</strong>
          <small>
            sterke basis
            <br />
            versnipperde uitvoering
          </small>
          <i>
            <b style={{ width: "64%" }} />
          </i>
        </div>
      </section>

      <Panel eyebrow="Hoofdconclusie" title="Vier structurele oorzaken">
        <div className="finding-grid">
          <article>
            <span>01</span>
            <h3>Globale compactheid</h3>
            <p>
              De CSS-scope verkleint vrijwel iedere gutter, titel en control
              achteraf. Desktopknoppen komen rond 32–34 px uit en pagina’s
              verliezen ademruimte.
            </p>
          </article>
          <article>
            <span>02</span>
            <h3>Te veel tegelijk</h3>
            <p>
              Zeventien primaire links in zes open groepen, veertien
              instellingentabs en toolbars met zoeken, filters, exports én
              creëren op één niveau.
            </p>
          </article>
          <article>
            <span>03</span>
            <h3>Parallelle patronen</h3>
            <p>
              Nieuwe DataView-, workbench- en dossiercomponenten bestaan naast
              tientallen handgeschreven tabellen, kaarten en inline kleuren.
            </p>
          </article>
          <article>
            <span>04</span>
            <h3>Geen taakrangorde</h3>
            <p>
              Pagina’s tonen veel witte kaders met vrijwel hetzelfde gewicht.
              Aandacht, hoofdtaak, context en beheer concurreren visueel.
            </p>
          </article>
        </div>
      </Panel>

      <div className="analysis-two-column">
        <Panel
          eyebrow="Van huidige naar doelstructuur"
          title="Informatiearchitectuur"
        >
          <div className="ia-list">
            {[
              [
                "Dagelijks",
                "Vandaag · Planbord · Opdrachten",
                "direct zichtbaar",
              ],
              [
                "Dossiers",
                "Klanten · Objecten · Medewerkers",
                "360 als gedeeld patroon",
              ],
              [
                "Team & middelen",
                "Verlof · Materialen · Bedrijfsmiddelen",
                "één operationeel domein",
              ],
              [
                "Kwaliteit",
                "Checklists · Rapportcontrole · Documenten",
                "van norm naar bewijs",
              ],
              [
                "Financieel",
                "Offertes · Facturen · Betalingen",
                "één geldstroom",
              ],
              [
                "Contact & publicatie",
                "Tickets · Nieuws · Website",
                "één communicatiezone",
              ],
              [
                "Beheer",
                "Verticale secties met zoeken",
                "zeldzaam werk uit de hoofdflow",
              ],
            ].map((row, index) => (
              <div key={row[0]}>
                <span>{String(index + 1).padStart(2, "0")}</span>
                <div>
                  <strong>{row[0]}</strong>
                  <p>{row[1]}</p>
                </div>
                <em>{row[2]}</em>
              </div>
            ))}
          </div>
        </Panel>
        <Panel eyebrow="Actiehiërarchie" title="Waar hoort welke handeling?">
          <div className="action-rules">
            <div>
              <span className="rule-primary">Primair</span>
              <strong>Maximaal één zichtbare hoofdactie</strong>
              <p>Bijvoorbeeld Nieuwe opdracht of Publiceren.</p>
            </div>
            <div>
              <span className="rule-secondary">Secundair</span>
              <strong>Hooguit twee frequente acties</strong>
              <p>Filter, vernieuwen of exporteren wanneer echt nodig.</p>
            </div>
            <div>
              <span className="rule-row">Per rij</span>
              <strong>Openen direct; rest in ···</strong>
              <p>
                Bewerken, dupliceren, status en archief logisch gegroepeerd.
              </p>
            </div>
            <div>
              <span className="rule-bulk">Bulk</span>
              <strong>Alleen na selectie zichtbaar</strong>
              <p>Sticky actiebalk met teller, veilige undo en bevestiging.</p>
            </div>
            <div>
              <span className="rule-danger">Destructief</span>
              <strong>Na scheiding en bevestiging</strong>
              <p>Concreet gevolg, target en herstelbaarheid benoemen.</p>
            </div>
          </div>
        </Panel>
      </div>

      <Panel eyebrow="Interactiecontract" title="Eén patroon per soort werk">
        <div className="pattern-grid">
          {[
            [
              FilePenLine,
              "Kleine wijziging",
              "Dialog",
              "Eén besluit of maximaal enkele velden.",
            ],
            [
              PanelLeftClose,
              "Snel bekijken/bewerken",
              "Zijpaneel",
              "Blijf in lijst of planbordcontext.",
            ],
            [
              Workflow,
              "Complex aanmaken",
              "Wizard",
              "Opdracht, medewerker, klant + eerste object.",
            ],
            [
              Globe2,
              "Langdurig redigeren",
              "Volledige werkruimte",
              "Website, nieuws en rijke content.",
            ],
            [
              Trash2,
              "Permanent verwijderen",
              "Bevestigingsdialog",
              "Gevolg, afhankelijkheden en herstel tonen.",
            ],
          ].map(([Icon, label, surface, detail]) => {
            const I = Icon as LucideIcon;
            return (
              <article key={String(label)}>
                <span>
                  <I />
                </span>
                <small>{String(surface)}</small>
                <strong>{String(label)}</strong>
                <p>{String(detail)}</p>
              </article>
            );
          })}
        </div>
      </Panel>

      <Panel
        eyebrow="Vijf richtingen"
        title="Geen kleurvarianten, maar andere shells"
      >
        <div className="design-analysis-grid">
          {designs.map((design) => (
            <button
              type="button"
              key={design.id}
              className={`design-analysis-card design-${design.id}`}
              onClick={() => onDesign(design.id)}
            >
              <span>{design.number}</span>
              <span className="design-analysis-copy">
                <small>{design.descriptor}</small>
                <strong>{design.name}</strong>
                <span className="design-analysis-thesis">{design.thesis}</span>
                <em>
                  Open ontwerp <ArrowRight />
                </em>
              </span>
            </button>
          ))}
        </div>
      </Panel>

      <Panel
        eyebrow="Volledigheidsmatrix"
        title="Alle bestaande functiedomeinen blijven bereikbaar"
      >
        <div
          className="coverage-table"
          role="table"
          aria-label="Functiedekking prototypes"
        >
          <div className="coverage-head" role="row">
            <strong role="columnheader">Domein</strong>
            <strong role="columnheader">Gedekte functies</strong>
            <strong role="columnheader">Waar te testen</strong>
          </div>
          {coverage.map((row) => (
            <div role="row" key={row[0]}>
              <strong role="cell">{row[0]}</strong>
              <span role="cell">{row[1]}</span>
              <em role="cell">{row[2]}</em>
            </div>
          ))}
        </div>
      </Panel>

      <Panel
        eyebrow="Belangrijk vóór productie-ombouw"
        title="Functionele fundamentrisico’s uit de code-audit"
        className="risk-panel"
      >
        <div className="risk-intro">
          <AlertCircle />
          <p>
            Een visueel redesign mag deze punten niet maskeren. Ze zijn tijdens
            de route- en actieanalyse gevonden en moeten in een aparte
            hersteltrack vóór of parallel aan de UI-migratie worden gesloten.
          </p>
        </div>
        <div className="risk-list">
          {findings.map((finding) => (
            <article key={finding[1]}>
              <span className={`severity severity-${finding[0].toLowerCase()}`}>
                {finding[0]}
              </span>
              <div>
                <strong>{finding[1]}</strong>
                <p>{finding[2]}</p>
              </div>
            </article>
          ))}
        </div>
      </Panel>

      <div className="analysis-two-column">
        <Panel eyebrow="Componentdoel" title="Nieuwe vaste bouwstenen">
          <div className="component-tags">
            {[
              "TenantAppShell",
              "GlobalHeader",
              "PageHeader",
              "DataView",
              "FilterSheet",
              "RowActionMenu",
              "BulkActionBar",
              "DossierShell",
              "DossierSectionNav",
              "Planboard",
              "FormSection",
              "EntityWizard",
              "DetailDrawer",
              "ConfirmDialog",
              "StatusBadge",
              "NoticeStack",
            ].map((item) => (
              <span key={item}>{item}</span>
            ))}
          </div>
        </Panel>
        <Panel eyebrow="Acceptatie" title="Ieder ontwerp moet dit bewijzen">
          <ul className="acceptance-list">
            {[
              "Dezelfde rechten, routes en acties",
              "Desktop én echte mobiele taakflow",
              "Planbord: tijd horizontaal, team verticaal",
              "Klant-, object- en personeelsdossier 360",
              "Lijst, filter, rijmenu, bulk en paginering",
              "Sheet, dialog, wizard, feedback en foutstaat",
              "Contrast, toetsenbord, focus en reduced motion",
              "Geen ruwe technische labels in gebruikerscopy",
            ].map((item) => (
              <li key={item}>
                <CheckCircle2 />
                {item}
              </li>
            ))}
          </ul>
        </Panel>
      </div>
    </div>
  );
}

function ConceptPageComposition({
  design,
  view,
  hasDossier,
  onNavigate,
  children,
}: {
  design: DesignId;
  view: ViewId;
  hasDossier: boolean;
  onNavigate: (view: ViewId) => void;
  children: React.ReactNode;
}) {
  const meta = titleMap[view];
  const [northstarView, setNorthstarView] = React.useState("Standaard");
  const pageNumber = String(
    Math.max(1, navItems.findIndex((item) => item.id === view) + 1),
  ).padStart(2, "0");
  const showAtlasInspector = !hasDossier && ![
    "dashboard",
    "planning",
    "analysis",
    "website",
    "settings",
  ].includes(view);
  return (
    <div
      className={`concept-page-composition composition-${design}`}
      data-view={view}
    >
      {design === "northstar" && view !== "dashboard" && (
        <nav className="northstar-view-command" aria-label="Werkweergaven">
          <div>
            <span>Actieve werkweergave</span>
            <strong>{meta.title} · {northstarView}</strong>
          </div>
          {["Standaard", "Mijn werk", "Aandacht"].map((label) => (
            <button
              type="button"
              key={label}
              className={northstarView === label ? "is-active" : ""}
              aria-pressed={northstarView === label}
              onClick={() => {
                setNorthstarView(label);
                toast.info(`Werkweergave ${label.toLowerCase()} actief`);
              }}
            >
              {label}
            </button>
          ))}
          <button
            type="button"
            onClick={() => toast.success("Werkweergave is opgeslagen")}
          >
            <Save /> Weergave opslaan
          </button>
        </nav>
      )}
      {design === "ledger" && (
        <div className="ledger-folio-marker" aria-hidden="true">
          <span>SECTIE {pageNumber}</span>
          <i />
          <em>FIELDGRID · 2026</em>
        </div>
      )}
      <div className="composition-main">{children}</div>
      {design === "atlas" && showAtlasInspector && (
        <aside className="atlas-page-inspector">
          <header>
            <span>INSPECTOR / {pageNumber}</span>
            <h2>{meta.title}</h2>
            <p>Context van de huidige selectie en snelle vervolgstappen.</p>
          </header>
          <dl>
            <div>
              <dt>Selectie</dt>
              <dd>1 actief record</dd>
            </div>
            <div>
              <dt>Laatste wijziging</dt>
              <dd>Vandaag 09:38</dd>
            </div>
            <div>
              <dt>Dossierstatus</dt>
              <dd>Compleet · 92%</dd>
            </div>
          </dl>
          <div>
            <button type="button" onClick={() => onNavigate("documents")}>
              <FolderOpen /> Documenten
            </button>
            <button type="button" onClick={() => onNavigate("planning")}>
              <CalendarDays /> Open planbord
            </button>
            <button type="button" onClick={() => onNavigate("reports")}>
              <ClipboardCheck /> Rapportages
            </button>
          </div>
        </aside>
      )}
    </div>
  );
}

function PageRouter({
  design,
  view,
  dossier,
  onNavigate,
  onCreate,
  onFilter,
  onDetail,
  onOpenDossier,
  onCloseDossier,
  onDesign,
}: {
  design: DesignId;
  view: ViewId;
  dossier: DossierType | null;
  onNavigate: (view: ViewId) => void;
  onCreate: () => void;
  onFilter: () => void;
  onDetail: (title: string, subtitle: string) => void;
  onOpenDossier: (type: DossierType) => void;
  onCloseDossier: () => void;
  onDesign: (id: DesignId) => void;
}) {
  if (dossier)
    return (
      <DossierPage type={dossier} onBack={onCloseDossier} onDetail={onDetail} />
    );
  switch (view) {
    case "dashboard":
      return (
        <DashboardPage
          design={design}
          onNavigate={onNavigate}
          onCreate={onCreate}
        />
      );
    case "planning":
      return (
        <PlanningPage
          onCreate={onCreate}
          onFilter={onFilter}
          onDetail={onDetail}
        />
      );
    case "assignments":
      return <AssignmentsPage onFilter={onFilter} onDetail={onDetail} />;
    case "customers":
      return (
        <EntityListPage
          key="customer"
          type="customer"
          onFilter={onFilter}
          onOpen={onOpenDossier}
        />
      );
    case "objects":
      return (
        <EntityListPage
          key="object"
          type="object"
          onFilter={onFilter}
          onOpen={onOpenDossier}
        />
      );
    case "personnel":
      return (
        <EntityListPage
          key="personnel"
          type="personnel"
          onFilter={onFilter}
          onOpen={onOpenDossier}
        />
      );
    case "leave":
      return <LeavePage onFilter={onFilter} onDetail={onDetail} />;
    case "materials":
      return (
        <MaterialsPage
          kind="materials"
          onFilter={onFilter}
          onDetail={onDetail}
        />
      );
    case "inventory":
      return (
        <MaterialsPage
          kind="inventory"
          onFilter={onFilter}
          onDetail={onDetail}
        />
      );
    case "quotes":
      return (
        <FinancePage key="quotes" kind="quotes" onFilter={onFilter} onDetail={onDetail} />
      );
    case "reports":
      return <ReportsPage onFilter={onFilter} onDetail={onDetail} />;
    case "invoices":
      return (
        <FinancePage key="invoices" kind="invoices" onFilter={onFilter} onDetail={onDetail} />
      );
    case "documents":
      return <DocumentsPage onFilter={onFilter} onDetail={onDetail} />;
    case "tickets":
      return <TicketsPage onFilter={onFilter} onDetail={onDetail} />;
    case "news":
      return <NewsPage onDetail={onDetail} />;
    case "website":
      return <WebsitePage />;
    case "checklists":
      return <ChecklistsPage onFilter={onFilter} onDetail={onDetail} />;
    case "settings":
      return <SettingsPage />;
    case "support":
      return <SupportPage />;
    case "analysis":
      return <AnalysisPage onDesign={onDesign} />;
  }
}

function FilterSheet({
  open,
  onOpen,
}: {
  open: boolean;
  onOpen: (open: boolean) => void;
}) {
  return (
    <Sheet open={open} onOpenChange={onOpen}>
      <SheetContent className="prototype-sheet filter-sheet">
        <SheetHeader>
          <SheetTitle>Filters</SheetTitle>
          <SheetDescription>
            Verfijn de huidige werkruimte. Actieve filters blijven zichtbaar
            boven de resultaten.
          </SheetDescription>
        </SheetHeader>
        <div className="sheet-form">
          <label>
            Status
            <Select defaultValue="active">
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle statussen</SelectItem>
                <SelectItem value="active">Actief & aandacht</SelectItem>
                <SelectItem value="open">Alleen open</SelectItem>
                <SelectItem value="closed">Afgerond</SelectItem>
              </SelectContent>
            </Select>
          </label>
          <label>
            Regio
            <Select defaultValue="haaglanden">
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle regio’s</SelectItem>
                <SelectItem value="haaglanden">Haaglanden</SelectItem>
                <SelectItem value="delft">Delft & Westland</SelectItem>
              </SelectContent>
            </Select>
          </label>
          <label>
            Periode
            <div className="date-pair">
              <Input type="date" defaultValue="2026-09-02" />
              <Input type="date" defaultValue="2026-09-30" />
            </div>
          </label>
          <fieldset>
            <legend>Toon ook</legend>
            <label className="check-row">
              <Checkbox defaultChecked />
              <span>
                <strong>Items met aandacht</strong>
                <small>Conflicten, blokkades en verlopen acties</small>
              </span>
            </label>
            <label className="check-row">
              <Checkbox />
              <span>
                <strong>Gearchiveerde items</strong>
                <small>Alleen wanneer expliciet nodig</small>
              </span>
            </label>
          </fieldset>
          <div className="saved-filter">
            <Star />
            <span>
              <strong>Weergave bewaren</strong>
              <small>Sla deze combinatie op voor later.</small>
            </span>
            <Switch />
          </div>
        </div>
        <SheetFooter>
          <Button
            variant="outline"
            onClick={() => toast.info("Filters zijn hersteld")}
          >
            Herstellen
          </Button>
          <Button
            className="primary-button"
            onClick={() => {
              toast.success("2 filters toegepast");
              onOpen(false);
            }}
          >
            2 filters toepassen
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}

function DetailSheet({
  detail,
  onClose,
}: {
  detail: { title: string; subtitle: string } | null;
  onClose: () => void;
}) {
  return (
    <Sheet open={Boolean(detail)} onOpenChange={(open) => !open && onClose()}>
      <SheetContent className="prototype-sheet detail-sheet">
        <SheetHeader>
          <div className="detail-sheet-icon">
            <ClipboardList />
          </div>
          <SheetTitle>{detail?.title}</SheetTitle>
          <SheetDescription>{detail?.subtitle}</SheetDescription>
        </SheetHeader>
        <Tabs defaultValue="overview" className="detail-tabs">
          <TabsList>
            <TabsTrigger value="overview">Overzicht</TabsTrigger>
            <TabsTrigger value="activity">Activiteit</TabsTrigger>
            <TabsTrigger value="actions">Acties</TabsTrigger>
          </TabsList>
          <TabsContent value="overview">
            <div className="detail-facts">
              <div>
                <span>Status</span>
                <StatusPill tone="info">Actief</StatusPill>
              </div>
              <div>
                <span>Eigenaar</span>
                <strong>Sanne van Delft</strong>
              </div>
              <div>
                <span>Laatste wijziging</span>
                <strong>Vandaag · 09:18</strong>
              </div>
              <div>
                <span>Context</span>
                <strong>Veele Services</strong>
              </div>
            </div>
            <div className="detail-note">
              <MessageSquareText />
              <div>
                <strong>Operationele notitie</strong>
                <p>
                  Controleer de laatste terugkoppeling en rond de open
                  vervolgactie af.
                </p>
              </div>
            </div>
          </TabsContent>
          <TabsContent value="activity">
            <ol className="timeline-list">
              <li>
                <i className="green">
                  <Check />
                </i>
                <div>
                  <strong>Status bijgewerkt</strong>
                  <small>Vandaag · 09:18 · Danny</small>
                </div>
              </li>
              <li>
                <i className="blue">
                  <Pencil />
                </i>
                <div>
                  <strong>Details gewijzigd</strong>
                  <small>Gisteren · 16:42 · Sanne</small>
                </div>
              </li>
            </ol>
          </TabsContent>
          <TabsContent value="actions">
            <div className="sheet-actions">
              <Button
                className="primary-button"
                onClick={() => toast.success("Bewerkmodus geopend")}
              >
                <Pencil /> Bewerken
              </Button>
              <Button
                variant="outline"
                onClick={() => toast.success("Link gekopieerd")}
              >
                <Copy /> Link kopiëren
              </Button>
              <Button
                variant="outline"
                onClick={() => toast.info("Volledige pagina geopend")}
              >
                <ExternalLink /> Volledig openen
              </Button>
            </div>
          </TabsContent>
        </Tabs>
        <SheetFooter>
          <Button variant="outline" onClick={onClose}>
            Sluiten
          </Button>
          <Button
            className="primary-button"
            onClick={() => toast.success("Wijzigingen zijn opgeslagen")}
          >
            <Save /> Opslaan
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}

function EntityWizard({
  open,
  onOpen,
  view,
}: {
  open: boolean;
  onOpen: (open: boolean) => void;
  view: ViewId;
}) {
  const [step, setStep] = React.useState(0);
  const labels: Partial<Record<ViewId, string>> = {
    customers: "klant",
    objects: "object",
    personnel: "medewerker",
    quotes: "offerte",
    invoices: "factuur",
    documents: "document",
    tickets: "ticket",
    news: "bericht",
    website: "pagina",
    checklists: "checklist",
    materials: "materiaal",
    inventory: "bedrijfsmiddel",
  };
  const entity =
    view === "dashboard" || view === "planning" || view === "assignments"
      ? "opdracht"
      : (labels[view] ?? "item");
  const steps =
    entity === "opdracht"
      ? ["Aanvraag", "Klant & locatie", "Uitvoering", "Planning", "Controle"]
      : ["Basis", "Details", "Toegang", "Controle"];
  const done = step === steps.length - 1;
  return (
    <Dialog
      open={open}
      onOpenChange={(nextOpen) => {
        if (!nextOpen) setStep(0);
        onOpen(nextOpen);
      }}
    >
      <DialogContent className="prototype-dialog wizard-dialog" showCloseButton>
        <DialogHeader>
          <DialogTitle>Nieuwe {entity}</DialogTitle>
          <DialogDescription>
            Volg alleen de stappen die nodig zijn. Je kunt altijd terug zonder
            ingevoerde gegevens te verliezen.
          </DialogDescription>
        </DialogHeader>
        <div className="wizard-progress">
          <div>
            <span>
              Stap {step + 1} van {steps.length}
            </span>
            <strong>{steps[step]}</strong>
          </div>
          <Progress value={((step + 1) / steps.length) * 100} />
          <ol>
            {steps.map((label, index) => (
              <li
                key={label}
                className={
                  index === step
                    ? "is-active"
                    : index < step
                      ? "is-complete"
                      : ""
                }
              >
                <span>{index < step ? <Check /> : index + 1}</span>
                <small>{label}</small>
              </li>
            ))}
          </ol>
        </div>
        <div className="wizard-body">
          {done ? (
            <div className="wizard-review">
              <span>
                <CheckCircle2 />
              </span>
              <h3>Klaar om aan te maken</h3>
              <p>
                Controleer de kerngegevens. Na opslaan verschijnt de {entity}{" "}
                direct in de juiste werkvoorraad.
              </p>
              <div>
                <small>Naam / omschrijving</small>
                <strong>
                  {entity === "opdracht"
                    ? "Periodieke vloerzorg"
                    : `Nieuwe ${entity}`}
                </strong>
              </div>
              <div>
                <small>Koppeling</small>
                <strong>Hofstaete Vastgoed · Toren B</strong>
              </div>
              <div>
                <small>Eigenaar</small>
                <strong>Sanne van Delft</strong>
              </div>
            </div>
          ) : step === 0 ? (
            <div className="wizard-fields">
              <label className="span-2">
                Naam of korte omschrijving
                <Input
                  placeholder={`Bijvoorbeeld: ${entity === "opdracht" ? "Periodieke vloerzorg" : `Nieuwe ${entity}`}`}
                />
              </label>
              <label>
                Categorie
                <Select defaultValue="service">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="service">Dienstverlening</SelectItem>
                    <SelectItem value="security">Beveiliging</SelectItem>
                    <SelectItem value="cleaning">Schoonmaak</SelectItem>
                  </SelectContent>
                </Select>
              </label>
              <label>
                Prioriteit
                <Select defaultValue="normal">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="normal">Normaal</SelectItem>
                    <SelectItem value="high">Hoog</SelectItem>
                    <SelectItem value="urgent">Spoed</SelectItem>
                  </SelectContent>
                </Select>
              </label>
              <label className="span-2">
                Toelichting
                <Textarea placeholder="Wat moet de uitvoerder of beheerder weten?" />
              </label>
            </div>
          ) : step === 1 ? (
            <div className="wizard-fields">
              <label>
                Klant
                <Select defaultValue="hofstaete">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hofstaete">
                      Hofstaete Vastgoed
                    </SelectItem>
                    <SelectItem value="worldforum">
                      World Forum Den Haag
                    </SelectItem>
                  </SelectContent>
                </Select>
              </label>
              <label>
                Object / locatie
                <Select defaultValue="toren">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="toren">Toren B</SelectItem>
                    <SelectItem value="entree">Entree en ontvangst</SelectItem>
                  </SelectContent>
                </Select>
              </label>
              <label>
                Verantwoordelijke
                <Select defaultValue="sanne">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sanne">Sanne van Delft</SelectItem>
                    <SelectItem value="danny">Danny Goldenbelt</SelectItem>
                  </SelectContent>
                </Select>
              </label>
              <label>
                Referentie
                <Input placeholder="Inkoopnummer of klantref." />
              </label>
              <div className="span-2 wizard-info">
                <Building2 />
                <span>
                  <strong>Objectgegevens worden hergebruikt</strong>
                  <small>
                    Adres, contactpersonen, toegangsregels en
                    standaardchecklists worden automatisch gekoppeld.
                  </small>
                </span>
              </div>
            </div>
          ) : (
            <div className="wizard-fields">
              <label>
                Gewenste datum
                <Input type="date" defaultValue="2026-09-04" />
              </label>
              <label>
                Tijdvenster
                <div className="date-pair">
                  <Input type="time" defaultValue="09:00" />
                  <Input type="time" defaultValue="12:00" />
                </div>
              </label>
              <label>
                Benodigde rol
                <Select defaultValue="allround">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="allround">
                      Allround medewerker
                    </SelectItem>
                    <SelectItem value="lead">Objectleider</SelectItem>
                    <SelectItem value="security">Beveiliger</SelectItem>
                  </SelectContent>
                </Select>
              </label>
              <label>
                Aantal personen
                <Input type="number" defaultValue="1" min="1" />
              </label>
              <label className="span-2 check-row">
                <Checkbox defaultChecked />
                <span>
                  <strong>Laat slimme planning kandidaten voorstellen</strong>
                  <small>
                    Match op kwalificaties, regio, beschikbaarheid, reistijd en
                    belasting.
                  </small>
                </span>
              </label>
            </div>
          )}
        </div>
        <DialogFooter className="wizard-footer">
          <span>
            {!done
              ? "Verplichte velden worden per stap gecontroleerd."
              : "Alles is gereed voor opslag."}
          </span>
          <div>
            <Button
              variant="outline"
              onClick={() =>
                step === 0 ? onOpen(false) : setStep((value) => value - 1)
              }
            >
              {step === 0 ? (
                "Annuleren"
              ) : (
                <>
                  <ArrowLeft /> Terug
                </>
              )}
            </Button>
            <Button
              className="primary-button"
              onClick={() => {
                if (done) {
                  toast.success(
                    `${entity.charAt(0).toUpperCase() + entity.slice(1)} is aangemaakt`,
                  );
                  setStep(0);
                  onOpen(false);
                } else setStep((value) => value + 1);
              }}
            >
              {done ? (
                <>
                  <Check /> Aanmaken
                </>
              ) : (
                <>
                  Volgende <ArrowRight />
                </>
              )}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function GlobalCommand({
  open,
  onOpen,
  onNavigate,
}: {
  open: boolean;
  onOpen: (open: boolean) => void;
  onNavigate: (view: ViewId) => void;
}) {
  return (
    <CommandDialog
      open={open}
      onOpenChange={onOpen}
      title="Ga naar of zoek"
      description="Zoek een werkruimte, dossier of actie"
      className="prototype-command-dialog"
    >
      <CommandInput placeholder="Zoek pagina, dossier, opdracht of actie…" />
      <CommandList>
        <CommandEmpty>Geen resultaat gevonden.</CommandEmpty>
        <CommandGroup heading="Werkruimtes">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <CommandItem
                key={item.id}
                value={`${item.label} ${item.group}`}
                onSelect={() => {
                  onNavigate(item.id);
                  onOpen(false);
                }}
              >
                <Icon />
                {item.label}
                <CommandShortcut>Open</CommandShortcut>
              </CommandItem>
            );
          })}
        </CommandGroup>
        <CommandGroup heading="Recente dossiers">
          <CommandItem
            onSelect={() => {
              onNavigate("customers");
              onOpen(false);
            }}
          >
            <BriefcaseBusiness />
            Hofstaete Vastgoed<CommandShortcut>KL-1040</CommandShortcut>
          </CommandItem>
          <CommandItem
            onSelect={() => {
              onNavigate("objects");
              onOpen(false);
            }}
          >
            <Building2 />
            World Forum — entree A<CommandShortcut>OBJ-301</CommandShortcut>
          </CommandItem>
          <CommandItem
            onSelect={() => {
              onNavigate("personnel");
              onOpen(false);
            }}
          >
            <UserCog />
            Sofia de Jong<CommandShortcut>P-201</CommandShortcut>
          </CommandItem>
        </CommandGroup>
        <CommandGroup heading="Snelle acties">
          <CommandItem
            onSelect={() => toast.info("Nieuwe opdrachtwizard geopend")}
          >
            <Plus />
            Nieuwe opdracht<CommandShortcut>N</CommandShortcut>
          </CommandItem>
          <CommandItem onSelect={() => toast.info("Documentupload geopend")}>
            <UploadCloud />
            Document uploaden
          </CommandItem>
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  );
}

export function FieldgridDesignLab() {
  const [designId, setDesignId] = React.useState<DesignId>("fieldflow");
  const [view, setView] = React.useState<ViewId>("dashboard");
  const [dossier, setDossier] = React.useState<DossierType | null>(null);
  const [commandOpen, setCommandOpen] = React.useState(false);
  const [mobileNavOpen, setMobileNavOpen] = React.useState(false);
  const [filterOpen, setFilterOpen] = React.useState(false);
  const [wizardOpen, setWizardOpen] = React.useState(false);
  const [detail, setDetail] = React.useState<{
    title: string;
    subtitle: string;
  } | null>(null);
  const design = findDesign(designId);
  const activeGroup = groupForView(view);

  React.useEffect(() => {
    document.body.dataset.concept = designId;
    return () => {
      delete document.body.dataset.concept;
    };
  }, [designId]);

  React.useEffect(() => {
    function onKeyDown(event: KeyboardEvent) {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setCommandOpen((current) => !current);
      }
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  function resetWorkspaceScroll() {
    document
      .querySelector<HTMLElement>(".workspace-scroll")
      ?.scrollTo({ top: 0, left: 0, behavior: "smooth" });
  }

  function navigate(next: ViewId) {
    setView(next);
    setDossier(null);
    resetWorkspaceScroll();
  }

  function selectGroup(group: GroupId) {
    const first = navItems.find((item) => item.group === group);
    if (first) navigate(first.id);
  }

  return (
    <TooltipProvider delayDuration={180}>
      <a className="skip-link" href="#main-content">
        Naar hoofdinhoud
      </a>
      <div className={`design-lab concept-${design.id}`}>
        <LabBar
          design={design}
          onDesign={(id) => {
            setDesignId(id);
            resetWorkspaceScroll();
          }}
          onPlanning={() => navigate("planning")}
          onAnalysis={() => navigate("analysis")}
        />
        <AppShell
          design={design}
          active={view}
          activeGroup={activeGroup}
          onNavigate={navigate}
          onGroup={selectGroup}
          onCommand={() => setCommandOpen(true)}
          onSupport={() => navigate("support")}
          onCreate={() => setWizardOpen(true)}
          onMobileNav={() => setMobileNavOpen(true)}
        >
          <ConceptPageComposition
            design={designId}
            view={view}
            hasDossier={Boolean(dossier)}
            onNavigate={navigate}
          >
            <PageRouter
              design={designId}
              view={view}
              dossier={dossier}
              onNavigate={navigate}
              onCreate={() => setWizardOpen(true)}
              onFilter={() => setFilterOpen(true)}
              onDetail={(title, subtitle) => setDetail({ title, subtitle })}
              onOpenDossier={(type) => {
                setDossier(type);
                resetWorkspaceScroll();
              }}
              onCloseDossier={() => {
                setDossier(null);
                resetWorkspaceScroll();
              }}
              onDesign={(id) => {
                setDesignId(id);
                resetWorkspaceScroll();
                navigate("dashboard");
              }}
            />
          </ConceptPageComposition>
        </AppShell>
        <MobileNavigation
          open={mobileNavOpen}
          onOpen={setMobileNavOpen}
          active={view}
          onNavigate={navigate}
        />
        <FilterSheet open={filterOpen} onOpen={setFilterOpen} />
        <DetailSheet detail={detail} onClose={() => setDetail(null)} />
        <EntityWizard open={wizardOpen} onOpen={setWizardOpen} view={view} />
        <GlobalCommand
          open={commandOpen}
          onOpen={setCommandOpen}
          onNavigate={navigate}
        />
        <Toaster position="bottom-right" richColors closeButton />
      </div>
    </TooltipProvider>
  );
}
