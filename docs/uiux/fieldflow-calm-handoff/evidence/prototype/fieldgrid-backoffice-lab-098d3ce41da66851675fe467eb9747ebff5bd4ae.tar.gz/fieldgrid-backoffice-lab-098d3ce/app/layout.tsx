import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Fieldgrid Backoffice Design Lab",
  description:
    "Vijf volledige premium UI/UX-richtingen voor de Fieldgrid tenant-backoffice.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
  other: {
    "codex-preview": "development",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="nl">
      <body className="antialiased">{children}</body>
    </html>
  );
}
